# EK Last Similar 4.2.0 — Revit 2024–2027

Adds **many more element types** to Last Similar and Recent 5, and a **"not visible" warning**. Families, tags, lines and height correction work exactly as in 4.1.0. Your saved history, favorites and heights are kept.

## What changed in 4.2.0

### Last Similar for more element types

When you place one of these normally in Revit, it becomes **Last** and goes into **Recent 5** and **Settings** (with its own icon):

| Group | Elements |
|---|---|
| Annotation | text notes, dimensions, spot elevations / coordinates / slopes, filled regions, masking regions, callouts, detail groups |
| Architecture | walls, curtain walls, stairs, railings, model groups |
| MEP | ducts, flex ducts, pipes, flex pipes, conduit, cable trays, duct accessories, pipe accessories |
| Structure | beams, braces, columns, structural columns |

**How LL places them:** always with **Revit's own tool** for that exact type, in this order:

1. **Create Similar from the element you placed last**, if it is in the current view. This keeps what Create Similar keeps, such as system type, size, and beam vs brace.
2. Otherwise Revit's own placement of exactly that type.
3. Otherwise Create Similar from another element of exactly that type in the current view.

If none of these works, EK says so and changes nothing. It never switches to a different or default type.

**Heights (double-checked):** none of these are ever height-corrected. They never go through EK's family placement or height correction; Revit places them exactly as it normally does. Beams, braces, columns and duct/pipe accessories used to be treated as ordinary families (none of them were actually moved, since the correction only touches wall-hosted devices); now they are routed natively and the code makes a height change impossible. Older history entries for these types switch over automatically. In Settings their height options read "Not applicable".

**What counts as one placement:**

- Several pieces of **one type** in one go count as one placement: a wall rectangle, conduit with a bend, columns at grids.
- **Pieces Revit adds automatically don't count:** pipe/duct pieces split off when you insert an accessory or tee, the railings of a new stair, curtain panels and mullions, wall members of a stacked wall, group members, and tags from Tag on Placement.
- Different types in one commit (copy/paste of mixed things, a tee into a main of another type), Undo/Redo, Duplicate View, and alignment lock constraints are not placements.

### "Not visible" warning

After you place something with Last Similar, Recent 5 or Settings > Place, EK checks the view. If what you placed is in the model but **not visible**, a warning says why:

- its category (or the line style) is turned off in Visibility/Graphics, in the view or in its view template;
- all model or annotation categories are off;
- a view filter hides it;
- or Revit does not draw it in that view (view range / depth, phase, workset, design option, Temporary Hide/Isolate).

The warning only explains; it never changes the model or the view. For tools Revit runs itself (tags, lines, walls, ducts, ...) it appears once you finish the tool (Esc). Turn it off with the checkbox in the warning, or in **Settings > General > After placing**.

### Fixed in the bundled checks

- The structural check and diagnostics test still expected old version strings and an old line of code; updated.

### Checks run for this package

- Full builds, including the windows, for Revit 2024, 2025, 2026 and 2027: 0 errors, 0 warnings (against Autodesk's published API reference packages).
- 129 fixture checks pass: 32 face/host, 79 history/placement (42 new for 4.2.0), 18 diagnostics.
- These are not a live Revit test. Please try the list below.

### First Revit check for 4.2.0

1. Place a text note, a wall (try the rectangle option), a duct and a conduit run with a bend. LL after each must start that tool with the same type.
2. Insert a pipe accessory into a pipe: LL must place the accessory again, not a pipe.
3. Make a stair: LL must start the stair tool, not the railing.
4. Place a beam, then a brace of the same type: LL repeats the brace (when the brace is in view).
5. Place a model group, a detail group, a filled region, a masking region, a dimension and a spot elevation, and check each with LL.
6. Callouts are the least certain item: check whether LL starts the callout tool. If not, tell me what happens.
7. Turn a category off in VV (e.g. Lighting Fixtures), then place a light with LL: the warning must name that category. Try a view filter too.
8. Check that wall-hosted switches and receptacles still get their heights exactly as before.

---

## Previous release: 4.1.0

Adds **tags** to Last Similar and Recent 5. Families, lines, Room Tags, height correction and all safety rules are unchanged from 4.0.5. Your saved history, favorites and heights are kept.

## What changed in 4.1.0

**More tag types are remembered and re-placed.** Besides Room Tags, Last Similar and Recent 5 now handle:

- **Category tags**: fixture, device, lighting, equipment, conduit, cable tray, pipe, duct tags and any other "Tag by Category" tag;
- **Multi-category tags** and **material tags**;
- **Space Tags** and **Area Tags**.

They work exactly like Room Tags already did:

- A single tag you place becomes **Last** and goes to the top of **Recent 5** (with a new tag icon).
- **Last Similar** starts Revit's own tag tool with that exact tag type. If Revit can't start that type directly, it uses Revit's **Create Similar** on a tag of that type in the current view. It never falls back to a different/default tag type and never draws tags itself.
- Tags have no height settings (Settings shows "Not applicable to tags or lines"); favorites work.

**Rules that keep your history clean:**

- **Tag on Placement**: when Revit tags a device automatically as you place it, the **device** stays Last, not the tag.
- **Tag All Not Tagged**, copy/paste of several tags, Undo/Redo, tags inside groups, Synchronize/Reload Latest: not counted as a placement.
- **Keynote tags** are not tracked (their element/material/user keynote mode is not part of the tag type).

**Bug fix (Room Tags):** the fallback that looks for a Room Tag in the current view used a Revit collector filter that Revit rejects for Room Tags, so that fallback always ended in "Could not start native Room Tag placement". It now searches Room Tags the supported way. Direct placement was not affected.

**Verification:** the Room Tag fixture now also covers the new tags (15 more checks: tracking, Tag on Placement, Tag All, keynotes, groups, Redo, Space/Area tags, exact-type dispatch, no-tagging views, Create Similar fallback, no type substitution, no heights). **These new checks have not been run yet**: this package was prepared without a .NET SDK. Run `Verification/run-fixtures.py` (see `Verification/README.md`) or simply install — the installer builds against your real Revit API and stops on any compile error.

### First Revit check for 4.1.0

1. Tag a light fixture with Tag by Category (non-default tag type). Run LL: the same tag type starts. Esc: nothing changes.
2. Place a device with **Tag on Placement** on: LL must place the device again, not the tag.
3. Run **Tag All Not Tagged**: Last must not change.
4. Place a Space Tag and an Area Tag; check both appear in Recent 5 and re-place correctly.
5. Room Tag: in a view where direct placement is refused, the Create Similar fallback now works.

---

## Previous release: 4.0.5

**Settings window reorganized.** Related options are now grouped together instead of being split across the header, the side and the bottom of the window:

- **Recent types** tab: the list of types on the left. Everything about the selected type is in one panel on the right: name and family, **Favorite**, then **Placement height** (*Auto-adjust height for this type*, *Last placed height* or *Fixed height … cm*). Below the list: **Remove from list**, **Move to bottom** and **Place**.
- **General** tab: options that apply to every type and project, in three groups: **Placement heights** (*Auto-adjust heights (all types)*), **Recent 5 palette** (thumbnails and size) and **Troubleshooting** (diagnostic log).
- If *Auto-adjust heights (all types)* is off, the Recent types panel shows a short note saying so.
- Same controls and same rules as before: **Save** keeps changes, **Close** (or Esc) discards them, **Place** saves and then places. Double-click or Enter still places.

**New ribbon icons** (see `ICON_PREVIEW.png`):

- **Last Similar**: a "repeat" arrow around a family block, meaning *place the last type again*.
- **Recent 5**: a short list with a blue **5** badge, meaning *pick one of the last 5*.
- **Settings**: now has a gear icon (before, it had none).

**Bug fixes**

- Settings: changing a type to *Fixed height* (or back to *Last placed height*) and turning off *Auto-adjust height for this type* at the same time lost the height change. The height choice is now kept; it applies again when auto-adjust is turned back on, as the window already promised. A fixed height is still only required to be valid while auto-adjust is on.
- Settings: if a project's history held only Detail/Model Lines (which have no settings), Settings opened an empty window. It now shows the usual "nothing remembered yet" message.
- Last Similar for lines: if Revit's Create Similar could not be started, your selection was left replaced by the seed line. It is now restored (Room Tags already did this).
- Recent 5: **Shift+Tab** now moves the highlight up (it moved down, like Tab).
- Minor code cleanup (one dead statement, two duplicate handlers merged, settings file version stamped consistently).
- Verification fixtures: the Room Tag and diagnostics test programs had not been updated for 4.0.4 and no longer compiled/passed; they are updated so the existing checks run again.

## Install

1. Close every Revit session.
2. Extract the entire ZIP to a normal folder.
3. Run **INSTALL_EK_LAST_SIMILAR.cmd**.
4. Wait for the installer to report success for every detected Revit version, then reopen Revit.

This is a **source-and-build installer**, like the previous package. It builds the production DLL for each installed Revit version using that installation's API. It does not contain precompiled production DLLs. The .NET 10 SDK supports the package's build targets; the installer checks installed SDKs. CMD shows short progress lines (one per Revit version); compiler details go into `_Payload\INSTALL_EK_LAST_SIMILAR.log`. If a build fails, relevant errors are shown.

The installer preserves existing EK settings/history. No shortcut reassignment is required. A failed or unfinished build does not prove the new version was installed; the October 19 diagnostic log still showed 4.0.1 running.

## Carried forward from 4.0.4.1: optional height correction and clean installation screen

In **EK Last Similar > Settings** (4.0.5: *Auto-adjust heights (all types)* is on the **General** tab; the per-type switch is in the selected-type panel of the **Recent types** tab):

- **Auto-adjust heights (all types)** is the master switch. ON (default): the previous correction behavior is used for every Revit project; OFF: LL and Recent 5 still place elements, but no height or automatic level adjustment is attempted by EK on any newly placed family.
- Select a family and uncheck **Auto-adjust height for this type** to disable correction for just that saved family type in this project. Other types keep their normal behavior. This preference is retained for that type when it is placed again.
- Re-enable either option at any time. Saved fixed height, learned-height preference, favorites, and Recent 5 history are not reset or deleted. Existing placed elements are never changed retroactively.
- Room Tags and lines do not have height controls. Ceilings, floors and horizontal hosts still stay untouched even when correction is enabled.
- Normal CMD output shows progress and build success only; full compiler warnings remain in the installer logfile. On a build error, a short error excerpt appears on screen. All previous safe-install/rollback mechanisms remain.

The new controls are staged like other settings: **Save** persists, **Close** discards, and **Place** saves before placing.

## Carried forward unchanged from 4.0.3

- **Vertical hosts:** resolve the actual host face through its geometry-instance transforms and the link transform. Check the target lies within that same face before attempting a correction. Preserve mounting offset, XY position, host/face identity, physical orientation and flip states; reject or roll back an unsafe correction. Floors, ceilings, roofs and horizontal faces remain excluded.
- **Room Tags:** actual room-tag placements update Last and Recent 5. LL requests native placement of the remembered `RoomTagType`. If that type cannot be queued directly, it uses native Create Similar from an exact-type tag in the current view. Revit retains its room selection, orientation, leader controls and Undo. Local and linked rooms use Revit's native capabilities and visibility rules. Tags have no height correction; favorites remain available.
- **Diagnostics:** optional per-process/version/run traces are retained to investigate the older unexplained outside-EK events. Troubleshooting remains off by default and follows your existing setting.

**Height reference is unchanged:** 110 cm means 110 cm above the level selected by the existing rule: the highest host-document level at or below the placement point. In the supplied October 19 examples, that is the level at 590 mm, so the target absolute Z is 1690 mm. This release does not redefine 110 cm as a ground-floor absolute elevation.

## Validation and limits

**4.0.5 checks (this package):** full builds including the real XAML for Revit 2024, 2025, 2026 and 2027 with 0 errors and 0 warnings (against the public Revit API reference packages), all 72 bundled fixture checks passing (32 face/host, 22 Room Tag/history, 18 diagnostics) and the structural settings check passing. See `Verification/results/v4.0.5-*.log`. These are still not a live Revit test; the installer does the real build on your PC against your Revit.


The **original 4.0.3 package** reported 72 focused checks: 32 face/host safety checks, 22 Room Tag/history integration checks and 18 diagnostic checks. Its C# compilation checks were against all four Revit API versions and its PowerShell scripts parsed without errors. **Those are v4.0.3 results, not new v4.0.4.1 build results.** v4.0.4.1 source and XAML have been checked structurally in this environment, which does not contain the Windows Revit APIs or .NET SDK needed for a production build.

These are code/fixture checks, **not a live Revit model test or a complete Windows WPF build**. Native placement, the actual glass panel geometry and Undo still need validation in Revit. The installer performs the complete Windows production build. See **DIAGNOSIS_AND_CHANGES.md** and **Verification/README.md** for evidence and limits.

The log proves the newer glass placements were captured and then rolled back at face verification. The missing geometry transform is a confirmed code defect; its exact role in your panel has not been measured in a live model. The cause of the original outside-EK events remains unproven.

## First Revit check

Place a switch on a regular linked wall and on the same linked glass panel, finish placement, and check the resulting height relative to the selected level, host and orientation. Test Undo/Redo. A target outside the panel must remain unchanged. Check a ceiling/floor placement remains unchanged.

Place a Room Tag normally, then use LL and Recent 5 to place that type again. Check a visible linked room too. If host and linked rooms overlap at the click, native Revit favors the host-model room. Room tagging must be available in the current view.

If a glass correction still skips or rolls back, enable the existing Troubleshooting setting, repeat once, and run **COLLECT_DIAGNOSTICS.cmd**. This release contains the diagnostics already; no separate diagnostic installer is needed.

# Verification record — October 19, 2026

## Results

| Check | Result | Scope |
|---|---|---|
| Revit 2024 C# API compilation, net48 | Pass, 0 errors | All production C# against the 2024 API, validation-only WPF generated fields |
| Revit 2025 C# API compilation, net8.0-windows | Pass, 0 errors | Same against the 2025 API |
| Revit 2026 C# API compilation, net8.0-windows | Pass, 0 errors | Same against the 2026 API |
| Revit 2027 C# API compilation, net10.0-windows | Pass, 0 errors | Same against the 2027 API |
| Face/host safety checks | 32 passed | Production HostFaceGeometry/HostClassifier against deterministic geometry fixtures |
| Room Tag/history checks | 22 passed | Production RoomTagSimilarService, CommandRunner, LastPlacedTracker, StateStore and StateModels with Revit boundary fixtures |
| Diagnostics checks | 18 passed | Production RunLog/DiagnosticFiles and release AssemblyInfo; test-only state directory |
| PowerShell parsing | 0 errors | Install-EKLastSimilar.ps1 and Collect-Diagnostics.ps1, actual PowerShell parser |
| Room Tag separation | Pass | Host-face and correction files unchanged from before Room Tag integration; XAML layouts unchanged |

C# validation warnings were 15 generated-field initialization warnings for 2024 and 17 warnings for each newer version, including reference-assembly conflict warnings for Microsoft.VisualBasic/Microsoft.VisualBasic.Core. These compile-only outputs were not used as installable DLLs. Full logs are included, so these checks are not presented as warning-free production builds.

## What the checks exercise

The face fixture reproduces the original link-only coordinate error and verifies transformed native/linked panels, rotation/translation/reflection, nested geometry and top-level solids. It rejects points outside trimmed faces/inside holes, excessive or changed mounting offsets, ambiguous/missing references, horizontal faces, changed host/face identity, and changed physical orientation. Native and linked ceiling/floor/roof hosts remain excluded. Traditional wall hosting remains supported.

The Room Tag fixture exercises actual tracker event handling, JSON history writes and readback, Recent 5 order, preservation of existing fixed heights/favorites, exact-type native placement dispatch, cancellation without false history, native Create Similar fallback, failed-post selection restoration, unavailable views, wrong-type rejection, height-write exclusions, Undo/Redo/view-duplication/group/bulk exclusions and continuing line tracking. Native API calls are observed by fixtures; no fixture verifies real Revit's placement UI, geometry kernel or Undo stack.

Diagnostics checks cover off-by-default silence, version/process/run identity, persistence before command exit, concurrent process traces, bounded logs, I/O failure isolation, shortcut conflicts and journal command extraction.

## Remaining Revit validation

A complete Windows WPF build, native UI placement and live Revit tests could not run in the Linux environment. Attempting the complete WPF build here fails in the markup build task; the original baseline also fails in that environment. The API check supplies validation-only generated fields to compile the C# separately. Those fields and their DLLs are not in this installer.

The included Windows installer builds the real XAML and production DLLs for each detected Revit installation. The user's uploaded installer log proves only a previous 4.0.2 Revit 2024 build succeeded, not that 4.0.3 is already built or installed.

In Revit, check regular linked walls, the actual glass panel, other valid vertical faces, target points beyond panel boundaries, floor/ceiling exclusions, hosting/orientation, native Undo/Redo, and local/linked Room Tag placement. Confirm fixed height against the existing selected-level rule. These runtime items are not claimed as passed.

## Reviewing or rerunning fixtures

`FaceTests`, `RoomTagTests` and `DiagnosticsTests` contain the exact production-source links and boundary fixtures used. They are outside `_Payload` and cannot be compiled into the add-in by its project. The installer does not run or install them. The separate patches are relative to 4.0.2's diagnostic installer package; `v400-to-v401-source.patch` is the original requested comparison.

On Linux with Python 3 and .NET 10 SDK, from this folder run:

```sh
python3 run-fixtures.py --dotnet /path/to/dotnet
```

Room Tag tests refuse to run unless their state storage resolves to the isolated test directory. No Revit model or real EK settings are used. Build artifacts from these fixtures must never be installed into Revit.

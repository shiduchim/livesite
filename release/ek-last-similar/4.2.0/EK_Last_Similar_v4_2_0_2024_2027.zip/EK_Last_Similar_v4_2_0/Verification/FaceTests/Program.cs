using System;
using Autodesk.Revit.DB;
using EK.LastSimilar.Services;
class Program {
 static int count; static void Check(bool b,string text){if(!b)throw new Exception(text);Console.WriteLine("PASS "+text);count++;}
 static Transform Rotate(double a,XYZ origin)=>new Transform {Origin=origin,BasisX=new XYZ(Math.Cos(a),Math.Sin(a),0),BasisY=new XYZ(-Math.Sin(a),Math.Cos(a),0)};
 static (FamilyInstance,Face,Transform) Fixture(bool nested,bool linked,bool mirror=false){
  var doc=new Document();var local=new Reference{ElementId=new ElementId(1),Stable="panel:instance:face:1"};
  var face=new Face{Reference=local};var solid=new Solid();solid.Faces.Add(face);
  var panelTransform=Rotate(Math.PI/2,new XYZ(100,200,2));if(mirror)panelTransform.BasisX=-1*panelTransform.BasisX;
  var panel=new Element{Document=doc,Id=local.ElementId,Geometry=nested?new GeometryElement{new GeometryInstance{Transform=panelTransform,Symbol=new GeometryElement{solid}}}:new GeometryElement{solid}};
  doc.Elements.Add(1,panel);
  var linkTransform=Rotate(-Math.PI/3,new XYZ(1000,-700,5));var link=new RevitLinkInstance{Id=new ElementId(9),Linked=doc,Transform=linkTransform};
  var reference=linked?new Reference{ElementId=link.Id,LinkedElementId=panel.Id,Stable="link:panel:face:1",Local=local}:local;
  Transform total=(linked?linkTransform:Transform.Identity).Multiply(nested?panelTransform:Transform.Identity);
  var device=new FamilyInstance {Host=linked?link:panel,HostFace=reference,Location=new LocationPoint{Point=total.OfPoint(new XYZ(0.05,1,0.7))}};
  return (device,face,total);
 }
 static void Main(){
  var (device,face,total)=Fixture(true,true);var before=((LocationPoint)device.Location).Point;var target=total.OfPoint(new XYZ(0.05,1,1100.0/304.8));
  var link=(RevitLinkInstance)device.Host;var oldLocal=link.Transform.Inverse.OfPoint(target);
  Check(face.Project(oldLocal)==null,"regression: v4.0.1's link-only conversion rejects a valid point on translated/rotated panel");
  Check(HostFaceGeometry.TryResolve(device,out var g,out var reason),"resolve exact linked panel face through original geometry");
  Check(g.ValidateMove(before,target,out var offset,out reason),"production resolver accepts valid 1100 mm local height with composed link/panel transforms");
  Check(Math.Abs(offset.GetLength()-0.05)<1e-9,"existing mounting offset preserved");
  Check(g.TryProject(target,out var projected,out var normal,out reason)&&normal.DistanceTo(total.OfVector(new XYZ(1,0,0)))<1e-9,"face normal transformed into model coordinates");
  Check(!g.ValidateMove(before,total.OfPoint(new XYZ(0.05,1,15)),out _,out reason),"target above finite panel rejected");
  face.Hole=true;Check(!g.ValidateMove(before,target,out _,out reason),"target within face opening rejected");face.Hole=false;
  Check(!g.ValidateMove(before,total.OfPoint(new XYZ(0.15,1,3)),out _,out reason),"change of mounting offset rejected");
  Check(!g.ValidateMove(total.OfPoint(new XYZ(1,1,0.7)),target,out _,out reason),"original point more than 100 mm from face rejected");
  var (native,_,nt)=Fixture(true,false);Check(HostFaceGeometry.TryResolve(native,out var ng,out reason)&&ng.ValidateMove(((LocationPoint)native.Location).Point,nt.OfPoint(new XYZ(0.05,1,3)),out _,out reason),"native transformed family host supported");
  var (direct,_,dt)=Fixture(false,true);Check(HostFaceGeometry.TryResolve(direct,out var dg,out reason)&&dg.ValidateMove(((LocationPoint)direct.Location).Point,dt.OfPoint(new XYZ(0.05,1,3)),out _,out reason),"top-level document geometry is not transformed twice");
  var (mirrored,_,mt)=Fixture(true,true,true);Check(HostFaceGeometry.TryResolve(mirrored,out var mg,out reason)&&mg.ValidateMove(((LocationPoint)mirrored.Location).Point,mt.OfPoint(new XYZ(0.05,1,3)),out _,out reason),"mirrored panel transform supported without moving across face");
  var (bad,_,bt)=Fixture(true,true);bad.HostFace.Local=new Reference{ElementId=new ElementId(1),Stable="wrong-face"};Check(!HostFaceGeometry.TryResolve(bad,out _,out reason),"missing exact reference fails closed, with no nearest-face fallback");
  var (ambiguous,af,_)=Fixture(false,false);((Solid)ambiguous.Host.Geometry[0]).Faces.Add(af);Check(!HostFaceGeometry.TryResolve(ambiguous,out _,out reason),"ambiguous duplicate face reference rejected");
  var (horizontal,hf,ht)=Fixture(false,false);hf.Horizontal=true;horizontal.Location=new LocationPoint{Point=new XYZ(0.5,1,0.05)};Check(HostFaceGeometry.TryResolve(horizontal,out var hg,out reason)&&!hg.ValidateMove(((LocationPoint)horizontal.Location).Point,new XYZ(0.5,1,0.2),out _,out reason),"horizontal face rejected");
  Check(HostFaceGeometry.SameBasis(total,new Transform{Origin=new XYZ(3,4,5),BasisX=total.BasisX,BasisY=total.BasisY,BasisZ=total.BasisZ}),"vertical translation preserves physical orientation");
  Check(!HostFaceGeometry.SameBasis(total,total.Multiply(Rotate(0.1,new XYZ(0,0,0)))),"actual rotation rejected by physical axes");
  Check(!HostFaceGeometry.SameBasis(total,new Transform{BasisX=-1*total.BasisX,BasisY=total.BasisY,BasisZ=total.BasisZ}),"mirroring change rejected");
  foreach(var cat in new[]{BuiltInCategory.OST_Ceilings,BuiltInCategory.OST_Floors,BuiltInCategory.OST_Roofs}){
   var (v,_,_t)=Fixture(true,false);v.Host.Category=new Category{Id=new ElementId((long)cat),Name=cat.ToString()};var kind=HostClassifier.Classify(v).Kind;
   Check(kind==HostKind.Other||kind==HostKind.Ceiling,"production classifier excludes "+cat+" despite vertical face");
   var (lv,_,_lt)=Fixture(true,true);((RevitLinkInstance)lv.Host).Linked.GetElement(lv.HostFace.LinkedElementId).Category=v.Host.Category;var lkind=HostClassifier.Classify(lv).Kind;
   Check(lkind==HostKind.Other||lkind==HostKind.Ceiling,"production classifier excludes linked "+cat);
  }
  var initial=HostClassifier.Classify(device);Check(initial.Kind==HostKind.VerticalFace,"production classifier recognizes linked transformed panel");
  ((LocationPoint)device.Location).Point=target;Check(HostClassifier.VerifySameVerticalHost(device,initial,out reason),"production guard accepts same transformed face after movement");
  device.Host.UniqueId="different-host";Check(!HostClassifier.VerifySameVerticalHost(device,initial,out reason),"production guard rejects changed host identity");
  var (wallDevice,wf,wt)=Fixture(false,false);var oldHost=wallDevice.Host;
  var wall=new Wall{Id=oldHost.Id,UniqueId=oldHost.UniqueId,Document=oldHost.Document,Geometry=oldHost.Geometry,Category=new Category{Id=new ElementId((long)BuiltInCategory.OST_Walls),Name="Walls"}};
  wallDevice.Host=wall;var wallInfo=HostClassifier.Classify(wallDevice);Check(wallInfo.Kind==HostKind.Wall&&HostClassifier.VerifySameVerticalHost(wallDevice,wallInfo,out reason),"regular wall face remains eligible with verified hosting");
  wallDevice.HostFace=null;var traditional=HostClassifier.Classify(wallDevice);Check(traditional.Kind==HostKind.Wall&&HostClassifier.VerifySameVerticalHost(wallDevice,traditional,out reason),"traditional wall hosting without HostFace retained");
  var (turning,tf,_tt)=Fixture(true,false);var turn=(GeometryInstance)turning.Host.Geometry[0];turn.Transform=new Transform{BasisX=new XYZ(0,0,1),BasisY=new XYZ(0,1,0),BasisZ=new XYZ(-1,0,0)};turning.Location=new LocationPoint{Point=turn.Transform.OfPoint(new XYZ(0.05,1,0.7))};
  Check(HostClassifier.Classify(turning).Kind==HostKind.Other,"local vertical face transformed to horizontal is excluded");
  var (second,sf,st)=Fixture(true,false);var originalTree=second.Host.Geometry;var extra=Rotate(0.3,new XYZ(4,7,9));second.Host.Geometry=new GeometryElement{new GeometryInstance{Transform=extra,Symbol=originalTree}};second.Location=new LocationPoint{Point=extra.OfPoint(((LocationPoint)second.Location).Point)};
  Check(HostFaceGeometry.TryResolve(second,out var sg,out reason)&&sg.ValidateMove(((LocationPoint)second.Location).Point,extra.OfPoint(st.OfPoint(new XYZ(0.05,1,3))),out _,out reason),"multiple nested geometry transforms composed in order");
  var secondInfo=HostClassifier.Classify(second);sf.Reference=new Reference{ElementId=second.Host.Id,Stable="new-face"};second.HostFace=sf.Reference;
  Check(!HostClassifier.VerifySameVerticalHost(second,secondInfo,out reason),"changed stable face reference rejected on unchanged host");
  Console.WriteLine("TOTAL PASS "+count);
 }
}

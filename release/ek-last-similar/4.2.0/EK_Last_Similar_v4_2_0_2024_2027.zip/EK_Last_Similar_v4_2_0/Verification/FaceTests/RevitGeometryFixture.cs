// Deterministic geometry fixtures, NOT Autodesk/Revit runtime implementations.
// Used only to execute production resolver/control logic outside Windows/Revit.
using System;
using System.Collections.Generic;
namespace Autodesk.Revit.DB {
 public class XYZ {
  public double X,Y,Z; public XYZ(double x,double y,double z){X=x;Y=y;Z=z;}
  public static XYZ operator +(XYZ a,XYZ b)=>new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
  public static XYZ operator -(XYZ a,XYZ b)=>new XYZ(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
  public static XYZ operator *(double s,XYZ a)=>new XYZ(s*a.X,s*a.Y,s*a.Z);
  public double Dot(XYZ b)=>X*b.X+Y*b.Y+Z*b.Z;
  public double GetLength()=>Math.Sqrt(Dot(this)); public double DistanceTo(XYZ b)=>(this-b).GetLength();
  public XYZ Normalize()=>1/GetLength()*this;
 }
 public class Transform {
  public XYZ Origin=new XYZ(0,0,0),BasisX=new XYZ(1,0,0),BasisY=new XYZ(0,1,0),BasisZ=new XYZ(0,0,1);
  public static Transform Identity=>new Transform();
  public XYZ OfVector(XYZ p)=>p.X*BasisX+p.Y*BasisY+p.Z*BasisZ;
  public XYZ OfPoint(XYZ p)=>Origin+OfVector(p);
  public Transform Multiply(Transform b)=>new Transform {Origin=OfPoint(b.Origin),BasisX=OfVector(b.BasisX),BasisY=OfVector(b.BasisY),BasisZ=OfVector(b.BasisZ)};
  public Transform Inverse {get {var r=new Transform{BasisX=new XYZ(BasisX.X,BasisY.X,BasisZ.X),BasisY=new XYZ(BasisX.Y,BasisY.Y,BasisZ.Y),BasisZ=new XYZ(BasisX.Z,BasisY.Z,BasisZ.Z)};r.Origin=r.OfVector(-1*Origin);return r;}}
 }
 public class ElementId {public long Value;public ElementId(long v){Value=v;} public static ElementId InvalidElementId=new ElementId(-1); public static bool operator ==(ElementId a,ElementId b)=>ReferenceEquals(a,b)||(a is not null&&b is not null&&a.Value==b.Value);public static bool operator !=(ElementId a,ElementId b)=>!(a==b);public override bool Equals(object o)=>o is ElementId e&&e==this;public override int GetHashCode()=>Value.GetHashCode();public override string ToString()=>Value.ToString();}
 public class Reference {public ElementId ElementId,LinkedElementId;public string Stable;public Reference Local;public Reference CreateReferenceInLink()=>Local;public string ConvertToStableRepresentation(Document d)=>Stable;}
 public class Document {public string Title="Fixture"; public Dictionary<long,Element> Elements=new();public Element GetElement(ElementId id)=>id!=null&&Elements.TryGetValue(id.Value,out var e)?e:null;}
 public class Category {public ElementId Id;public string Name;}
 public enum BuiltInCategory {OST_Walls=1,OST_Ceilings,OST_Floors,OST_Roofs,OST_Ramps,OST_Stairs,OST_StairsRuns,OST_StairsLandings,OST_StructuralFoundation}
 public class Element {public ElementId Id=new ElementId(1);public string Name="Fixture",UniqueId=Guid.NewGuid().ToString();public Document Document=new Document();public GeometryElement Geometry;public Category Category;public GeometryElement get_Geometry(Options o)=>Geometry;public BoundingBoxXYZ get_BoundingBox(object view)=>new BoundingBoxXYZ{Min=new XYZ(-10000,-10000,-10000),Max=new XYZ(10000,10000,10000)};}
 public class Wall:Element {} public class Floor:Element {} public class RoofBase:Element {} public class Level:Element {}
 public class LocationPoint {public XYZ Point;}
 public class FamilyInstance:Element {public Element Host;public Reference HostFace;public object Location;}
 public class RevitLinkInstance:Element {public Document Linked;public Transform Transform=Transform.Identity;public Document GetLinkDocument()=>Linked;public Transform GetTotalTransform()=>Transform;}
 public class BoundingBoxXYZ {public XYZ Min,Max;public Transform Transform=Transform.Identity;}
 public class Options:IDisposable {public bool ComputeReferences,IncludeNonVisibleObjects;public void Dispose(){}}
 public class GeometryObject {}
 public class GeometryElement:List<GeometryObject> {}
 public class GeometryInstance:GeometryObject {public GeometryElement Symbol;public Transform Transform=Transform.Identity;public GeometryElement GetSymbolGeometry()=>Symbol;}
 public class Solid:GeometryObject {public List<Face> Faces=new();}
 public class UV {public double U,V;public UV(double u,double v){U=u;V=v;}}
 public class IntersectionResult {public XYZ XYZPoint;public UV UVPoint;}
 public class Face:GeometryObject {
  public Reference Reference;public double Lower=0,Upper=10;public bool Hole,Horizontal;
  public virtual bool IsInside(UV p)=>p.U>=-2&&p.U<=2&&p.V>=Lower&&p.V<=Upper&&!(Hole&&p.V>2&&p.V<5);
  public virtual IntersectionResult Project(XYZ p){var uv=Horizontal?new UV(p.X,p.Y):new UV(p.Y,p.Z);return IsInside(uv)?new IntersectionResult{XYZPoint=Horizontal?new XYZ(p.X,p.Y,0):new XYZ(0,p.Y,p.Z),UVPoint=uv}:null;}
  public virtual XYZ ComputeNormal(UV uv)=>Horizontal?new XYZ(0,0,1):new XYZ(1,0,0);
 }
}

// Test-only API boundary. This is not a Revit simulator and is NEVER shipped in the installer.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace System.Windows.Media { public class ImageSource {} }
namespace Autodesk.Revit.DB {
 public class ElementId : IEquatable<ElementId> {
  public long Value; public ElementId(long v){Value=v;} public static readonly ElementId InvalidElementId=new(-1);
  public bool Equals(ElementId e)=>e!=null&&Value==e.Value; public override bool Equals(object o)=>o is ElementId e&&Equals(e);
  public override int GetHashCode()=>Value.GetHashCode(); public static bool operator==(ElementId a,ElementId b)=>object.Equals(a,b); public static bool operator!=(ElementId a,ElementId b)=>!object.Equals(a,b);
 }
 public class Element { public ElementId TypeId{get;set;} public virtual ElementId GetTypeId()=>TypeId; public ElementId Id{get;set;}=new(1); public string UniqueId{get;set;}=Guid.NewGuid().ToString();public string Name{get;set;}="element"; public bool IsValidObject{get;set;}=true;public ElementId GroupId{get;set;}=ElementId.InvalidElementId;public ElementId OwnerViewId{get;set;}=ElementId.InvalidElementId;public Category Category{get;set;}=new();public Document Document{get;set;}
  public bool ViewSpecific=>OwnerViewId!=ElementId.InvalidElementId; public HashSet<long> VisibleInViews=new(); }
 public class Category{public string Name{get;set;}="category";public ElementId Id{get;set;}=new(100);}
 public class Family:Element{public bool IsInPlace{get;set;}}
 public class ElementType:Element{public string TypeFamilyName="";public virtual string FamilyName=>TypeFamilyName;}
 public class FamilySymbol:ElementType{public Family Family{get;set;}=new();public override string FamilyName=>Family.Name;}
 public class FamilyInstance:Element{public FamilySymbol Symbol{get;set;} public Autodesk.Revit.DB.Structure.StructuralType StructuralType{get;set;} public override ElementId GetTypeId()=>Symbol?.Id??TypeId;}
 public class View:Element{public bool IsTemplate{get;set;}public bool IsCallout{get;set;}public ElementId ParentId=ElementId.InvalidElementId;public ElementId GetCalloutParentId()=>ParentId;}
 // v4.2 native element kinds
 public class TextNote:Element{}
 public enum WallKind{Basic,Curtain,Stacked}
 public class WallType:ElementType{public WallKind Kind{get;set;}}
 public class Wall:Element{public bool IsStackedWallMember{get;set;}public WallType WallType=>Document?.GetElement(GetTypeId()) as WallType;}
 public class Group:Element{}
 public class FilledRegion:Element{public bool IsMasking{get;set;}}
 public class Dimension:Element{}
 public class SpotDimension:Dimension{}
 public class ElementFilter{}
 public class ElementIdSetFilter:ElementFilter{public ICollection<ElementId> Ids;public ElementIdSetFilter(ICollection<ElementId> ids){Ids=ids;}}
 public class SpatialElementTag:Element{}
 public class AreaTag:SpatialElementTag{public FamilySymbol AreaTagType{get;set;} public override ElementId GetTypeId()=>AreaTagType?.Id;}
 public class IndependentTag:Element{public FamilySymbol TagType{get;set;} public List<ElementId> Tagged=new(); public ICollection<ElementId> GetTaggedLocalElementIds()=>Tagged; public override ElementId GetTypeId()=>TagType?.Id;}
 public class GraphicsStyle:Element{}
 public class Curve{}
 public class Line:Curve{}
 public class CurveElement:Element{public Curve GeometryCurve{get;set;}=new Line();public Element LineStyle{get;set;}}
 public class DetailCurve:CurveElement{}
 public class ModelCurve:CurveElement{}
 public class ModelPath{}
 public static class ModelPathUtils{public static string ConvertModelPathToUserVisiblePath(ModelPath p)=>"central";}
 public class Document {
  public bool IsValidObject{get;set;}=true;public bool IsFamilyDocument{get;set;}public bool IsLinked{get;set;}public bool IsWorkshared{get;set;}
  public Element ProjectInformation{get;set;}=new(){UniqueId="test-project"};public string PathName{get;set;}="test.rvt";public string Title{get;set;}="test";public Guid CreationGUID{get;set;}=Guid.NewGuid();
  public List<Element> Elements=new();public ModelPath GetWorksharingCentralModelPath()=>null;
  public Element GetElement(string uid)=>Elements.FirstOrDefault(x=>x.UniqueId==uid);public Element GetElement(ElementId id)=>Elements.FirstOrDefault(x=>x.Id==id);
  public T Add<T>(T e)where T:Element{e.Document=this;Elements.Add(e);return e;}
 }
 public class FilteredElementCollector:IEnumerable<Element>{IEnumerable<Element> items;public FilteredElementCollector(Document d){items=d.Elements;}public FilteredElementCollector(Document d,ElementId view){items=d.Elements.Where(e=>e.OwnerViewId==view||e.VisibleInViews.Contains(view.Value));}public FilteredElementCollector OfClass(Type t){items=items.Where(e=>t.IsInstanceOfType(e));return this;}
  public FilteredElementCollector WhereElementIsNotElementType(){items=items.Where(e=>!(e is ElementType));return this;}
  public FilteredElementCollector WherePasses(ElementFilter f){if(f is ElementIdSetFilter s)items=items.Where(e=>s.Ids.Contains(e.Id));return this;}
  public FilteredElementCollector OfCategory(BuiltInCategory c){items=items.Where(e=>e.Category!=null&&e.Category.Id.Value==(long)c);return this;}public IEnumerator<Element> GetEnumerator()=>items.GetEnumerator();IEnumerator IEnumerable.GetEnumerator()=>GetEnumerator();}
 public enum BuiltInCategory{OST_ConduitFitting=-1,OST_CableTrayFitting=-2,OST_DuctFitting=-3,OST_PipeFitting=-4,OST_CurtainWallPanels=-5,OST_CurtainWallMullions=-6,OST_TitleBlocks=-7,OST_Lines=-8,OST_KeynoteTags=-9,
  OST_IOSModelGroups=-10,OST_IOSDetailGroups=-11,OST_SpotElevations=-12,OST_SpotCoordinates=-13,OST_SpotSlopes=-14,OST_Dimensions=-15,OST_DuctAccessory=-16,OST_PipeAccessory=-17,OST_StructuralColumns=-18,OST_Columns=-19,OST_StructuralFraming=-20,OST_Viewers=-21,OST_Constraints=-22,OST_DetailComponents=-23}
}
namespace Autodesk.Revit.DB.Structure {public enum StructuralType{NonStructural,Beam,Brace,Column,Footing,UnknownFraming}}
namespace Autodesk.Revit.DB.Electrical {public class Conduit:Autodesk.Revit.DB.Element{} public class CableTray:Autodesk.Revit.DB.Element{}}
namespace Autodesk.Revit.DB.Plumbing {public class Pipe:Autodesk.Revit.DB.Element{} public class FlexPipe:Autodesk.Revit.DB.Element{}}
namespace Autodesk.Revit.DB.Architecture {public class Stairs:Autodesk.Revit.DB.Element{} public class Railing:Autodesk.Revit.DB.Element{public Autodesk.Revit.DB.ElementId HostId{get;set;}=Autodesk.Revit.DB.ElementId.InvalidElementId;}}
namespace Autodesk.Revit.DB.Architecture {public class RoomTagType:Autodesk.Revit.DB.FamilySymbol{} public class RoomTag:Autodesk.Revit.DB.SpatialElementTag{public RoomTagType RoomTagType{get;set;} public override Autodesk.Revit.DB.ElementId GetTypeId()=>RoomTagType.Id;}}
namespace Autodesk.Revit.DB.Mechanical {public class Duct:Autodesk.Revit.DB.Element{} public class FlexDuct:Autodesk.Revit.DB.Element{}}
namespace Autodesk.Revit.DB.Mechanical {public class SpaceTag:Autodesk.Revit.DB.SpatialElementTag{public Autodesk.Revit.DB.FamilySymbol SpaceTagType{get;set;} public override Autodesk.Revit.DB.ElementId GetTypeId()=>SpaceTagType?.Id;}}
namespace Autodesk.Revit.DB.Events {
 public enum UndoOperation{TransactionCommitted,TransactionUndone,TransactionRedone}
 public class DocumentChangedEventArgs:EventArgs {public UndoOperation Operation{get;set;} public Autodesk.Revit.DB.Document Doc;public ICollection<Autodesk.Revit.DB.ElementId> Added;public Autodesk.Revit.DB.Document GetDocument()=>Doc;public ICollection<Autodesk.Revit.DB.ElementId> GetAddedElementIds()=>Added;}
}
namespace Autodesk.Revit.ApplicationServices {
 public class ControlledApplication{public event EventHandler<Autodesk.Revit.DB.Events.DocumentChangedEventArgs> DocumentChanged;public void Emit(Autodesk.Revit.DB.Events.DocumentChangedEventArgs e)=>DocumentChanged?.Invoke(this,e);}
}
namespace Autodesk.Revit.UI {
 using Autodesk.Revit.DB;
 public enum Result{Succeeded,Cancelled,Failed}public enum PostableCommand{RoomTag,CreateSimilar,TagByCategory}
 public class RevitCommandId{public PostableCommand Command;public static RevitCommandId LookupPostableCommandId(PostableCommand c)=>new(){Command=c};}
 public class Selection{public ICollection<ElementId> Ids=new List<ElementId>();public ICollection<ElementId> GetElementIds()=>Ids.ToList();public void SetElementIds(ICollection<ElementId> ids){Ids=ids.ToList();}}
 public class UIDocument {public Document Document{get;set;}public View ActiveView{get;set;}public Selection Selection=new();public bool CanPlace=true;public bool ThrowOnQueue;public ElementType Queued;public int QueueCalls;public bool CanPlaceElementType(ElementType t)=>CanPlace;public void PostRequestForElementTypePlacement(ElementType t){QueueCalls++;if(ThrowOnQueue)throw new InvalidOperationException("queue failure");Queued=t;}}
 public class UIApplication{public UIDocument ActiveUIDocument{get;set;}public bool CanRoom=true,CanSimilar=true,CanTag=true,ThrowOnPost;public PostableCommand? Posted;public bool CanPostCommand(RevitCommandId id)=>id.Command==PostableCommand.RoomTag?CanRoom:id.Command==PostableCommand.TagByCategory?CanTag:CanSimilar;public void PostCommand(RevitCommandId id){if(ThrowOnPost)throw new InvalidOperationException("post failure");Posted=id.Command;}}
 public class UIControlledApplication{public Autodesk.Revit.ApplicationServices.ControlledApplication ControlledApplication=new();}
 public enum TaskDialogCommonButtons{Close}public class TaskDialog{public TaskDialog(string s){}public string MainInstruction{get;set;}public string MainContent{get;set;}public TaskDialogCommonButtons CommonButtons{get;set;}public void Show(){}}
}
namespace EK.LastSimilar.UI{public static class CategoryIconFactory{public static System.Windows.Media.ImageSource Create(EK.LastSimilar.Services.RecentTypeState s,bool dark)=>null;}}
namespace EK.LastSimilar.Services {
 using Autodesk.Revit.DB;using Autodesk.Revit.UI;using Autodesk.Revit.DB.Events;
 public static class RunLog{public static bool Enabled=false;public static string FilePath="test";public static List<string> Lines=new();public static void Add(string s)=>Lines.Add(s);}
 public enum HostKind{Wall,VerticalFace,Other}public class HostInfo{public HostKind Kind=HostKind.Other;public bool IsLinked;}
 public static class HostClassifier{public static HostInfo Classify(FamilyInstance f)=>new();}
 public static class LevelHeightService{public static int Calls;public static double GetHeightAboveLevelUnder(FamilyInstance f){Calls++;return 0;}public static string MmText(double d)=>d.ToString();}
 public static class DiagnosticsProbe{public static void TrackerEvent(Document d,DocumentChangedEventArgs e,FamilyInstance f){}}
 public class PlacementOutcome {public int Placed=0,WallCorrected=0,WallAlreadyOk=0,WallSkipped=0,WallFailed=0,CeilingUntouched=0,EquipmentCorrected=0,OtherUntouched=0,OtherFailed=0,OtherTypeAdded=0;public bool AnyDocumentChange=false;public string PromptError="",RequestedTypeName="";public List<string> Problems=new();public List<ElementId> PlacedIds=new();}
 // v4.2 test boundaries: the real VisibilityCheck shows Revit UI; line placement is covered elsewhere.
 public static class VisibilityCheck{public static int Reports;public static void ReportPlaced(Document d,View v,ICollection<ElementId> ids,string what){Reports++;}}
 public static class LineSimilarService{public static int Calls;public static Result Start(UIApplication a,RecentResolvedItem i){Calls++;return Result.Succeeded;}}
 public static class PlacementService{public static int Calls;public static bool IsSessionActive=false,IsListenerAttached=false;public static bool IsActiveSessionType(FamilyInstance f)=>false;public static bool IsEligibleFamilyInstance(FamilyInstance f)=>f!=null;public static PlacementOutcome PlaceAndFinalize(UIApplication a,FamilySymbol s,RecentTypeState e,StateSession session){Calls++;return new();}}
}

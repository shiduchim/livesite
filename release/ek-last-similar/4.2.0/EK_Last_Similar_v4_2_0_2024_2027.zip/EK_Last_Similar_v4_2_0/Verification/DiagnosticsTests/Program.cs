using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using EK.LastSimilar.Services;
namespace EK.LastSimilar.Services {
 internal static class StateStore { public static string FolderPath = Environment.GetEnvironmentVariable("EK_TEST_LOG_ROOT"); }
}
class Program {
 static int passed;
 static void Check(bool condition,string description) { if(!condition) throw new Exception(description); Console.WriteLine("PASS " + description); passed++; }
 static int Main(string[] args) {
  try {
   if(args.Length>0 && args[0]=="worker") {
    RunLog.ConfigureRuntime("2026","test-build");RunLog.SetEnabled(true);RunLog.Begin("Worker");
    for(int i=0;i<150;i++) RunLog.Add("WORKER_EVENT_"+i);
    RunLog.Flush();Console.WriteLine(RunLog.SessionFilePath);return 0;
   }
   string root=Path.Combine(Path.GetTempPath(),"ek-diagnostics-test-"+Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
   StateStore.FolderPath=Path.Combine(root,"disabled");
   RunLog.SetEnabled(false);RunLog.Begin("Disabled");RunLog.Add("hidden");RunLog.Flush();
   Check(!Directory.Exists(StateStore.FolderPath),"disabled diagnostics write no files");
   StateStore.FolderPath=Path.Combine(root,"enabled");RunLog.ConfigureRuntime("2025","test-build");RunLog.SetEnabled(true);RunLog.Begin("LL");RunLog.Add("BEFORE_FLUSH");
   string text=File.ReadAllText(RunLog.SessionFilePath);
   Check(text.Contains("BEFORE_FLUSH"),"command records persist before command end");
   Check(text.Split('\n').Where(l=>l.Trim().Length>0).All(l=>l.Contains("pid=")&&l.Contains("revit=2025/test-build")&&l.Contains("ek=4.2.0.0")&&l.Contains("load=")&&l.Contains("run=")),"every record identifies runtime, process, load and run");
   Check(RunLog.InCommand && !RunLog.Identity.EndsWith("run=none"),"active command gets a correlation id");
   RunLog.Flush();RunLog.Add("AFTER_FLUSH");
   Check(!RunLog.InCommand&&RunLog.Identity.EndsWith("run=none"),"command end clears correlation id");
   Check(File.ReadAllText(RunLog.SessionFilePath).Split('\n').Single(l=>l.Contains("AFTER_FLUSH")).Contains("[background]"),"passive records labeled background");
   RunLog.Begin("Toggle");RunLog.SetEnabled(false);long size=new FileInfo(RunLog.SessionFilePath).Length;RunLog.Add("MUST_NOT_APPEAR");RunLog.Flush();
   Check(new FileInfo(RunLog.SessionFilePath).Length==size&&!RunLog.InCommand&&RunLog.Identity.EndsWith("run=none"),"disable mid-command stops writes and resets correlation");
   RunLog.SetEnabled(true);RunLog.Add("RESUMED");Check(File.ReadAllText(RunLog.SessionFilePath).Contains("RESUMED"),"diagnostics can be re-enabled");
   string blocker=Path.Combine(root,"not-a-folder");File.WriteAllText(blocker,"x");StateStore.FolderPath=blocker;RunLog.Begin("IO failure");RunLog.Add("failure");RunLog.Flush();Check(true,"logging IO failures never escape");
   StateStore.FolderPath=Path.Combine(root,"parallel"); Directory.CreateDirectory(StateStore.FolderPath);
   string dotnet=Environment.ProcessPath; string dll=typeof(Program).Assembly.Location;
   Process StartWorker(){var info=new ProcessStartInfo(dotnet){RedirectStandardOutput=true,RedirectStandardError=true};info.ArgumentList.Add(dll);info.ArgumentList.Add("worker");info.Environment["EK_TEST_LOG_ROOT"]=StateStore.FolderPath;return Process.Start(info);}
   using(var a=StartWorker())using(var b=StartWorker()) {a.WaitForExit();b.WaitForExit();Check(a.ExitCode==0&&b.ExitCode==0,"concurrent worker processes succeed");}
   var traces=Directory.GetFiles(Path.Combine(StateStore.FolderPath,"Diagnostics"),"*.log");
   Check(traces.Length==2&&traces.All(f=>File.ReadAllLines(f).Count(l=>l.Contains("WORKER_EVENT_"))==150),"independent process traces retain every event under concurrent writes");
   string xml=Path.Combine(root,"KeyboardShortcuts.xml");
   File.WriteAllText(xml,"<Shortcuts><ShortcutItem CommandName='Other' Shortcuts='AA#LL' CommandId='native'/><ShortcutItem CommandName='Last Similar' Shortcuts='LS' CommandId='CustomCtrl_%CustomCtrl_%EK%Placement%EK_LastSimilar'/><ShortcutItem CommandName='Ball' Shortcuts='ALL'/><ShortcutItem CommandName='Print' Shortcuts='PP'/></Shortcuts>");
   var rows=DiagnosticFiles.ShortcutRows(xml).ToArray();Check(rows.Length==2&&rows[0].Contains("native")&&rows[1].Contains("EK_LastSimilar"),"shortcut scan catches duplicate LL binding and EK command identity without ALL false positives");
   File.WriteAllText(xml,"<!DOCTYPE foo [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><foo a='&xxe;'/>");bool rejected=false;try{DiagnosticFiles.ShortcutRows(xml).ToArray();}catch(System.Xml.XmlException){rejected=true;}Check(rejected,"shortcut XML refuses DTD and external entities");
   string journal="unrelated model data\nJrn.Command \"Ribbon\", _\n \"External command: EK.LastSimilar.LastSimilarCommand\"\nJrn.Data \"secret\"\n' EKLS_DIAG pid=123 PROMPT ENTER\nJrn.Command \"Internal\", \"ID_CREATE_SIMILAR\"\n";
   var commands=DiagnosticFiles.JournalCommands(journal).ToArray();Check(commands.Length==4&&commands[1].Contains("LastSimilarCommand")&&!string.Join("",commands).Contains("secret"),"journal captures multiline command identity and markers while omitting unrelated data");
   foreach(var encoding in new[]{Encoding.UTF8,Encoding.Unicode,Encoding.BigEndianUnicode}) {
    string file=Path.Combine(root,"journal-"+encoding.CodePage+".txt");File.WriteAllText(file,new string('a',2000)+"\n"+journal,encoding);
    Check(DiagnosticFiles.JournalCommands(DiagnosticFiles.ReadTail(file,900)).SequenceEqual(commands),"journal tail detects encoding "+encoding.WebName);
   }
   StateStore.FolderPath=Path.Combine(root,"trim");RunLog.Begin("Large");for(int i=0;i<220;i++)RunLog.Add("LARGE_"+i+new string('a',10000));RunLog.Flush();
   Check(new FileInfo(RunLog.SessionFilePath).Length<1536*1024&&File.ReadAllText(RunLog.SessionFilePath).Contains("LARGE_219"),"rolling trace is bounded and retains newest records");
   Console.WriteLine("TOTAL PASS "+passed);Directory.Delete(root,true);return 0;
  }catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
 }
}

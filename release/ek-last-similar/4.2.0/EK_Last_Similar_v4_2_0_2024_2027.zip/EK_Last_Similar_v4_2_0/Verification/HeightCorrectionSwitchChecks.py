"""Offline structural smoke checks for v4.2.0.0 (not a Revit execution test)."""
from pathlib import Path
from xml.etree import ElementTree

payload = Path(__file__).resolve().parent.parent / "_Payload"
read = lambda path: (payload / path).read_text(encoding="utf-8")
models = read("Services/StateModels.cs")
store = read("Services/StateStore.cs")
placement = read("Services/PlacementService.cs")
settings = read("UI/SettingsWindow.xaml.cs")
installer = read("Install-EKLastSimilar.ps1")
ui = ElementTree.parse(payload / "UI/SettingsWindow.xaml")
assert 'HeightCorrectionsEnabled { get; set; } = true' in models
assert 'HeightCorrectionEnabled { get; set; } = true' in models
assert 'GetHeightCorrectionsEnabled()' in store
assert 'SaveHeightCorrectionsEnabled(bool enabled)' in store
assert 'HeightCorrectionEnabled = e.HeightCorrectionEnabled' in store
assert 'e.HeightCorrectionEnabled = !RecentItemKinds.HasNoHeight(snapshot.ItemKind)' in store
assert 'globalHeightCorrectionsEnabled && entry?.HeightCorrectionEnabled != false' in placement
assert 'if (!adjustHeights)' in placement
assert 'NO - automatic height correction is disabled' in placement
assert placement.index('if (!adjustHeights)') < placement.index('HostInfo host = HostClassifier.Classify(fi);')
assert 'GlobalHeightCorrectionCheck.IsChecked = StateStore.GetHeightCorrectionsEnabled()' in settings
assert 'StateStore.SaveHeightCorrectionsEnabled(GlobalHeightCorrectionCheck.IsChecked == true)' in settings
assert 'TypeHeightCorrectionCheck.IsChecked = state.HeightCorrectionEnabled != false' in settings
assert 'state.HeightCorrectionEnabled = TypeHeightCorrectionCheck.IsChecked == true' in settings
assert 'bool enforce = validate && state.HeightCorrectionEnabled != false;' in settings
assert 'if (!state.HeightCorrectionEnabled)' not in settings
assert 'item.State.HeightCorrectionEnabled != false' in settings
assert "Write-Log $buildLine" in installer
assert "Write-Host $buildLine" not in installer
assert "$AppVersion = '4.2.0.0'" in installer
xname = "{http://schemas.microsoft.com/winfx/2006/xaml}Name"
controls = [x.attrib.get(xname) for x in ui.iter()]
assert controls.count('GlobalHeightCorrectionCheck') == 1
assert controls.count('TypeHeightCorrectionCheck') == 1
assert controls.count('LastHeightRadio') == 1
assert controls.count('FixedHeightRadio') == 1
# 4.0.5.0 layout: global options on the General tab, per-type options beside the list.
for name in ('HeaderTitle', 'RecentList', 'SelectedTitle', 'SelectedSubtitle', 'FavoriteCheck',
             'LearnedText', 'HeightBox', 'UseThumbnailsCheck', 'ThumbnailSizeBox', 'DiagnosticsCheck'):
    assert controls.count(name) == 1, name
tabs = [x for x in ui.iter() if x.tag.endswith('}TabItem')]
assert [t.attrib['Header'] for t in tabs] == ['Recent types', 'General']
general = [x.attrib.get(xname) for x in tabs[1].iter()]
assert all(n in general for n in ('GlobalHeightCorrectionCheck', 'UseThumbnailsCheck', 'ThumbnailSizeBox', 'DiagnosticsCheck'))
types = [x.attrib.get(xname) for x in tabs[0].iter()]
assert all(n in types for n in ('RecentList', 'FavoriteCheck', 'TypeHeightCorrectionCheck', 'LastHeightRadio', 'FixedHeightRadio', 'HeightBox'))
print('PASS: settings, serialized defaults, UI, correction gates and quiet installer (structural checks)')
# 4.2.0: native elements never reach the family/height workflow.
runner = read("CommandRunner.cs")
assert runner.index('ElementSimilarService.KindForFamilySymbol(symbol) != null') < runner.index('PlacementService.PlaceAndFinalize')
assert 'public static bool HasNoHeight(string kind)' in models and 'IsElement(kind)' in models
assert controls.count('WarnHiddenCheck') == 1
print('PASS: 4.2.0 native elements bypass height correction; warning option present (structural checks)')

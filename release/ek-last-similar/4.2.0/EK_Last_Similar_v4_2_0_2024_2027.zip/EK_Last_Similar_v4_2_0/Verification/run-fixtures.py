"""Run deterministic checks, not Revit integration tests. Requires Linux and .NET 10."""
from pathlib import Path
import argparse, json, os, re, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('--dotnet',default='dotnet');a=p.parse_args()
if os.name=='nt': raise SystemExit('Run these isolated fixtures on Linux; use Revit for Windows integration checks.')
root=Path(__file__).resolve().parent
listing=subprocess.check_output([a.dotnet,'--list-runtimes'],text=True)
versions=re.findall(r'^Microsoft.NETCore.App (10\.\d+\.\d+) ',listing,re.M)
if not versions: raise SystemExit('.NET 10 runtime is required.')
version=max(versions,key=lambda s:tuple(map(int,s.split('.'))))
with tempfile.TemporaryDirectory(prefix='ek-fixtures-') as scratch:
    state=Path(scratch)/'state';state.mkdir()
    env=dict(os.environ,XDG_CONFIG_HOME=str(state),EK_TEST_STATE_ROOT=str(state),DOTNET_CLI_HOME=str(Path(scratch)/'dotnet-home'))
    for name,project in [('FaceTests','FaceTests'),('RoomTagTests','RoomTagTests'),('DiagnosticsTests','DiagnosticsTests')]:
        folder=root/name
        subprocess.run([a.dotnet,'build',str(folder/(project+'.csproj')),'-c','Release','-v:quiet'],env=env,check=True)
        dll=folder/'bin/Release/net10.0'/(project+'.dll')
        dll.with_suffix('.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'tfm':'net10.0','framework':{'name':'Microsoft.NETCore.App','version':version}}}))
        subprocess.run([a.dotnet,str(dll)],env=env,check=True)

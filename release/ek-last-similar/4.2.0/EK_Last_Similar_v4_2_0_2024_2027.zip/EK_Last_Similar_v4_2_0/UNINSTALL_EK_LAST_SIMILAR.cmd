@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_Payload\UNINSTALL_EK_LAST_SIMILAR_ALL.cmd"
exit /b %errorlevel%

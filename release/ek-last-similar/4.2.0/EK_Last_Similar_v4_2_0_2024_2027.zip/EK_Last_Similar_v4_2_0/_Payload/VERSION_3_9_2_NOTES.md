# EK Last Similar 3.9.2

Rotation-safe wall height correction:

- After native Revit placement ends, the tool snapshots each new wall item's final:
  - LocationPoint rotation
  - FacingOrientation
  - HandOrientation
  - FacingFlipped
  - HandFlipped
  - Mirrored
- The normal Schedule Level + height correction then runs.
- Before committing, the tool verifies that none of those orientation values changed.
- If Revit changed rotation/flip/mirror during the level/height edit, that individual
  correction transaction is rolled back. The user's placed rotation is preserved.

Important:
- This does not copy an absolute angle from one wall to another.
- It preserves the rotation the user chose for each actual placement.
- Ceiling, linked-host, history, Recent 5, and Settings logic are unchanged.

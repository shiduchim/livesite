# EK Last Similar 4.0.0 — Straight Lines

New:
- Straight Detail Lines and Model Lines now participate in true Last Similar history.
- Line style is remembered, e.g. `Grounding`.
- Last Similar (`LL`) starts Revit's native Create Similar for the remembered line.
- Recent 5 mixes family types and line styles in true placement order.
- Lines use a simple line glyph; family thumbnail behavior is unchanged.
- Settings remains family-only because wall-height settings do not apply to lines.

How it works:
- The passive read-only tracker records a committed straight DetailCurve/ModelCurve.
- History key is line kind + GraphicsStyle.UniqueId, so Detail Line `Grounding`
  and Model Line `Grounding` are distinct recent items.
- The actual source line UniqueId is remembered.
- When LL is pressed, EK temporarily selects a matching existing line internally and
  posts Revit's native Create Similar command. This preserves Revit's own snaps,
  temporary dimensions, chain behavior, and exact line style.
- The internal selection does NOT define Last. Only a real committed draw/placement does.

Fallback:
- If the exact source line no longer exists, EK looks for another matching line in
  the active view (or anywhere in the model for Model Lines).
- If no matching source line exists at all, EK asks the user to draw one normally once.

Scope:
- Straight lines only in 4.0.0. Arcs/splines are deliberately not tracked yet.
- All 3.9.5 family placement, height, linked-host, Recent 5, troubleshooting,
  and Settings behavior is otherwise unchanged.

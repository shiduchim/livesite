# EK Last Similar 3.2 - change notes (max review of v3.1)

## Critical fixes
1. **Placed instances could be rolled back.** If you switched type in the Properties palette
   during a Last Similar run and placed only that other type, the command returned
   Cancelled, and Revit rolls back everything a cancelled command did - your instances
   vanished. The command now returns Succeeded whenever anything was committed during
   placement; Cancelled only when nothing happened at all.
2. **False "last placed" from automatic and bulk additions.** The tracker recorded every
   new instance of every commit. Drawing conduit/cable tray created fittings that became
   "Last"; paste/array/mirror of many items put random types into Recent 5; Synchronize /
   Reload Latest could record colleagues' placements; Duplicate-with-detailing and new
   sheets (title block) counted as placements. Now only a single fresh placement counts
   (see README "Listeners").
3. **History of one project leaked into others.** The history key was
   `ProjectInformation.UniqueId`, which is identical for every project created from the
   same template, so Last/Recent 5 mixed projects. Key now adds the central model path
   (workshared) or the document's creation GUID / path. Existing v3.1 history is migrated
   (copied) automatically on first use.
4. **State file could wipe all projects' history.** A locked (not corrupt) file was treated
   as corrupt, and the next save wrote a fresh file containing only the current project.
   Unreadable files are now never overwritten; corrupt files are kept and the last good
   copy (`.bak`) is restored.

## Important fixes
* Lost updates: saves wrote a whole project snapshot taken earlier, so a second Revit
  session working on the same project could lose newer history. Every write is now an
  atomic lock + read + change-one-thing + write.
* Installer required all four Revit versions; now builds and installs only those present,
  checks the .NET SDK version needed (10 for Revit 2027) before building, passes custom
  Revit paths to the build (they were checked but not used), stages outside
  ApplicationPlugins and swaps by rename so a failure keeps the previous install,
  writes PackageContents.xml for the built versions only, unblocks downloaded files,
  and removes old direct installs only after success.
* Batch files were LF-only (can break `call :label` in cmd); all are CRLF now.
* The tracker learned a pre-correction height while a Last Similar run was placing that
  same type; the run's own result is now the only source for that type's height.
* Twin levels (two levels at the same elevation): Schedule Level / Level could flip to the
  other one. The instance's current level is now kept.
* Settings "Remove" of the Last type left no Last; the next most recent placed type now
  becomes Last.
* If the tracker cannot start, Last Similar runs still record what they placed.

## UI
* Recent 5 rebuilt as a quiet context palette: 220-330 px wide (fits the names), compact
  two-line rows, no title bar or footer,
  type name in semibold, `Family / Category` in smaller muted text, shortcut digits on the
  right like menu accelerators, one subtle hover/keyboard highlight, Home/End added.
  Follows Revit's dark UI theme when Revit exposes it (read by reflection, safe on all years).
  Positioning, no-flash reveal, owner, focus and click-away mechanics are unchanged from v3.1.
* New icon set on one 20 px grid: switch plate, socket, bulb, flame, panel with bolt, box.
  Category decides first; names only refine Electrical Fixtures or unknown categories.
* Recent Heights: 640x500 instead of 860x640, master list + compact height editor,
  "Last" badge, star for favorites, learned height shown in plain text, compact buttons,
  Enter in the list places, Enter in the height box saves, Esc closes.

## Minor
* Bounded diagnostic log memory; dead selection helper removed; version 3.3.0 everywhere;
  README/notes rewritten; review prompt moved into `_Payload`.

## Intentionally unchanged
* The temporary placement listener design, correction rules, verification and per-instance
  rollback; linked wall/ceiling classification (HostFace + LinkedElementId + proximity proof).
* Ceiling items are never changed. Selection never defines Last.
* No Shift+F5 special case. No telemetry, no network code.
* `ElementId.Value` everywhere (no `IntegerValue`).

## Revit 2024 test checklist
1. Install with Revit closed; confirm EK > Placement in Revit 2024.
2. Place a face-based switch on a linked wall with Revit's own tool. Click Last Similar
   (nothing selected): the same type starts placing.
3. Place 3 switches; confirm Schedule Level = level below and the height you used in step 2.
4. Shift+click: palette beside the mouse, no flash; 1-5, arrows+Enter, Esc, click on the
   model and on another app all behave. Try near each screen edge and on a second monitor.
5. Draw a conduit run with bends; Last must NOT become a fitting.
6. Copy/paste 10 mixed devices; Recent 5 must not change.
7. In a Last Similar run, switch type in Properties and place only that type, then Esc:
   the instances must stay (v3.1 lost them).
8. Ceiling lights/smoke detectors (native and linked ceiling): level/elevation untouched.
9. Select an element, open Recent Heights, cancel: Last unchanged.
10. Open two projects made from the same template: each keeps its own Last/Recent 5.
11. `%APPDATA%\EK\LastSimilar\last-run.log` ends with `Listener attached: False`.

## Extra checks for 2025 / 2026 / 2027
* Each version shows the ribbon and places correctly from the same bundle.
* Revit 2026/2027 in dark theme: the palette is dark; ribbon icons readable.
* 2027: confirm the bundle loads from `%APPDATA%\Autodesk\ApplicationPlugins`.
* A second Revit version open at the same time: placements in both show up in each
  project's Recent 5, and the state file stays valid.


## v3.3 configurable Recent 5 key

- Recent 5 is no longer hard-coded to Shift.
- Settings now has a compact **Recent 5 key** chooser.
- Supported reliable Revit modifiers: Ctrl, Shift, Alt, Ctrl+Shift, Ctrl+Alt, Shift+Alt.
- Default is **Ctrl**, so a Revit shortcut such as Shift+F5 runs normal Last Similar.
- The modifier is global to EK Last Similar and does not affect per-project Recent/height history.

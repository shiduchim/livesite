# EK Last Similar v3.4

- Added a dedicated **Recent 5** Revit command so it can have its own reliable Revit keyboard shortcut.
- Keep `LL` assigned to **Last Similar**. Assign another shortcut such as `R5`, `55`, or `RF` to **Recent 5** in Revit Keyboard Shortcuts.
- Ctrl / Shift / Alt settings are now explicitly for **ribbon-click use only**.
- Recent 5 and Recent Heights are stacked as compact small ribbon buttons beside Last Similar.
- No placement, tracking, height, level, linked-host, ceiling-safety, or history logic was changed.

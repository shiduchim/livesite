using System;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EK.LastSimilar.Services;

namespace EK.LastSimilar
{
    internal static class CommandRunner
    {
        /// <summary>
        /// Runs placement and maps the outcome to a Result.
        /// IMPORTANT: Revit rolls back everything a command did when it returns Failed or
        /// Cancelled. So whenever ANYTHING was committed during the native placement
        /// (instances of the requested type, or of another type picked in the Properties
        /// palette, or any other edit) we return Succeeded, even if some height corrections
        /// were skipped or rolled back. Cancelled is returned only when nothing happened.
        /// </summary>
        public static Result Place(
            UIApplication uiapp,
            FamilySymbol symbol,
            RecentTypeState entry,
            StateSession session)
        {
            // RoomTagType derives from FamilySymbol, but RoomTag is an annotation.
            // Dispatch before entering the model-family capture/height workflow.
            if (symbol is Autodesk.Revit.DB.Architecture.RoomTagType roomTagType)
                return RoomTagSimilarService.Start(uiapp, roomTagType, entry);

            // v4.1: category / multi-category / material tags, Space Tags and Area Tags.
            // Tag types are FamilySymbols too, but they are never placed through the
            // model-family capture/height workflow.
            if (RecentItemKinds.IsTag(entry?.ItemKind))
                return TagSimilarService.Start(uiapp, symbol, entry);

            // v4.2: beams, braces, columns and duct/pipe accessories are placed with Revit's own
            // tool and are never height-corrected, whatever their history entry says.
            if (RecentItemKinds.IsElement(entry?.ItemKind) || ElementSimilarService.KindForFamilySymbol(symbol) != null)
                return ElementSimilarService.Start(uiapp, symbol, entry);

            View viewBefore = null;
            try { viewBefore = uiapp.ActiveUIDocument?.ActiveView; }
            catch { }

            PlacementOutcome outcome = PlacementService.PlaceAndFinalize(uiapp, symbol, entry, session);

            RunLog.Add(
                $"Summary: placed={outcome.Placed}, wallCorrected={outcome.WallCorrected}, " +
                $"wallAlreadyOk={outcome.WallAlreadyOk}, wallSkipped={outcome.WallSkipped}, " +
                $"wallFailed={outcome.WallFailed}, ceilingUntouched={outcome.CeilingUntouched}, " +
                $"equipmentCorrected={outcome.EquipmentCorrected}, otherUntouched={outcome.OtherUntouched}, " +
                $"otherFailed={outcome.OtherFailed}, otherTypePlaced={outcome.OtherTypeAdded}, " +
                $"reportedProblems={outcome.Problems.Count}, " +
                $"anyDocumentChange={outcome.AnyDocumentChange}, listenerAttached={PlacementService.IsListenerAttached}");

            if (outcome.Placed > 0 || outcome.AnyDocumentChange)
            {
                ReportProblemsIfAny(outcome);
                VisibilityCheck.ReportPlaced(uiapp.ActiveUIDocument?.Document, viewBefore, outcome.PlacedIds,
                    outcome.RequestedTypeName);
                return Result.Succeeded;
            }

            if (!string.IsNullOrWhiteSpace(outcome.PromptError))
            {
                SafeDialog(
                    "Could not place this type here.\n\n" + outcome.PromptError +
                    "\n\nTip: switch to a view where this family can be placed (e.g. a floor plan for wall/ceiling devices).");
            }

            // Nothing at all was committed during placement: let Revit discard the optional
            // "Activate Type" transaction. No placed element can be lost here.
            return Result.Cancelled;
        }

        private static void ReportProblemsIfAny(PlacementOutcome outcome)
        {
            // These are forensic/skipped-correction warnings, not fatal placement errors.
            // Keep normal use quiet; show them only when Troubleshooting is enabled.
            if (!RunLog.Enabled || outcome.Problems.Count == 0)
                return;

            var sb = new StringBuilder();
            string what = string.IsNullOrWhiteSpace(outcome.RequestedTypeName)
                ? ""
                : " of " + outcome.RequestedTypeName;
            string others = outcome.OtherTypeAdded > 0
                ? $" and {outcome.OtherTypeAdded} of other type(s)"
                : "";
            sb.AppendLine($"Placed {outcome.Placed} instance(s){what}{others}.");
            sb.AppendLine("These were NOT height-corrected and were left exactly as placed:");
            sb.AppendLine();

            int shown = 0;
            foreach (string p in outcome.Problems)
            {
                if (shown++ >= 6)
                {
                    sb.AppendLine($"... and {outcome.Problems.Count - 6} more.");
                    break;
                }
                sb.AppendLine("• " + p);
            }

            sb.AppendLine();
            sb.Append("Full details (newest run at the bottom): " + RunLog.FilePath);
            SafeDialog(sb.ToString());
        }

        /// <summary>
        /// v4.2: one entry point for any resolved history item (Last Similar, Recent 5, Settings).
        /// </summary>
        public static Result PlaceItem(UIApplication uiapp, RecentResolvedItem item, StateSession session)
        {
            if (item?.State == null)
                return Result.Cancelled;

            if (item.IsLine)
                return LineSimilarService.Start(uiapp, item);

            if (item.IsElement)
                return ElementSimilarService.Start(uiapp, item.ElementType, item.State);

            FamilySymbol symbol = item.Symbol;
            if (symbol == null || !symbol.IsValidObject)
                return Result.Cancelled;

            return Place(uiapp, symbol, item.State, session);
        }

        public static void SafeDialog(string text)
        {
            try
            {
                var td = new TaskDialog("EK Last Similar")
                {
                    MainInstruction = "EK Last Similar",
                    MainContent = text,
                    CommonButtons = TaskDialogCommonButtons.Close
                };
                td.Show();
            }
            catch { }
        }
    }
}

# ALL VERSION BUILD NOTE (v3.2)

One source, four builds:

| Revit | Target framework       | Configuration |
|-------|------------------------|---------------|
| 2024  | .NET Framework 4.8     | Release R24   |
| 2025  | .NET 8 (net8.0-windows)  | Release R25 |
| 2026  | .NET 8 (net8.0-windows)  | Release R26 |
| 2027  | .NET 10 (net10.0-windows)| Release R27 |

`Install-EKLastSimilar.ps1` (started by `INSTALL_EK_LAST_SIMILAR.cmd`):

* builds only the Revit versions installed on the PC (API path from `REVIT20xx_DIR`,
  `C:\Program Files\Autodesk\Revit 20xx`, or the Revit registry entry) and passes that
  path to MSBuild as `RevitApiPath_20xx`,
* needs the .NET 8 SDK (or newer) for 2024-2026 and the .NET 10 SDK if 2027 is present,
* stages the bundle in `%APPDATA%\Autodesk\EKLastSimilar.install-staging`, writes a
  `PackageContents.xml` that lists only the built versions, then swaps it into
  `%APPDATA%\Autodesk\ApplicationPlugins\EKLastSimilar.bundle` by rename
  (any failure keeps the previous install),
* only after success removes older direct installs
  (`%APPDATA%\Autodesk\Revit\Addins\20xx\EKLastSimilar.addin` and `...\EKLastSimilar\`).

Only `EKLastSimilar.dll` + the `.addin` are deployed per version. Revit 2025+ does not need
the generated `runtimeconfig.json`, and the add-in has no third-party dependencies.

Do not reintroduce `ElementId.IntegerValue` (removed in Revit 2026). Use `ElementId.Value`.

# EK Last Similar v4.0.1 — verified vertical hosts

Built on v4.0.0 Straight Lines release. Preserves the same installation method,
family placement, Recent 5, favorites, learned/fixed heights, line tools, shortkeys,
logging and opt-in troubleshooting. No history migration.

## Added

- The exact Revit host face is checked when a new face-hosted item is placed.
- Loaded linked Revit geometry is resolved with `CreateReferenceInLink` and the
  link transform; the same linked-element proximity safeguard remains.
- Curtain panels, columns, in-place / Generic Model faces, mullions and other
  verified near-vertical faces (including curved surfaces with a verifiable local normal) can receive the height correction.
- New vertical hosts use the existing wall-height rules (fixed vs learned).
- Pre-commit verification additionally confirms host identity, exact face
  reference, final point on the face (within 100 mm), target height and XY.
- Diagnostic logging explains why any correction is rejected or rolled back.

## Excluded deliberately

- Ceilings, floors, roofs, stairs, ramps and foundations, even where a side face
  might be nearly vertical; all other horizontal/sloped faces and unresolved links.
- Unhosted, level-based, grouped and detail placement remain under existing rules.
- Curved faces require a resolvable local normal at the device mounting point.

## Level behavior

As in 4.0.0, the base is the highest host-project level at or below the initial
placement Z. In 3D models with several closely spaced levels, place close to the
intended reference level. No speculative change to this rule in v4.0.1.

## Build/runtime limitation

The archive contains C# source plus the original cross-version PowerShell build
installer. This build environment does not have Revit DLLs or Windows, so final
API compilation and runtime placement tests occur on the user's Revit machine.
The installer builds all installed supported versions first and swaps the existing
add-in only after successful compilation.

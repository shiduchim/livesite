# EK Last Similar 3.9.2

## Fixed: Move to bottom
The previous implementation used only a boolean flag. Once multiple rows were
already in the bottom group, another click could not reliably become the actual
last row.

3.9 adds a Settings-only ordering timestamp. Every press of Move to bottom gets
a newer timestamp, so the selected row becomes the absolute last row immediately
and stays there after Save.

This never changes true Recent 5 placement chronology.

## Favorite behavior
Favorite now:
- shows the existing star,
- receives a subtle pale-gold row highlight,
- sorts near the top of the normal Settings rows,
- updates visually immediately when checked/unchecked.

Favorite does NOT:
- redefine Last Similar,
- alter true Recent 5 order,
- change placement history.

## Additional fix
Removed an accidental duplicate Save commit call.

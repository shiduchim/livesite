# EK Last Similar 3.9.2

UI unit change only:
- Settings fixed-height input is now centimeters.
- Learned-height display is now centimeters.
- Row status (Fixed / Last) is now centimeters.
- Internally, saved StandardHeightMm remains millimeters for full backward compatibility.
- Existing saved values therefore require no migration and keep exactly the same physical height.
- Placement/level/host correction logic is unchanged.

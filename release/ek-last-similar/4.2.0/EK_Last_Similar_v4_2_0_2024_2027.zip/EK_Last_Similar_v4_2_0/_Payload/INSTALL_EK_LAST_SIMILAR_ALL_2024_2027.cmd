@echo off
setlocal
title EK Last Similar - Install for Revit 2024-2027
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-EKLastSimilar.ps1"
set "RC=%ERRORLEVEL%"

echo.
pause
exit /b %RC%

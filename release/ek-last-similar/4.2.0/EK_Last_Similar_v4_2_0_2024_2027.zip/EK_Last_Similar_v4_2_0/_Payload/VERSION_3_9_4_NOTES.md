# EK Last Similar 4.0.0 - forensic fix for intermittent wall-height correction

Built from the 3.9.2 / "3.9.3" source (identical code). Revit 2024-2027, same installer.

## Symptom

Wall-height correction sometimes did not happen (also with a FIXED height), later worked
again, once put a device on the wrong level ("Level 11.0"), and seemed related to rotating
a light switch during placement.

## Findings (ranked)

1. **Silent skips.** Several paths left a new instance untouched WITHOUT any message:
   * an instance of a different type than the one the run started with (Type Selector
     changed during placement) - only a count in the log;
   * a requested-type instance whose host is not a proven wall: work plane / level,
     no host, a linked column / curtain panel / sweep / Parts / in-place wall, an
     unloaded or nested link - "untouched", no dialog;
   * placements made outside EK (native tool, Create Similar, copy) - EK never runs.
   And every command (even just opening Settings) OVERWROTE last-run.log, so the
   evidence was gone by the time anyone looked. This matches "stopped / worked again"
   and is independent of Fixed vs Last height. Manual rotation correlates with it:
   a switch hosted on a wall face orients itself; one placed on a work plane does not,
   so that is exactly when you reach for the spacebar.

2. **Strict rotation rollback still present.** `OrientationStillMatches` (added in 3.9.2)
   rolled back a correct height change if `LocationPoint.Rotation` read differently after
   the edit. That value is not a well-defined angle for instances hosted on a vertical
   face, especially after a 90-degree spacebar rotation. This was the only code path in
   which rotation itself could block a correction (always with a "rotation/orientation
   changed" dialog). The source given as 3.9.3 still contained it.

3. **Level choice.** Rule (kept): highest host level whose `ProjectElevation` is at or
   below the placed `LocationPoint.Z` (both internal coordinates; linked levels never
   used). "Level 11.0" is chosen when (a) Revit initially dropped the device above
   Level 11.0 (click height in a section/3D view, or a large "Elevation from Level"
   carried in the Properties palette), (b) Level 11.0 lies between the floor and the
   device (SSL/FFL pair, auxiliary level), or (c) Level 11.0 shares its elevation with
   the floor level and the device was not already on one of them: 3.9.2 then took the
   twin that came LAST in Revit's collector order (effectively arbitrary).

4. **Robustness gap.** An unexpected exception outside one element's own transaction
   would have aborted the loop and rolled back the whole correction group, undoing
   corrections already committed in the same run.

Ruled out (from code + Revit API behavior): capture timing, transaction names, Undo
filtering, listener detaching early, element recreation on rotation (a rotation is a
Modified event on the SAME id; spacebar rotation is part of the placement commit),
duplicate ids, learned-height state for Fixed types.

## Changes

* Orientation is logged before/after (Hand, Facing, flips, LocationPoint.Rotation) but
  never blocks a correction. EK still never writes rotation.
* Same-elevation levels are resolved deterministically: current Schedule Level, then the
  level of the view you placed in, then a Building Story level, then the lowest id.
  Levels are sorted by elevation, then id (no collector-order dependence).
* Each candidate is processed in its own try/catch; the correction group is closed
  safely; a correction whose transaction already committed is always reported as
  committed.
* No silent skips for what users read as "it did not work" (existing dialog):
  wall-hosted instances of another type; requested-type instances not on a wall face
  (work plane, column, unverified link...) when the type has a wall height set.
  Ceiling items are never reported.
* last-run.log is now a rolling log (about 1 MB, newest run at the bottom) with a full
  event trace and a per-candidate block; the passive tracker logs every placement it
  records, including ones EK does not adjust, as `[background] Tracker:` lines.

## Not changed (deliberately)

* What counts as a wall (still `Wall` class + Walls category, linked or native, with the
  nested-link proximity check). Widening it (in-place walls, Parts, columns) would
  weaken "unknown host => skip". The log now names the exact host class/category, so a
  real case can be decided later on evidence.
* The level rule itself, ceiling rule, exact-type rule, read-only listeners, detach before
  corrections, per-element transactions, Recent 5 and Settings UI.

## Reading the log

`%APPDATA%\EK\LastSimilar\last-run.log`, scroll to the bottom. Per new instance:
`Initial` (Z, Schedule Level, Elevation from Level), `Rotation`, `Host`,
`Target level` (with the rule used, same-elevation levels, next lower/higher),
`Target height`, `Note` lines, `Attempted`, `Result` (exact reason), `Transaction`,
`Final`, `Orientation`. Above them: one `[event n]` line per document change during the
placement, with `CAPTURED` / `NOT captured` per new instance.

# EK Last Similar 3.7.0

## UI changes
- Ribbon button text **Recent Heights** renamed to **Settings**.
- Settings actions **Remove from list / Set as Last / Place** moved above the height editor.
- **Save** moved to the bottom-right next to **Close**.
- Main Last Similar ribbon icon changed to a compact duplicate/click symbol: overlapping component cards with a small pointer.

## Thumbnail quality
- Thumbnail size remains the display-size setting.
- Revit is now asked for a cached **128 x 128** preview source regardless of display size.
- WPF downsamples that source with HighQuality bitmap scaling.
- This avoids enlarging a 20-40px source on high-DPI displays and should look much closer to Revit's Place Component browser.
- Missing previews still fall back to the simple category icon.

## Behavior unchanged
- True last-placed tracking, Recent 5 ordering, linked-wall handling, ceiling protection, and placement safety logic are unchanged.

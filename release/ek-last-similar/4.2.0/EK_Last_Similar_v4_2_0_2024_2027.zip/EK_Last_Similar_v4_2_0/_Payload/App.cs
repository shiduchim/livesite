using System;
using System.Linq;
using System.Reflection;
using Autodesk.Revit.UI;

namespace EK.LastSimilar
{
    public class App : IExternalApplication
    {
        private const string TabName = "EK";
        private const string PanelName = "Placement";

        public Result OnStartup(UIControlledApplication application)
        {
            try
            {
                try { application.CreateRibbonTab(TabName); }
                catch { /* tab already exists (other EK tools) */ }

                RibbonPanel panel = application.GetRibbonPanels(TabName)
                    .FirstOrDefault(p => string.Equals(p.Name, PanelName, StringComparison.OrdinalIgnoreCase));

                if (panel == null)
                    panel = application.CreateRibbonPanel(TabName, PanelName);

                string assembly = Assembly.GetExecutingAssembly().Location;

                var mainData = new PushButtonData(
                    "EK_LastSimilar",
                    "Last\nSimilar",
                    assembly,
                    "EK.LastSimilar.LastSimilarCommand");

                if (panel.AddItem(mainData) is PushButton mainButton)
                {
                    mainButton.ToolTip =
                        "Place the family type you placed last in this project.\n\n" +
                        "Use the Recent 5 command for your last 5 placed types.";
                    mainButton.LargeImage = UI.RibbonIconFactory.CreateMainIcon(32);
                    mainButton.Image = UI.RibbonIconFactory.CreateMainIcon(16);
                }

                var recentData = new PushButtonData(
                    "EK_LastSimilar_Recent5",
                    "Recent\n5",
                    assembly,
                    "EK.LastSimilar.RecentFiveCommand");

                var settingsData = new PushButtonData(
                    "EK_LastSimilar_Settings",
                    "Settings",
                    assembly,
                    "EK.LastSimilar.SettingsCommand");

                // Keep the panel compact: Recent 5 and Settings are stacked as
                // two small commands beside the main Last Similar button. Because
                // Recent 5 is a real Revit ribbon command, the user can assign it its
                // own Revit keyboard shortcut (for example R5) in Keyboard Shortcuts.
                var stacked = panel.AddStackedItems(recentData, settingsData);
                if (stacked != null && stacked.Count >= 2)
                {
                    PushButton recentButton = stacked[0] as PushButton;
                    PushButton settingsButton = stacked[1] as PushButton;

                    if (recentButton != null)
                    {
                        recentButton.ToolTip =
                            "Open your 5 most recently placed family types next to the mouse.\n\n" +
                            "You can assign this Recent 5 command its own Revit keyboard shortcut.";
                        recentButton.Image = UI.RibbonIconFactory.CreateRecentFiveIcon(16);
                        recentButton.LargeImage = UI.RibbonIconFactory.CreateRecentFiveIcon(32);
                    }

                    if (settingsButton != null)
                    {
                        settingsButton.ToolTip =
                            "Recent types: favorites and wall heights per type.\n" +
                            "General: automatic heights, Recent 5 thumbnails, troubleshooting.";
                        settingsButton.Image = UI.RibbonIconFactory.CreateSettingsIcon(16);
                        settingsButton.LargeImage = UI.RibbonIconFactory.CreateSettingsIcon(32);
                    }
                }

                // Troubleshooting is opt-in. Load it before the passive tracker starts
                // so background tracker diagnostics are also quiet when disabled.
                try { Services.RunLog.SetEnabled(Services.StateStore.GetDiagnosticsEnabled()); }
                catch { }

                // Passive read-only tracker: remembers only Family/Type/history.
                // It NEVER edits the Revit model or opens a transaction. A failure here must
                // not take the ribbon down: placement still works, it then records its own
                // placements only.
                Services.DiagnosticsProbe.Startup(application.ControlledApplication);
                try { Services.LastPlacedTracker.Start(application); }
                catch { }

                // v4.2 "not visible" warning for placements EK starts with Revit's own tools.
                // Revit raises Idling only when no tool is active, i.e. after the user finished.
                // The handler returns at once when nothing is pending; it is read-only.
                try { application.Idling += Services.VisibilityCheck.OnIdling; }
                catch { }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("EK Last Similar", "Could not create ribbon controls:\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            // Stop the passive read-only history tracker and also remove any temporary
            // placement listener as a final safety guard.
            Services.RunLog.Add("APPLICATION SHUTDOWN");
            Services.LastPlacedTracker.Stop();
            try { application.Idling -= Services.VisibilityCheck.OnIdling; }
            catch { }
            Services.PlacementService.DetachListener();
            return Result.Succeeded;
        }
    }
}

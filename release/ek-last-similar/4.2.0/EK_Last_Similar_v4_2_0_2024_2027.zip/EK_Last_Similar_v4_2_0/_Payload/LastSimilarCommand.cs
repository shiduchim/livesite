using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EK.LastSimilar.Services;
using EK.LastSimilar.UI;

namespace EK.LastSimilar
{
    [Transaction(TransactionMode.Manual)]
    public class LastSimilarCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            // Last Similar always means the true last type placed.
            // Recent 5 is a separate Revit command with its own keyboard shortcut.
            RunLog.SetEnabled(StateStore.GetDiagnosticsEnabled());
            RunLog.Begin("Last Similar");
            DiagnosticsProbe.CommandEntry(commandData.Application, "Last Similar");

            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                if (uidoc == null)
                    return Result.Cancelled;

                Document doc = uidoc.Document;
                StateSession session = StateStore.Open(doc);

                // Normal Last Similar ALWAYS means the last eligible thing actually placed:
                // either a family type or a straight Detail/Model Line style.
                // Current selection does not change Last.
                RecentResolvedItem last = StateStore.ResolveLastItem(session.Doc, doc);

                if (last == null || last.State == null)
                {
                    bool hasHistory = StateStore.GetRecentValid(session.Doc, doc, 1).Count > 0;
                    CommandRunner.SafeDialog(hasHistory
                        ? "The last placed item no longer exists in this project.\n\n" +
                          "Run Recent 5 to pick one of your recent items."
                        : "No eligible placement has been recorded for this project yet.\n\n" +
                          "Place a family, tag, text note, wall, duct, pipe, conduit, cable tray, stair, " +
                          "railing, group, callout, beam, column, region, dimension or spot elevation, " +
                          "or draw a Detail/Model Line normally in Revit, then click Last Similar again.");
                    return Result.Cancelled;
                }

                // Lines and native elements (walls, ducts, text, ...) start Revit's own tool;
                // families go through the placement/height workflow.
                // Do NOT mark the chosen item as Last merely because the command was invoked.
                // The passive tracker updates Last only when an item is actually placed/drawn.
                return CommandRunner.PlaceItem(uiapp, last, session);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                // Only reachable before placement starts.
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                // Only reachable before placement starts (placement itself never throws).
                RunLog.Add("Error: " + ex);
                CommandRunner.SafeDialog(ex.Message);
                return Result.Cancelled;
            }
            finally
            {
                // Belt and braces: guarantee no model listener survives this command.
                DiagnosticsProbe.CommandExit(commandData.Application, "Last Similar");
                PlacementService.DetachListener();
                RunLog.Add("Command end. Listener attached: " + PlacementService.IsListenerAttached);
                RunLog.Flush();
            }
        }
    }
}

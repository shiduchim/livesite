using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;

namespace EK.LastSimilar.Services
{
    // Optional forensic observations only. No transactions, commands, key hooks, selection
    // writes, parameter writes or change to placement lifetime. All entry points fail safely.
    internal static class DiagnosticsProbe
    {
        private static DateTime _lastEnvironmentUtc = DateTime.MinValue;

        internal static void Startup(ControlledApplication app)
        {
            try
            {
                RunLog.ConfigureRuntime(app.VersionNumber, app.VersionBuild);
                if (!RunLog.Enabled) return;
                RunLog.Add("APPLICATION STARTUP | " + AssemblyIdentity(typeof(DiagnosticsProbe).Assembly));
                EnvironmentSnapshot(app.VersionNumber, true);
                RunLog.Add("JOURNAL PATH: " + app.RecordingJournalFilename);
            }
            catch (Exception ex) { Error("startup", ex); }
        }

        internal static void CommandEntry(UIApplication uiapp, string command)
        {
            try
            {
                Application app = uiapp.Application;
                RunLog.ConfigureRuntime(app.VersionNumber, app.VersionBuild);
                if (!RunLog.Enabled) return;
                RunLog.Add("COMMAND ENTRY " + command + " | " + PlacementService.DiagnosticSessionState +
                    " | " + DocumentIdentity(uiapp.ActiveUIDocument?.Document));
                EnvironmentSnapshot(app.VersionNumber, true);
                JournalSnapshot(app);
                Marker(app, "COMMAND ENTRY " + command);
            }
            catch (Exception ex) { Error("command entry", ex); }
        }

        internal static void CommandExit(UIApplication uiapp, string command)
        {
            if (!RunLog.Enabled) return;
            try
            {
                // Also captures enabling diagnostics from the unchanged Settings window.
                RunLog.ConfigureRuntime(uiapp.Application.VersionNumber, uiapp.Application.VersionBuild);
                EnvironmentSnapshot(uiapp.Application.VersionNumber, false);
                RunLog.Add("COMMAND EXIT " + command + " | " + PlacementService.DiagnosticSessionState);
                Marker(uiapp.Application, "COMMAND EXIT " + command);
                JournalSnapshot(uiapp.Application);
            }
            catch (Exception ex) { Error("command exit", ex); }
        }

        internal static void SessionEvent(Document doc, string stage)
        {
            if (!RunLog.Enabled) return;
            try
            {
                RunLog.Add(stage + " | " + PlacementService.DiagnosticSessionState + " | " + DocumentIdentity(doc));
                Marker(doc.Application, stage);
            }
            catch (Exception ex) { Error("session event", ex); }
        }

        internal static void IgnoredDocument(Document actual, Document expected)
        {
            if (!RunLog.Enabled) return;
            try { RunLog.Add("CAPTURE ignored different document | actual " + DocumentIdentity(actual) +
                " | expected " + DocumentIdentity(expected)); }
            catch (Exception ex) { Error("document mismatch", ex); }
        }

        internal static void TrackerEvent(Document doc, DocumentChangedEventArgs args, FamilyInstance fi)
        {
            if (!RunLog.Enabled) return;
            try
            {
                RunLog.ConfigureRuntime(doc.Application.VersionNumber, doc.Application.VersionBuild);
                RunLog.Add("TRACKER EVENT | " + PlacementService.DiagnosticSessionState +
                    " matchesSessionType=" + PlacementService.IsActiveSessionType(fi) +
                    " | operation=" + args.Operation + " transactions=" + string.Join(";", args.GetTransactionNames()) +
                    " | " + DocumentIdentity(doc));
                PlacedInstance(fi, "TRACKER INSTANCE", !PlacementService.IsSessionActive);
            }
            catch (Exception ex) { Error("tracker event", ex); }
        }

        internal static void PlacedInstance(FamilyInstance fi, string stage, bool includeEnvironment)
        {
            if (!RunLog.Enabled) return;
            try
            {
                Document doc = fi.Document;
                RunLog.Add(stage + " id=" + fi.Id.Value + " uid=" + fi.UniqueId +
                    " type=" + fi.GetTypeId().Value + " family=" + fi.Symbol.FamilyName + " : " + fi.Symbol.Name +
                    " placement=" + fi.Symbol.Family.FamilyPlacementType +
                    " | " + DocumentIdentity(doc));
                RunLog.Add("INSTANCE STATE | " + LevelHeightService.DescribeState(doc, fi));
                RunLog.Add("INSTANCE ORIENTATION | " + OrientationInfo.Capture(fi).Describe());
                HostInfo hostInfo = HostClassifier.Classify(fi);
                RunLog.Add("HOST DETAIL | " + hostInfo + " | identity=" + hostInfo.HostIdentity +
                    " | stableFace=" + hostInfo.FaceStableReference);
                FaceDetails(fi);
                if (includeEnvironment)
                {
                    EnvironmentSnapshot(doc.Application.VersionNumber, false);
                    JournalSnapshot(doc.Application);
                }
            }
            catch (Exception ex) { Error("instance observation", ex); }
        }

        private static void FaceDetails(FamilyInstance fi)
        {
            try
            {
                if (HostFaceGeometry.TryResolve(fi, out HostFaceGeometry resolved, out string resolutionReason) &&
                    fi.Location is LocationPoint actual &&
                    resolved.TryProject(actual.Point, out XYZ projected, out XYZ modelNormal, out resolutionReason))
                    RunLog.Add("RESOLVED FACE | transform origin=" + Vec(resolved.FaceToModel.Origin) +
                        " modelNormal=" + Vec(modelNormal) + " projection distance mm=" +
                        LevelHeightService.MmText(actual.Point.DistanceTo(projected)));
                else RunLog.Add("RESOLVED FACE | unavailable: " + resolutionReason);
                RunLog.Add("RAW FACE COMPARISON | below excludes family/panel instance transforms; diagnostic comparison only");
                Reference reference = fi.HostFace;
                Element host = fi.Host;
                RunLog.Add("HOST REFERENCE | hostId=" + host?.Id + " hostClass=" + host?.GetType().FullName +
                    " referenceElement=" + reference?.ElementId + " linkedElement=" + reference?.LinkedElementId);
                if (reference == null || host == null || !(fi.Location is LocationPoint lp)) return;
                Transform transform = Transform.Identity;
                XYZ point = lp.Point;
                if (host is RevitLinkInstance link)
                {
                    transform = link.GetTotalTransform();
                    Document linked = link.GetLinkDocument();
                    host = linked?.GetElement(reference.LinkedElementId);
                    reference = reference.CreateReferenceInLink();
                    point = transform.Inverse.OfPoint(point);
                    RunLog.Add("LINK TRANSFORM | origin=" + Vec(transform.Origin) +
                        " X=" + Vec(transform.BasisX) + " Y=" + Vec(transform.BasisY) + " Z=" + Vec(transform.BasisZ));
                }
                Face face = host?.GetGeometryObjectFromReference(reference) as Face;
                if (face == null) { RunLog.Add("FACE DETAIL | unresolved geometry"); return; }
                IntersectionResult projection = face.Project(point);
                XYZ normal = face is PlanarFace plane ? plane.FaceNormal :
                    (projection?.UVPoint == null ? null : face.ComputeNormal(projection.UVPoint));
                RunLog.Add("FACE DETAIL | class=" + face.GetType().Name + " localNormal=" + Vec(normal) +
                    " modelNormal=" + Vec(normal == null ? null : transform.OfVector(normal).Normalize()) +
                    " projection=" + (projection == null ? "null/outside" :
                        "on face; origin distance mm=" + LevelHeightService.MmText(projection.Distance)));
            }
            catch (Exception ex) { Error("face observation", ex); }
        }

        private static string Vec(XYZ value) => value == null ? "n/a" :
            string.Format(CultureInfo.InvariantCulture, "({0:0.000000},{1:0.000000},{2:0.000000})", value.X, value.Y, value.Z);

        private static string DocumentIdentity(Document doc)
        {
            if (doc == null) return "document=none";
            try { return "document='" + doc.Title + "' runtime=" + RuntimeHelpers.GetHashCode(doc) +
                " projectUid=" + doc.ProjectInformation?.UniqueId + " path=" + doc.PathName; }
            catch { return "document identity unavailable"; }
        }

        private static void EnvironmentSnapshot(string year, bool force)
        {
            if (!RunLog.Enabled || (!force && (DateTime.UtcNow - _lastEnvironmentUtc).TotalSeconds < 5)) return;
            _lastEnvironmentUtc = DateTime.UtcNow;
            try
            {
                Assembly[] loaded = AppDomain.CurrentDomain.GetAssemblies();
                foreach (Assembly assembly in loaded.Where(a =>
                    (a.GetName().Name ?? "").IndexOf("LastSimilar", StringComparison.OrdinalIgnoreCase) >= 0))
                    RunLog.Add("LOADED EK ASSEMBLY | " + AssemblyIdentity(assembly));
                RunLog.Add("THIS LOGGER ASSEMBLY | " + AssemblyIdentity(typeof(DiagnosticsProbe).Assembly));
                ShortcutSnapshot(year);
                ManifestSnapshot(year);
            }
            catch (Exception ex) { Error("environment snapshot", ex); }
        }

        private static string AssemblyIdentity(Assembly assembly)
        {
            try
            {
                string context = "default/.NET Framework";
                Type alc = Type.GetType("System.Runtime.Loader.AssemblyLoadContext, System.Runtime.Loader", false);
                if (alc != null)
                {
                    object value = alc.GetMethod("GetLoadContext", new[] { typeof(Assembly) })?.Invoke(null, new object[] { assembly });
                    if (value != null) context = value.ToString() + " runtime=" + RuntimeHelpers.GetHashCode(value);
                }
                return assembly.FullName + " path=" + assembly.Location + " mvid=" + assembly.ManifestModule.ModuleVersionId +
                    " assemblyObject=" + RuntimeHelpers.GetHashCode(assembly) + " context=" + context;
            }
            catch (Exception ex) { return "unavailable: " + ex.GetType().Name; }
        }

        private static void ShortcutSnapshot(string year)
        {
            try
            {
                string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Autodesk", "Revit");
                if (!Directory.Exists(root)) { RunLog.Add("SHORTCUT SNAPSHOT | Revit preferences directory absent"); return; }
                bool found = false;
                foreach (string dir in Directory.GetDirectories(root).Where(d => Path.GetFileName(d).Contains(year)))
                {
                    string file = Path.Combine(dir, "KeyboardShortcuts.xml");
                    if (!File.Exists(file)) continue;
                    found = true;
                    RunLog.Add("SHORTCUT FILE | " + file + " modifiedUtc=" + File.GetLastWriteTimeUtc(file).ToString("o"));
                    string[] rows = DiagnosticFiles.ShortcutRows(file).ToArray();
                    foreach (string row in rows) RunLog.Add("SHORTCUT ROW | " + row);
                    if (rows.Length == 0) RunLog.Add("SHORTCUT ROW | no LL or EK Last Similar row found");
                }
                if (!found) RunLog.Add("SHORTCUT SNAPSHOT | no saved XML found for " + year + "; in-memory mapping is not proven");
                else RunLog.Add("SHORTCUT NOTE | saved XML only; current in-memory mapping may differ until Revit saves it");
            }
            catch (Exception ex) { Error("shortcut read", ex); }
        }

        private static void ManifestSnapshot(string year)
        {
            foreach (Environment.SpecialFolder folder in new[] {
                Environment.SpecialFolder.ApplicationData, Environment.SpecialFolder.CommonApplicationData })
            {
                try
                {
                    string root = Path.Combine(Environment.GetFolderPath(folder), "Autodesk");
                    string addins = Path.Combine(root, "Revit", "Addins", year);
                    if (Directory.Exists(addins))
                        foreach (string file in Directory.GetFiles(addins, "*.addin")) LogManifest(file);
                    string plugins = Path.Combine(root, "ApplicationPlugins");
                    if (Directory.Exists(plugins))
                        foreach (string bundle in Directory.GetDirectories(plugins, "*.bundle"))
                        {
                            string file = Path.Combine(bundle, "PackageContents.xml");
                            LogManifest(file);
                        }
                }
                catch (Exception ex) { Error("manifest inventory", ex); }
            }
        }

        private static void LogManifest(string file)
        {
            try
            {
                if (!File.Exists(file) || new FileInfo(file).Length > 1024 * 1024) return;
                string text = File.ReadAllText(file);
                string compact = text.Replace(" ", "").Replace("_", "").ToLowerInvariant();
                if (!compact.Contains("lastsimilar")) return;
                RunLog.Add("EK REGISTRATION | " + file + " | " + text.Replace("\r", "").Replace("\n", " "));
            }
            catch (Exception ex) { Error("manifest read", ex); }
        }

        private static void JournalSnapshot(Application app)
        {
            try
            {
                string path = app.RecordingJournalFilename;
                RunLog.Add("JOURNAL PATH: " + path);
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return;
                RunLog.Add("JOURNAL COMMAND TAIL | read at " + DateTimeOffset.Now.ToString("o") +
                    "; Revit may not have flushed recent entries yet");
                foreach (string line in DiagnosticFiles.JournalCommands(DiagnosticFiles.ReadTail(path)))
                    RunLog.Add("JOURNAL | " + line);
            }
            catch (Exception ex) { Error("journal read", ex); }
        }

        private static void Marker(Application app, string text)
        {
            try { app.WriteJournalComment("EKLS_DIAG " + RunLog.Identity + " " + text, true); }
            catch (Exception ex) { Error("journal marker", ex); }
        }

        private static void Error(string step, Exception ex)
        {
            if (RunLog.Enabled) RunLog.Add("DIAGNOSTIC UNAVAILABLE " + step + ": " + ex.GetType().Name + " " + ex.Message);
        }
    }
}

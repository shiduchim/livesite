using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;

namespace EK.LastSimilar.Services
{
    /// <summary>Which native element a history entry of ItemKind "element" is.</summary>
    internal static class ElementKinds
    {
        public const string TextNote = "text";
        public const string Wall = "wall";
        public const string CurtainWall = "curtain-wall";
        public const string Duct = "duct";
        public const string FlexDuct = "flex-duct";
        public const string Pipe = "pipe";
        public const string FlexPipe = "flex-pipe";
        public const string Conduit = "conduit";
        public const string CableTray = "cable-tray";
        public const string DuctAccessory = "duct-accessory";
        public const string PipeAccessory = "pipe-accessory";
        public const string Stair = "stair";
        public const string Railing = "railing";
        public const string ModelGroup = "model-group";
        public const string DetailGroup = "detail-group";
        public const string Callout = "callout";
        public const string Beam = "beam";
        public const string Brace = "brace";
        public const string Column = "column";
        public const string StructuralColumn = "structural-column";
        public const string FilledRegion = "filled-region";
        public const string MaskingRegion = "masking-region";
        public const string Dimension = "dimension";
        public const string SpotElevation = "spot-elevation";
        public const string SpotCoordinate = "spot-coordinate";
        public const string SpotSlope = "spot-slope";

        public static string Label(string kind)
        {
            switch (kind)
            {
                case TextNote: return "Text note";
                case Wall: return "Wall";
                case CurtainWall: return "Curtain wall";
                case Duct: return "Duct";
                case FlexDuct: return "Flex duct";
                case Pipe: return "Pipe";
                case FlexPipe: return "Flex pipe";
                case Conduit: return "Conduit";
                case CableTray: return "Cable tray";
                case DuctAccessory: return "Duct accessory";
                case PipeAccessory: return "Pipe accessory";
                case Stair: return "Stair";
                case Railing: return "Railing";
                case ModelGroup: return "Model group";
                case DetailGroup: return "Detail group";
                case Callout: return "Callout";
                case Beam: return "Beam";
                case Brace: return "Brace";
                case Column: return "Column";
                case StructuralColumn: return "Structural column";
                case FilledRegion: return "Filled region";
                case MaskingRegion: return "Masking region";
                case Dimension: return "Dimension";
                case SpotElevation: return "Spot elevation";
                case SpotCoordinate: return "Spot coordinate";
                case SpotSlope: return "Spot slope";
                default: return "Element";
            }
        }

        /// <summary>
        /// MEP runs. Drawing one can add several segments (bends, offsets) in one commit, and
        /// inserting an accessory or tee splits an existing run, which adds a segment too.
        /// So run segments are recorded only when nothing else was placed in the same commit.
        /// </summary>
        public static bool IsRun(string kind) =>
            kind == Duct || kind == FlexDuct || kind == Pipe || kind == FlexPipe ||
            kind == Conduit || kind == CableTray;
    }

    /// <summary>
    /// v4.2: Last Similar for elements Revit places with its own tools: text notes, walls and
    /// curtain walls, ducts, pipes, flex runs, conduit, cable trays, duct/pipe accessories,
    /// stairs, railings, model/detail groups, callouts, beams, braces, columns, filled/masking
    /// regions, dimensions and spot elevations/coordinates/slopes.
    ///
    /// Same rules as the tag services: only Revit's own placement of the exact remembered type,
    /// never a default-type substitution, never a custom pick/create loop, no application
    /// transaction and NO height correction. None of these ever enter PlacementService.
    /// </summary>
    internal static class ElementSimilarService
    {
        // ------------------------------------------------------------------
        // Classification (read-only)
        // ------------------------------------------------------------------

        /// <summary>
        /// Returns the element kind of a user-placed element and its type, or null when the
        /// element is not one of the native kinds or must not be tracked (group member, nested,
        /// stacked-wall member, in-place, unusable type, keynote/constraint, ...).
        /// </summary>
        internal static string Classify(Element e, out ElementType type)
        {
            type = null;
            try
            {
                if (e == null || !e.IsValidObject || e is ElementType)
                    return null;

                if (e.GroupId != null && e.GroupId != ElementId.InvalidElementId)
                    return null;

                string kind = KindOf(e);
                if (kind == null)
                    return null;

                type = e.Document?.GetElement(e.GetTypeId()) as ElementType;
                if (type == null || !type.IsValidObject)
                    return null;

                if (type is FamilySymbol symbol && !StateStore.IsUsableSymbol(symbol))
                    return null;

                return kind;
            }
            catch
            {
                type = null;
                return null;
            }
        }

        private static string KindOf(Element e)
        {
            if (e is TextNote) return ElementKinds.TextNote;

            if (e is Wall wall)
            {
                if (wall.IsStackedWallMember) return null;
                return wall.WallType != null && wall.WallType.Kind == WallKind.Curtain
                    ? ElementKinds.CurtainWall
                    : ElementKinds.Wall;
            }

            if (e is FlexDuct) return ElementKinds.FlexDuct;
            if (e is Duct) return ElementKinds.Duct;
            if (e is FlexPipe) return ElementKinds.FlexPipe;
            if (e is Pipe) return ElementKinds.Pipe;
            if (e is Conduit) return ElementKinds.Conduit;
            if (e is CableTray) return ElementKinds.CableTray;

            if (e is Stairs) return ElementKinds.Stair;
            if (e is Railing) return ElementKinds.Railing;

            if (e is Group)
            {
                if (IsCategory(e, BuiltInCategory.OST_IOSModelGroups)) return ElementKinds.ModelGroup;
                if (IsCategory(e, BuiltInCategory.OST_IOSDetailGroups)) return ElementKinds.DetailGroup;
                return null; // attached detail groups etc.
            }

            if (e is View view)
                return IsTrackableCallout(view) ? ElementKinds.Callout : null;

            if (e is FilledRegion region)
                return region.IsMasking ? ElementKinds.MaskingRegion : ElementKinds.FilledRegion;

            if (e is SpotDimension)
            {
                if (IsCategory(e, BuiltInCategory.OST_SpotElevations)) return ElementKinds.SpotElevation;
                if (IsCategory(e, BuiltInCategory.OST_SpotCoordinates)) return ElementKinds.SpotCoordinate;
                if (IsCategory(e, BuiltInCategory.OST_SpotSlopes)) return ElementKinds.SpotSlope;
                return null;
            }

            // Only real dimensions: not constraints, not spot dimensions (handled above).
            if (e is Dimension)
                return IsCategory(e, BuiltInCategory.OST_Dimensions) ? ElementKinds.Dimension : null;

            if (e is FamilyInstance fi)
                return FamilyKind(fi);

            return null;
        }

        /// <summary>Family instances that Revit places with its own tool and EK never height-corrects.</summary>
        private static string FamilyKind(FamilyInstance fi)
        {
            if (!PlacementService.IsEligibleFamilyInstance(fi))
                return null;

            if (IsCategory(fi, BuiltInCategory.OST_DuctAccessory)) return ElementKinds.DuctAccessory;
            if (IsCategory(fi, BuiltInCategory.OST_PipeAccessory)) return ElementKinds.PipeAccessory;
            if (IsCategory(fi, BuiltInCategory.OST_StructuralColumns)) return ElementKinds.StructuralColumn;
            if (IsCategory(fi, BuiltInCategory.OST_Columns)) return ElementKinds.Column;
            if (IsCategory(fi, BuiltInCategory.OST_StructuralFraming))
                return fi.StructuralType == Autodesk.Revit.DB.Structure.StructuralType.Brace
                    ? ElementKinds.Brace
                    : ElementKinds.Beam;
            return null;
        }

        /// <summary>
        /// Family TYPES that belong to the native path (beams, braces, columns, duct/pipe
        /// accessories). Used to route older "family" history entries of these types away
        /// from the family placement and height-correction workflow.
        /// </summary>
        internal static string KindForFamilySymbol(FamilySymbol symbol)
        {
            try
            {
                if (symbol == null || !symbol.IsValidObject)
                    return null;

                if (IsCategory(symbol, BuiltInCategory.OST_DuctAccessory)) return ElementKinds.DuctAccessory;
                if (IsCategory(symbol, BuiltInCategory.OST_PipeAccessory)) return ElementKinds.PipeAccessory;
                if (IsCategory(symbol, BuiltInCategory.OST_StructuralColumns)) return ElementKinds.StructuralColumn;
                if (IsCategory(symbol, BuiltInCategory.OST_Columns)) return ElementKinds.Column;
                if (IsCategory(symbol, BuiltInCategory.OST_StructuralFraming)) return ElementKinds.Beam;
            }
            catch { }

            return null;
        }

        internal static bool IsTrackableCallout(View view)
        {
            try
            {
                return view != null && view.IsValidObject && !view.IsTemplate && view.IsCallout &&
                       view.GetCalloutParentId() != ElementId.InvalidElementId;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// A railing created together with its host in the same commit (the automatic railings
        /// of a new stair) is a companion of that placement, not a railing placement.
        /// </summary>
        internal static bool IsCompanion(Element e, string kind, ICollection<ElementId> addedInSameCommit)
        {
            if (kind != ElementKinds.Railing || addedInSameCommit == null)
                return false;

            try
            {
                ElementId host = ((Railing)e).HostId;
                return host != null && host != ElementId.InvalidElementId && addedInSameCommit.Contains(host);
            }
            catch
            {
                return true; // unknown: never let it hide the real placement
            }
        }

        internal static PlacementRecord BuildRecord(Element e, string kind, ElementType type)
        {
            try
            {
                if (e == null || kind == null || type == null || string.IsNullOrWhiteSpace(type.UniqueId))
                    return null;

                var rec = new PlacementRecord
                {
                    SymbolUniqueId = type.UniqueId,
                    ItemKind = RecentItemKinds.Element,
                    ElementKind = kind,
                    SourceElementUniqueId = e.UniqueId,
                    // Shown as "<type>" with "<what> / <family>" underneath, e.g.
                    // "Generic - 200mm" / "Wall / Basic Wall".
                    FamilyName = ElementKinds.Label(kind),
                    TypeName = type.Name ?? "",
                    CategoryName = SafeFamilyName(type),
                    LearnedWallHeightFeet = null
                };

                Category c = e.Category;
                if (c != null)
                    rec.CategoryIdValue = c.Id.Value;

                return rec;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Turns a history entry of a beam/column/accessory type that older versions stored as a
        /// plain family into an element entry (in memory). Persisted with the next placement.
        /// </summary>
        internal static void ConvertFamilyEntry(RecentTypeState entry, FamilySymbol symbol, string kind)
        {
            if (entry == null || kind == null)
                return;

            entry.ItemKind = RecentItemKinds.Element;
            entry.ElementKind = kind;
            entry.CategoryName = SafeFamilyName(symbol);
            entry.FamilyName = ElementKinds.Label(kind);
            entry.HeightMode = HeightModes.Last;
            entry.LastWallHeightFeet = null;
            entry.StandardHeightMm = null;
        }

        // ------------------------------------------------------------------
        // Native placement
        // ------------------------------------------------------------------

        /// <summary>
        /// Starts Revit's own placement for the remembered type, in this order:
        ///   1. Create Similar from the last placed element itself when it is in the current view
        ///      (keeps everything Create Similar keeps: system type, size, beam vs brace, ...);
        ///   2. Revit's native placement of exactly that type;
        ///   3. Create Similar from another element of exactly that type in the current view.
        /// Otherwise it explains why and changes nothing.
        /// </summary>
        internal static Result Start(UIApplication uiapp, ElementType type, RecentTypeState entry)
        {
            UIDocument uidoc = uiapp?.ActiveUIDocument;
            if (uidoc == null || type == null || !type.IsValidObject)
                return Result.Cancelled;

            if (type is FamilySymbol fs && !StateStore.IsUsableSymbol(fs))
                return Result.Cancelled;

            string kind = entry?.ElementKind;
            if (string.IsNullOrEmpty(kind) && type is FamilySymbol symbol)
                kind = KindForFamilySymbol(symbol);

            string label = ElementKinds.Label(kind);
            Document doc = uidoc.Document;
            View view = uidoc.ActiveView;

            try
            {
                // 1. The very element that was placed last.
                Element last = FindLastSource(doc, view, type, entry, kind);
                if (last != null && PostCreateSimilar(uiapp, uidoc, last, label, "last placed"))
                    return Started(doc, view, type, kind);

                // 2. Revit's own placement of the exact type.
                bool canPlace = false;
                try { canPlace = uidoc.CanPlaceElementType(type); }
                catch { }

                if (canPlace)
                {
                    try
                    {
                        uidoc.PostRequestForElementTypePlacement(type);
                        RunLog.Add(label + " native placement queued: " + SafeFamilyName(type) + " : " + type.Name +
                                   " | type=" + type.Id.Value + " | height correction never applies");
                        return Started(doc, view, type, kind);
                    }
                    catch (Exception ex)
                    {
                        RunLog.Add(label + " native type placement refused: " + ex.Message);
                    }
                }

                // 3. Any other element of exactly this type in the current view.
                Element other = FindOtherSource(doc, view, type, kind, last);
                if (other != null && PostCreateSimilar(uiapp, uidoc, other, label, "same-type"))
                    return Started(doc, view, type, kind);

                CommandRunner.SafeDialog(
                    "Revit cannot start this " + label.ToLowerInvariant() + " type here:\n" +
                    "\"" + type.Name + "\"\n\n" +
                    "Open a view where you can place it and where one " + label.ToLowerInvariant() +
                    " of this type is visible, or place one normally, then use Last Similar again.");
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                RunLog.Add(label + " placement unavailable: " + ex.Message);
                CommandRunner.SafeDialog("Could not start Revit's " + label.ToLowerInvariant() + " placement.\n\n" + ex.Message);
                return Result.Cancelled;
            }
        }

        private static Result Started(Document doc, View view, ElementType type, string kind)
        {
            // Callouts are views; there is nothing to check for visibility.
            if (kind != ElementKinds.Callout)
                VisibilityWatch.Expect(doc, view, type.Id, ElementKinds.Label(kind) + " \"" + type.Name + "\"");
            return Result.Succeeded;
        }

        private static bool PostCreateSimilar(UIApplication uiapp, UIDocument uidoc, Element source, string label, string what)
        {
            RevitCommandId similar = RevitCommandId.LookupPostableCommandId(PostableCommand.CreateSimilar);

            ICollection<ElementId> oldSelection = null;
            try { oldSelection = uidoc.Selection.GetElementIds(); }
            catch { }

            bool posted = false;
            try
            {
                uidoc.Selection.SetElementIds(new List<ElementId> { source.Id });

                // Availability depends on the selection, so check after selecting.
                if (similar == null || !uiapp.CanPostCommand(similar))
                    return false;

                uiapp.PostCommand(similar);
                posted = true;
                RunLog.Add(label + " Create Similar queued from " + what + " element " + source.Id.Value +
                           " | type=" + source.GetTypeId().Value + " | height correction never applies");
                return true;
            }
            catch (Exception ex)
            {
                RunLog.Add(label + " Create Similar unavailable: " + ex.Message);
                return false;
            }
            finally
            {
                if (!posted && oldSelection != null)
                {
                    try { uidoc.Selection.SetElementIds(oldSelection); }
                    catch { }
                }
            }
        }

        private static Element FindLastSource(Document doc, View view, ElementType type, RecentTypeState entry, string kind)
        {
            if (doc == null || view == null || string.IsNullOrEmpty(entry?.SourceElementUniqueId))
                return null;

            Element e = null;
            try { e = doc.GetElement(entry.SourceElementUniqueId); }
            catch { }

            // A callout is remembered by its view; Create Similar needs its callout in this view.
            if (e is View calloutView)
                return FindCalloutInView(doc, view, type, calloutView.Name);

            return IsUsableSource(e, type, kind) && IsInView(doc, view, e) ? e : null;
        }

        private static Element FindOtherSource(Document doc, View view, ElementType type, string kind, Element skip)
        {
            if (doc == null || view == null)
                return null;

            if (kind == ElementKinds.Callout)
                return FindCalloutInView(doc, view, type, null);

            try
            {
                return new FilteredElementCollector(doc, view.Id)
                    .WhereElementIsNotElementType()
                    .FirstOrDefault(x => (skip == null || x.Id != skip.Id) && IsUsableSource(x, type, kind));
            }
            catch
            {
                return null;
            }
        }

        /// <summary>The callout symbol (viewer) in the current view, of the exact view type.</summary>
        private static Element FindCalloutInView(Document doc, View view, ElementType type, string preferredName)
        {
            try
            {
                List<Element> viewers = new FilteredElementCollector(doc, view.Id)
                    .OfCategory(BuiltInCategory.OST_Viewers)
                    .Where(x => x.GetTypeId() == type.Id)
                    .ToList();

                return viewers.FirstOrDefault(x => preferredName != null && x.Name == preferredName) ??
                       viewers.FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }

        private static bool IsUsableSource(Element e, ElementType type, string kind)
        {
            try
            {
                return e != null && e.IsValidObject && e.GetTypeId() == type.Id &&
                       Classify(e, out ElementType _) == kind;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Create Similar needs an element the user could select in this view.</summary>
        private static bool IsInView(Document doc, View view, Element e)
        {
            try
            {
                if (e.ViewSpecific)
                    return e.OwnerViewId == view.Id;

                return new FilteredElementCollector(doc, view.Id)
                    .WherePasses(new ElementIdSetFilter(new List<ElementId> { e.Id }))
                    .Any();
            }
            catch
            {
                return false;
            }
        }

        private static bool IsCategory(Element e, BuiltInCategory bic)
        {
            try
            {
                Category c = e.Category;
                return c != null && c.Id.Value == (long)bic;
            }
            catch
            {
                return false;
            }
        }

        private static string SafeFamilyName(ElementType type)
        {
            try { return type?.FamilyName ?? ""; }
            catch { return ""; }
        }
    }
}

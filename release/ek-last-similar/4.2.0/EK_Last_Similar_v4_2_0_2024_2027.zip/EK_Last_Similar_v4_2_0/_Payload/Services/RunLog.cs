using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace EK.LastSimilar.Services
{
    /// <summary>
    /// Diagnostic log: %APPDATA%\EK\LastSimilar\last-run.log
    ///
    /// v3.9.4: ROLLING. Every run is APPENDED (newest run at the BOTTOM) and the file is
    /// trimmed to roughly the last 1 MB. Before 4.0.0 every command - including just opening
    /// Settings or Recent 5 - overwrote the file, so the log of a failed placement was
    /// usually gone by the time anyone looked at it.
    ///
    /// v4.0.2: every line is written immediately, with process/build/load/run identity.
    /// Independent per-load traces are authoritative; last-run.log remains a convenience.
    /// Logging is opt-in and never opens a model transaction. Never throws.
    /// </summary>
    internal static class RunLog
    {
        private const int MaxBufferedLines = 3000;
        private const long MaxFileBytes = 1536L * 1024L;
        private const int TrimToChars = 1024 * 1024;
        private const string RunMarker = "==========";

        private static readonly List<string> Lines = new List<string>();
        private static bool _inCommand;
        private static bool _enabled;
        private static readonly string LoadId = Guid.NewGuid().ToString("N").Substring(0, 12);
        private static readonly int ProcessId = Process.GetCurrentProcess().Id;
        private static readonly string TraceName = "trace-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") +
            "-pid" + ProcessId + "-" + LoadId + ".log";
        private static string _runId = "none";
        private static string _revitVersion = "unknown";
        private static readonly object Gate = new object();

        public static string SessionFilePath => Path.Combine(StateStore.FolderPath, "Diagnostics", TraceName);
        public static string Identity => "pid=" + ProcessId + " revit=" + _revitVersion +
            " ek=" + Version + " load=" + LoadId + " run=" + _runId;

        // Pure metadata; never changes any model/session decision.
        public static void ConfigureRuntime(string version, string build)
        {
            _revitVersion = (version ?? "?") + "/" + (build ?? "?");
        }

        public static string FilePath =>
            Path.Combine(StateStore.FolderPath, "last-run.log");

        public static bool InCommand => _inCommand;
        public static bool Enabled => _enabled;

        /// <summary>
        /// Enables/disables diagnostic logging. Turning it off flushes anything already
        /// buffered, then all later Begin/Add/Flush calls become no-ops until re-enabled.
        /// </summary>
        public static void SetEnabled(bool enabled)
        {
            try
            {
                if (_enabled && !enabled)
                {
                    try { WritePending(); }
                    catch { }
                    Lines.Clear();
                    _inCommand = false;
                    _runId = "none";
                }

                bool justEnabled = !_enabled && enabled;
                _enabled = enabled;
                if (justEnabled)
                    Add("DIAGNOSTICS ENABLED | authoritative trace: " + SessionFilePath);
            }
            catch
            {
                _enabled = enabled;
            }
        }

        public static string Version
        {
            get
            {
                try { return typeof(RunLog).Assembly.GetName().Version.ToString(); }
                catch { return "?"; }
            }
        }

        public static void Begin(string title)
        {
            if (!_enabled)
                return;

            try
            {
                // Anything still buffered (should not happen) is written before the new run.
                if (Lines.Count > 0)
                    WritePending();

                _inCommand = true;
                _runId = Guid.NewGuid().ToString("N").Substring(0, 12);

                int pid = 0;
                try { pid = Process.GetCurrentProcess().Id; }
                catch { }

                AddRaw("");
                AddRaw(RunMarker + " " +
                       DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) +
                       "  EK Last Similar " + Version + "  -  " + title +
                       "  (Revit process " + pid + ") " + RunMarker);
                WritePending(); // Command entry survives a crash or a missing command exit.
            }
            catch { }
        }

        public static void Add(string line)
        {
            if (!_enabled)
                return;

            try
            {
                if (_inCommand)
                {
                    AddRaw(line ?? "");
                    WritePending(); // Stream diagnostics during placement, not only at command end.
                    return;
                }

                // Between commands (passive tracker, state file messages): write at once.
                AddRaw("[background] " + (line ?? ""));
                WritePending();
            }
            catch { }
        }

        /// <summary>Mark the end of a command and reset its diagnostic correlation id.</summary>
        public static void Flush()
        {
            if (!_enabled)
            {
                _inCommand = false;
                _runId = "none";
                Lines.Clear();
                return;
            }

            if (_inCommand) Add("COMMAND LOG END");
            try { WritePending(); }
            catch { }

            _inCommand = false;
            _runId = "none";
        }

        private static void AddRaw(string text)
        {
            try
            {
                lock (Gate)
                    Lines.Add(DateTimeOffset.Now.ToString("o", CultureInfo.InvariantCulture) +
                        " [" + Identity + "] " + text);

                // Very long runs: write early instead of dropping lines.
                if (Lines.Count >= MaxBufferedLines)
                    WritePending();
            }
            catch { }
        }

        private static void WritePending()
        {
            if (!_enabled) return;
            lock (Gate)
            {
                if (Lines.Count == 0) return;
                string text = string.Join("\r\n", Lines) + "\r\n";
                Lines.Clear();
                // Each loaded copy has its own file: another process/version cannot overwrite it.
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(SessionFilePath));
                    File.AppendAllText(SessionFilePath, text, new UTF8Encoding(false));
                    TrimIfLarge(SessionFilePath);
                }
                catch { /* Diagnostics must never affect placement. */ }

                // Preserve the familiar last-run.log as a convenience, not the only evidence.
                // A busy shared writer is skipped; the independent trace above remains complete.
                try
                {
                    using (var mutex = new Mutex(false, @"Local\EK_LastSimilar_DiagnosticLog"))
                    {
                        bool owned = false;
                        try
                        {
                            try { owned = mutex.WaitOne(0); }
                            catch (AbandonedMutexException) { owned = true; }
                            if (!owned) return;
                            Directory.CreateDirectory(StateStore.FolderPath);
                            File.AppendAllText(FilePath, text, new UTF8Encoding(false));
                            TrimIfLarge(FilePath);
                        }
                        finally { if (owned) mutex.ReleaseMutex(); }
                    }
                }
                catch { }
            }
        }

        private static void TrimIfLarge(string path)
        {
            try
            {
                var info = new FileInfo(path);
                if (!info.Exists || info.Length <= MaxFileBytes)
                    return;

                string text = File.ReadAllText(path, Encoding.UTF8);
                if (text.Length <= TrimToChars)
                    return;

                int cut = text.Length - TrimToChars;

                // Prefer to cut at the start of a run, so every kept run is complete.
                int boundary = text.IndexOf("\n" + RunMarker, cut, StringComparison.Ordinal);
                if (boundary < 0)
                    boundary = text.IndexOf('\n', cut);
                if (boundary < 0)
                    return;

                string kept = "(older runs trimmed " +
                              DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) +
                              ")\r\n" + text.Substring(boundary + 1);

                string temp = path + ".tmp";
                File.WriteAllText(temp, kept, new UTF8Encoding(false));
                File.Copy(temp, path, true);

                try { File.Delete(temp); }
                catch { }
            }
            catch { }
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace EK.LastSimilar.Services
{
    // File-only helpers, tested independently of Revit. Never modify the files inspected.
    internal static class DiagnosticFiles
    {
        internal static IEnumerable<string> ShortcutRows(string path)
        {
            var xml = new XmlDocument { XmlResolver = null };
            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Prohibit,
                XmlResolver = null,
                MaxCharactersInDocument = 4 * 1024 * 1024
            };
            using (var reader = XmlReader.Create(path, settings)) xml.Load(reader);
            var rows = new List<string>();
            foreach (XmlNode node in xml.SelectNodes("//*"))
            {
                if (node.Attributes == null || node.Attributes.Count == 0) continue;
                string attributes = string.Join(" | ", node.Attributes.Cast<XmlAttribute>()
                    .Select(a => a.Name + "=" + a.Value));
                string compact = attributes.Replace(" ", "").Replace("_", "").ToLowerInvariant();
                bool ll = node.Attributes.Cast<XmlAttribute>()
                    .Where(a => a.Name.IndexOf("shortcut", StringComparison.OrdinalIgnoreCase) >= 0)
                    .Any(a => a.Value.Split(new[] { '#', ',', ';', ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                        .Any(k => string.Equals(k, "LL", StringComparison.OrdinalIgnoreCase)));
                if (ll || compact.Contains("lastsimilar")) rows.Add(attributes);
            }
            return rows;
        }

        internal static string ReadTail(string path, int maxBytes = 65536)
        {
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read,
                FileShare.ReadWrite | FileShare.Delete))
            {
                var bom = new byte[4];
                int count = stream.Read(bom, 0, bom.Length);
                bool utf16 = count >= 2 && ((bom[0] == 255 && bom[1] == 254) ||
                    (bom[0] == 254 && bom[1] == 255));
                Encoding encoding = utf16
                    ? (bom[0] == 255 ? Encoding.Unicode : Encoding.BigEndianUnicode)
                    : Encoding.UTF8;
                long start = Math.Max(0, stream.Length - maxBytes);
                if (utf16 && start % 2 != 0) start--;
                stream.Position = start;
                using (var reader = new StreamReader(stream, encoding, start == 0))
                {
                    if (start > 0) reader.ReadLine(); // Omit a partial first line.
                    return reader.ReadToEnd();
                }
            }
        }

        internal static IEnumerable<string> JournalCommands(string text, int maxLines = 36)
        {
            var output = new List<string>();
            int continuation = 0;
            foreach (string raw in text.Replace("\r", "").Split('\n'))
            {
                string line = raw.Trim();
                // Commands can span multiple lines. Avoid unrelated journal/model contents.
                bool command = line.IndexOf("Jrn.Command", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    line.IndexOf("EKLS_DIAG", StringComparison.Ordinal) >= 0;
                if (command) continuation = 3;
                if (continuation <= 0) continue;
                output.Add(line);
                continuation = line.EndsWith("_", StringComparison.Ordinal) ? continuation - 1 : 0;
            }
            return output.Skip(Math.Max(0, output.Count - maxLines));
        }
    }
}

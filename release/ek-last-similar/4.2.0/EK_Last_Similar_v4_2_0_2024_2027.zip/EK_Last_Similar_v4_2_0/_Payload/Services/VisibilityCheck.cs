using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;

namespace EK.LastSimilar.Services
{
    /// <summary>
    /// v4.2 "Not visible" warning. After an EK placement, tells the user when what they just
    /// placed is not shown in the view ("I placed it and it disappeared"): category turned off
    /// in Visibility/Graphics (in the view or its view template), all model/annotation
    /// categories off, a view filter that hides it, or anything else that makes Revit leave it
    /// out of the view (view range, phase, workset, Temporary Hide/Isolate, ...).
    ///
    /// Read-only. Never changes the model or the view. Can be turned off in Settings > General
    /// or from the warning itself.
    /// </summary>
    internal static class VisibilityCheck
    {
        /// <summary>Family placements (PlacementService): checked right after the command's placement.</summary>
        internal static void ReportPlaced(Document doc, View view, ICollection<ElementId> ids, string what)
        {
            try
            {
                if (doc == null || view == null || ids == null || ids.Count == 0)
                    return;

                Report(doc, view, ids, what);
            }
            catch (Exception ex)
            {
                RunLog.Add("Visibility check skipped: " + ex.Message);
            }
        }

        /// <summary>Native placements (tags, lines, walls, ...): checked when Revit is idle again.</summary>
        internal static void OnIdling(object sender, IdlingEventArgs e)
        {
            VisibilityWatch.Pending p = VisibilityWatch.TakeFinished(DateTime.UtcNow);
            if (p == null)
                return;

            try
            {
                if (p.Doc == null || !p.Doc.IsValidObject)
                    return;

                View view = p.Doc.GetElement(p.ViewId) as View;
                if (view == null || !view.IsValidObject)
                    return;

                Report(p.Doc, view, p.Added, p.What);
            }
            catch (Exception ex)
            {
                RunLog.Add("Visibility check skipped: " + ex.Message);
            }
        }

        private static void Report(Document doc, View view, ICollection<ElementId> ids, string what)
        {
            if (!StateStore.GetWarnHiddenPlacements())
                return;

            if (view.IsTemplate)
                return;

            var reasons = new List<string>();
            int hidden = 0;
            int total = 0;

            HashSet<ElementId> visible = VisibleInView(doc, view, ids);

            foreach (ElementId id in ids)
            {
                Element e = doc.GetElement(id);
                if (e == null || !e.IsValidObject)
                    continue;

                total++;
                List<string> why = Reasons(doc, view, e, visible);
                if (why.Count == 0)
                    continue;

                hidden++;
                foreach (string r in why)
                {
                    if (!reasons.Contains(r))
                        reasons.Add(r);
                }
            }

            RunLog.Add("Visibility check in view '" + view.Name + "': " + hidden + " of " + total +
                       " placed item(s) not visible" + (reasons.Count > 0 ? " | " + string.Join(" | ", reasons) : ""));

            if (hidden == 0)
                return;

            string items = hidden == 1 ? "1 placed item" : hidden + " placed items";
            string content =
                (string.IsNullOrWhiteSpace(what) ? "" : what + "\n") +
                items + " " + (hidden == 1 ? "is" : "are") + " in the model but not visible in the view \"" +
                view.Name + "\":\n\n" +
                string.Join("\n", reasons.Select(r => "• " + r)) +
                "\n\nNothing was changed. To see it, adjust the view (Visibility/Graphics: VV), or use Undo to remove it.";

            try
            {
                var td = new TaskDialog("EK Last Similar")
                {
                    MainInstruction = "Placed, but not visible in this view",
                    MainContent = content,
                    VerificationText = "Don't show this warning again (Settings > General turns it back on)",
                    CommonButtons = TaskDialogCommonButtons.Close
                };
                td.Show();

                if (td.WasVerificationChecked())
                    StateStore.SaveWarnHiddenPlacements(false);
            }
            catch { }
        }

        /// <summary>Why one element is not visible in the view. Empty when it is visible.</summary>
        private static List<string> Reasons(Document doc, View view, Element e, HashSet<ElementId> visibleIds)
        {
            var reasons = new List<string>();

            Category category = SafeCategory(e);
            if (category == null)
                return reasons;

            var categories = new List<Category> { category };
            AddIfNew(categories, SafeParent(category));

            // A line's style is a subcategory of Lines; hiding it hides the line.
            if (e is CurveElement curve)
            {
                try
                {
                    if (curve.LineStyle is GraphicsStyle gs)
                    {
                        AddIfNew(categories, gs.GraphicsStyleCategory);
                        AddIfNew(categories, SafeParent(gs.GraphicsStyleCategory));
                    }
                }
                catch { }
            }

            bool annotation = false;
            try { annotation = category.CategoryType == CategoryType.Annotation; }
            catch { }

            // Visibility/Graphics: the view itself, or its template when the template controls it.
            View vg = ControllingView(doc, view,
                annotation ? BuiltInParameter.VIS_GRAPHICS_ANNOTATION : BuiltInParameter.VIS_GRAPHICS_MODEL,
                out string vgNote);

            try
            {
                if (annotation ? vg.AreAnnotationCategoriesHidden : vg.AreModelCategoriesHidden)
                {
                    reasons.Add("All " + (annotation ? "annotation" : "model") +
                                " categories are turned off in Visibility/Graphics" + vgNote + ".");
                }
            }
            catch { }

            foreach (Category c in categories)
            {
                try
                {
                    if (vg.GetCategoryHidden(c.Id))
                        reasons.Add("The category \"" + c.Name + "\" is turned off in Visibility/Graphics" + vgNote + ".");
                }
                catch { }
            }

            // View filters set to invisible.
            View fv = ControllingView(doc, view, BuiltInParameter.VIS_GRAPHICS_FILTERS, out string filterNote);
            ICollection<ElementId> filters = null;
            try { filters = fv.GetFilters(); }
            catch { }

            if (filters != null)
            {
                var categoryIds = new HashSet<long>(categories.Select(c => c.Id.Value));
                foreach (ElementId filterId in filters)
                {
                    try
                    {
                        if (!fv.GetIsFilterEnabled(filterId) || fv.GetFilterVisibility(filterId))
                            continue;

                        Element f = doc.GetElement(filterId);
                        bool hides = false;

                        if (f is ParameterFilterElement pfe)
                        {
                            if (pfe.GetCategories().Any(id => categoryIds.Contains(id.Value)))
                            {
                                ElementFilter rule = pfe.GetElementFilter();
                                hides = rule == null || rule.PassesFilter(e);
                            }
                        }
                        else if (f is SelectionFilterElement sfe)
                        {
                            hides = sfe.GetElementIds().Contains(e.Id);
                        }

                        if (hides)
                            reasons.Add("The view filter \"" + f.Name + "\" hides it" + filterNote + ".");
                    }
                    catch { }
                }
            }

            if (reasons.Count > 0)
                return reasons;

            // Nothing specific found: ask Revit whether the element is drawn in the view at all.
            // (A group is represented by its members, so it is not judged this way.)
            if (visibleIds != null && !(e is Group) && !visibleIds.Contains(e.Id))
            {
                bool isolate = false;
                try { isolate = view.IsTemporaryHideIsolateActive(); }
                catch { }

                reasons.Add(isolate
                    ? "Temporary Hide/Isolate is active in this view."
                    : "Revit does not show it in this view, for example because it is outside the view range " +
                      "or view depth, or hidden by phase, workset or design option settings.");
            }

            return reasons;
        }

        /// <summary>Ids Revit reports as drawn in the view; null when Revit cannot tell.</summary>
        private static HashSet<ElementId> VisibleInView(Document doc, View view, ICollection<ElementId> ids)
        {
            try
            {
                return new HashSet<ElementId>(
                    new FilteredElementCollector(doc, view.Id)
                        .WherePasses(new ElementIdSetFilter(ids))
                        .ToElementIds());
            }
            catch
            {
                return null;
            }
        }

        /// <summary>The view template when it controls this part of Visibility/Graphics, else the view.</summary>
        private static View ControllingView(Document doc, View view, BuiltInParameter part, out string note)
        {
            note = "";
            try
            {
                ElementId templateId = view.ViewTemplateId;
                if (templateId == null || templateId == ElementId.InvalidElementId)
                    return view;

                if (!(doc.GetElement(templateId) is View template))
                    return view;

                bool controlled = !template.GetNonControlledTemplateParameterIds()
                    .Any(id => id.Value == (long)part);
                if (!controlled)
                    return view;

                note = " (set by the view template \"" + template.Name + "\")";
                return template;
            }
            catch
            {
                return view;
            }
        }

        private static Category SafeCategory(Element e)
        {
            try { return e.Category; }
            catch { return null; }
        }

        private static Category SafeParent(Category c)
        {
            try { return c?.Parent; }
            catch { return null; }
        }

        private static void AddIfNew(List<Category> list, Category c)
        {
            if (c != null && !list.Any(x => x.Id == c.Id))
                list.Add(c);
        }
    }
}

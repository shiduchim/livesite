using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace EK.LastSimilar.Services
{
    /// <summary>
    /// v4.2: remembers what an EK-started NATIVE placement (tag, line, text, wall, duct, ...)
    /// creates, so the "not visible" check can run once the user leaves Revit's tool.
    ///
    /// Native tools run after the EK command has returned, so the command itself never sees
    /// the new elements. The passive tracker feeds every fresh commit to OnAdded; Revit raises
    /// Idling only when no tool is active, which is when VisibilityCheck takes the result.
    /// Read-only: never edits the model.
    /// </summary>
    internal static class VisibilityWatch
    {
        internal sealed class Pending
        {
            public Document Doc;
            public ElementId ViewId;
            public ElementId TypeId;       // match by element type ...
            public ElementId LineStyleId;  // ... or, for lines, by line style
            public string What;
            public DateTime StartedUtc;
            public readonly List<ElementId> Added = new List<ElementId>();
        }

        private const int MaxIds = 500;

        // Before the queued tool starts there can be an idle moment with nothing placed yet.
        private static readonly TimeSpan StartGrace = TimeSpan.FromSeconds(5);

        private static Pending _pending;

        internal static bool IsWatching => _pending != null;

        internal static void Expect(Document doc, View view, ElementId typeId, string what)
        {
            Start(doc, view, typeId, null, what);
        }

        internal static void ExpectLines(Document doc, View view, ElementId lineStyleId, string what)
        {
            Start(doc, view, null, lineStyleId, what);
        }

        private static void Start(Document doc, View view, ElementId typeId, ElementId styleId, string what)
        {
            try
            {
                if (doc == null || view == null || (typeId == null && styleId == null))
                {
                    _pending = null;
                    return;
                }

                _pending = new Pending
                {
                    Doc = doc,
                    ViewId = view.Id,
                    TypeId = typeId,
                    LineStyleId = styleId,
                    What = what ?? "item",
                    StartedUtc = DateTime.UtcNow
                };
            }
            catch
            {
                _pending = null;
            }
        }

        internal static void Clear() => _pending = null;

        /// <summary>Called by the passive tracker for every fresh commit (never Undo/Redo).</summary>
        internal static void OnAdded(Document doc, ICollection<ElementId> added)
        {
            Pending p = _pending;
            if (p == null || added == null || added.Count == 0 || p.Added.Count >= MaxIds)
                return;

            try
            {
                if (!ReferenceEquals(doc, p.Doc) && !doc.Equals(p.Doc))
                    return;

                foreach (ElementId id in added)
                {
                    Element e = doc.GetElement(id);
                    if (e == null || e is ElementType)
                        continue;

                    bool match = p.LineStyleId != null
                        ? e is CurveElement c && c.LineStyle != null && c.LineStyle.Id == p.LineStyleId
                        : e.GetTypeId() == p.TypeId;

                    if (match && p.Added.Count < MaxIds)
                        p.Added.Add(id);
                }
            }
            catch
            {
                // Diagnostics-only feature: never disturb tracking.
            }
        }

        /// <summary>
        /// Called when Revit is idle (no active tool). Returns the finished watch with what was
        /// placed, or null. A watch that placed nothing is dropped after a short grace period.
        /// </summary>
        internal static Pending TakeFinished(DateTime utcNow)
        {
            Pending p = _pending;
            if (p == null)
                return null;

            if (p.Added.Count > 0)
            {
                _pending = null;
                return p;
            }

            if (utcNow - p.StartedUtc > StartGrace)
                _pending = null;

            return null;
        }
    }
}

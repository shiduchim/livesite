using System;
using Autodesk.Revit.DB;

namespace EK.LastSimilar.Services
{
    public enum HostKind
    {
        Wall,           // proven wall host (native or loaded Revit link)
        Ceiling,        // always left as placed
        Level,          // level/work plane, not a proven vertical host
        None,           // no host
        Other,          // horizontal, unsupported, or unresolved host
        VerticalFace    // NEW: verified vertical mounting face, native or linked
    }

    public sealed class HostInfo
    {
        public HostKind Kind { get; set; }
        public bool IsLinked { get; set; }
        public string Detail { get; set; }
        public string ShortText { get; set; } = "";
        public bool LinkProblem { get; set; }
        // Retained across the correction transaction to reject unintended rehosting.
        public string HostIdentity { get; set; }
        public string FaceStableReference { get; set; }

        public override string ToString() =>
            Kind + (IsLinked ? " (linked)" : "") +
            (string.IsNullOrEmpty(Detail) ? "" : " - " + Detail);
    }

    /// <summary>
    /// READ ONLY. Regular walls remain supported. All OTHER hosts must provide a
    /// resolvable face with a nearly horizontal local normal (= vertical surface).
    /// No ceiling/floor/roof, horizontal face, unresolved link or ambiguous host
    /// is changed.  Linked geometry references are converted into link-local form.
    /// </summary>
    public static class HostClassifier
    {
        private const double LinkedProximityToleranceFeet = 1.0;
        // The surface may be up to about 7 degrees off vertical.
        private const double MaxVerticalNormalZ = 0.12;

        public static HostInfo Classify(FamilyInstance fi)
        {
            Element host = null;
            try { host = fi.Host; } catch { }

            if (host == null)
            {
                return new HostInfo
                {
                    Kind = HostKind.None,
                    Detail = "no host (FamilyInstance.Host is null)" + FaceNote(fi),
                    ShortText = "no host (unhosted)"
                };
            }

            if (host is RevitLinkInstance link)
                return ClassifyLinked(fi, link);

            if (host is Level)
            {
                return new HostInfo
                {
                    Kind = HostKind.Level,
                    Detail = "level / work plane '" + SafeName(host) + "' " + host.Id + FaceNote(fi),
                    ShortText = "work plane / level '" + SafeName(host) + "', not a vertical face"
                };
            }

            if (IsCeiling(host))
            {
                return new HostInfo
                {
                    Kind = HostKind.Ceiling,
                    HostIdentity = SafeUniqueId(host),
                    Detail = "native ceiling " + host.Id,
                    ShortText = "ceiling " + host.Id
                };
            }

            if (IsExcludedHorizontalHost(host))
            {
                return new HostInfo
                {
                    Kind = HostKind.Other,
                    Detail = "native excluded horizontal host " + DescribeElement(host),
                    ShortText = DescribeCategory(host) + " (floor / roof / horizontal host)"
                };
            }

            // Traditional wall-hosted families may have NO HostFace (as opposed to
            // work-plane/face-hosted ones). Preserve their proven-wall behavior.
            Reference reference = SafeHostFace(fi);
            if (IsWall(host) && reference == null)
            {
                return new HostInfo
                {
                    Kind = HostKind.Wall,
                    HostIdentity = SafeUniqueId(host),
                    Detail = "native wall " + host.Id + " '" + SafeName(host) + "' (wall-hosted)",
                    ShortText = "wall " + host.Id
                };
            }

            if (reference == null)
                return UnsafeHost("native " + DescribeElement(host) + " has no HostFace", DescribeCategory(host), false);

            if (!TryGetVerticalHostFace(fi, host, reference, null, out string reason))
                return UnsafeHost("native " + DescribeElement(host) + ": " + reason,
                    DescribeCategory(host) + " (" + reason + ")", false);

            bool wall = IsWall(host);
            string nativeStable = SafeStableReference(fi, reference);
            if (!wall && string.IsNullOrEmpty(nativeStable))
                return UnsafeHost("native " + DescribeElement(host) + ": face reference cannot be tracked",
                    DescribeCategory(host) + " (unverifiable face reference)", false);

            return new HostInfo
            {
                Kind = wall ? HostKind.Wall : HostKind.VerticalFace,
                HostIdentity = SafeUniqueId(host),
                FaceStableReference = nativeStable,
                Detail = "native " + (wall ? "wall" : "vertical face") + " " +
                         DescribeElement(host) + " | face normal verified nearly horizontal",
                ShortText = (wall ? "wall " : "vertical face of ") + DescribeCategory(host)
            };
        }

        private static HostInfo ClassifyLinked(FamilyInstance fi, RevitLinkInstance link)
        {
            string linkText = "link instance " + link.Id + " '" + SafeName(link) + "'";
            var result = UnsafeHost(linkText + ": unresolved linked host", "unverified linked host", true);
            result.IsLinked = true;
            result.LinkProblem = true;

            try
            {
                Reference reference = SafeHostFace(fi);
                if (reference == null)
                {
                    result.Detail = linkText + ": no HostFace reference";
                    return result;
                }

                ElementId linkedId = reference.LinkedElementId;
                if (linkedId == null || linkedId == ElementId.InvalidElementId)
                {
                    result.Detail = linkText + ": HostFace has no LinkedElementId";
                    return result;
                }

                Document linkDoc = link.GetLinkDocument();
                if (linkDoc == null)
                {
                    result.Detail = linkText + ": link is not loaded";
                    return result;
                }

                Element linkedHost = linkDoc.GetElement(linkedId);
                if (linkedHost == null)
                {
                    result.Detail = linkText + " '" + SafeTitle(linkDoc) +
                                    "': linked element " + linkedId + " not found (nested link?)";
                    return result;
                }

                string linkedText = DescribeElement(linkedHost) + " in '" +
                                    SafeTitle(linkDoc) + "' via " + linkText;
                result.LinkProblem = false;

                if (IsCeiling(linkedHost))
                {
                    result.Kind = HostKind.Ceiling;
                    result.Detail = "linked ceiling " + linkedText;
                    result.ShortText = "linked ceiling " + linkedId;
                    return result;
                }

                if (IsExcludedHorizontalHost(linkedHost))
                {
                    result.Detail = "linked excluded horizontal host " + linkedText;
                    result.ShortText = "linked floor / roof / horizontal host " + linkedId;
                    return result;
                }

                if (!IsInstanceNearLinkedHost(fi, link, linkedHost))
                {
                    result.LinkProblem = true;
                    result.Detail = "linked " + linkedText +
                                    " FAILED proximity check (potential wrong/nested link)";
                    result.ShortText = "linked face that failed proximity verification";
                    return result;
                }

                if (!TryGetVerticalHostFace(fi, linkedHost, reference, link, out string reason))
                {
                    result.Detail = "linked " + linkedText + ": " + reason;
                    result.ShortText = "linked " + DescribeCategory(linkedHost) + " (" + reason + ")";
                    return result;
                }

                bool wall = IsWall(linkedHost);
                string linkedStable = SafeStableReference(fi, reference);
                if (!wall && string.IsNullOrEmpty(linkedStable))
                {
                    result.Detail = "linked " + linkedText + ": face reference cannot be tracked";
                    result.ShortText = "unverifiable linked face reference";
                    return result;
                }
                result.Kind = wall ? HostKind.Wall : HostKind.VerticalFace;
                result.HostIdentity = SafeUniqueId(link) + ":" + SafeUniqueId(linkedHost);
                result.FaceStableReference = linkedStable;
                result.Detail = "linked " + (wall ? "wall" : "vertical face") + " " +
                                linkedText + " | face normal verified nearly horizontal";
                result.ShortText = "linked " + (wall ? "wall " : "vertical face of ") + linkedId;
                return result;
            }
            catch (Exception ex)
            {
                result.Kind = HostKind.Other;
                result.LinkProblem = true;
                result.Detail = linkText + ": link classification error: " + ex.Message;
                return result;
            }
        }

        /// <summary>After a vertical-face correction, ensure SAME host and SAME face.</summary>
        public static bool VerifySameVerticalHost(FamilyInstance fi, HostInfo before, out string reason)
        {
            reason = "";
            if (before == null || (before.Kind != HostKind.VerticalFace && before.Kind != HostKind.Wall) ||
                string.IsNullOrEmpty(before.HostIdentity))
            {
                reason = "original vertical host identity unavailable";
                return false;
            }

            HostInfo after = Classify(fi);
            if (after.Kind != before.Kind ||
                !string.Equals(after.HostIdentity, before.HostIdentity, StringComparison.Ordinal))
            {
                reason = "host changed or vertical face no longer verified: " + after;
                return false;
            }

            // Traditional wall-hosted families have no HostFace. Their host must
            // remain the same wall and no new face reference may appear.
            if (before.Kind == HostKind.Wall && string.IsNullOrEmpty(before.FaceStableReference))
            {
                if (string.IsNullOrEmpty(after.FaceStableReference)) return true;
                reason = "wall hosting mode changed";
                return false;
            }

            if (string.IsNullOrEmpty(before.FaceStableReference) ||
                string.IsNullOrEmpty(after.FaceStableReference) ||
                !string.Equals(before.FaceStableReference, after.FaceStableReference, StringComparison.Ordinal))
            {
                reason = "host face reference changed or could not be verified";
                return false;
            }

            // A reference may remain stable even if the requested elevation goes
            // ABOVE/BELOW a short glass panel. Check the new insertion point is
            // still physically on its trimmed host face (within 100 mm).
            if (!IsPointNearCurrentHostFace(fi, out reason))
                return false;

            return true;
        }

        private static bool IsPointNearCurrentHostFace(FamilyInstance fi, out string reason)
        {
            reason = "";
            try
            {
                if (!(fi.Location is LocationPoint lp))
                {
                    reason = "corrected element has no location point";
                    return false;
                }
                if (!HostFaceGeometry.TryResolve(fi, out HostFaceGeometry geometry, out reason) ||
                    !geometry.TryProject(lp.Point, out XYZ onFace, out XYZ normal, out reason))
                    return false;
                if (onFace.DistanceTo(lp.Point) > 100.0 / 304.8)
                {
                    reason = "new position is over 100 mm from its resolved host face";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                reason = "could not confirm new point lies on host face: " + ex.Message;
                return false;
            }
        }

        private static HostInfo UnsafeHost(string detail, string shortText, bool linkProblem) =>
            new HostInfo { Kind = HostKind.Other, Detail = detail, ShortText = shortText,
                           LinkProblem = linkProblem };

        private static Reference SafeHostFace(FamilyInstance fi)
        {
            try { return fi.HostFace; } catch { return null; }
        }

        private static string SafeStableReference(FamilyInstance fi, Reference reference)
        {
            try { return reference.ConvertToStableRepresentation(fi.Document); }
            catch { return null; }
        }

        private static bool TryGetVerticalHostFace(FamilyInstance fi, Element host,
            Reference hostFace, RevitLinkInstance link, out string reason)
        {
            reason = "";
            try
            {
                if (!(fi.Location is LocationPoint lp))
                {
                    reason = "hosted instance has no point location";
                    return false;
                }
                if (!HostFaceGeometry.TryResolve(host, hostFace, link, out HostFaceGeometry geometry, out reason) ||
                    !geometry.TryProject(lp.Point, out XYZ onFace, out XYZ normal, out reason))
                    return false;
                // Includes both the panel/family instance transform and link transform.
                double vertical = Math.Abs(normal.Z);

                if (vertical > MaxVerticalNormalZ)
                {
                    reason = "horizontal or sloped host face (normal Z=" +
                             vertical.ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ")";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                reason = "could not verify host face geometry: " + ex.Message;
                return false;
            }
        }

        private static bool IsInstanceNearLinkedHost(FamilyInstance fi, RevitLinkInstance link, Element linkedHost)
        {
            if (!(fi.Location is LocationPoint lp))
                return false;
            BoundingBoxXYZ bb = linkedHost.get_BoundingBox(null);
            if (bb == null)
                return false;

            XYZ p = link.GetTotalTransform().Inverse.OfPoint(lp.Point);
            // Apply the box transform to all 8 corners: two corners alone are NOT
            // enough for transformed/rotated bounding boxes.
            double x0 = double.PositiveInfinity, y0 = double.PositiveInfinity, z0 = double.PositiveInfinity;
            double x1 = double.NegativeInfinity, y1 = double.NegativeInfinity, z1 = double.NegativeInfinity;
            foreach (double x in new[] { bb.Min.X, bb.Max.X })
            foreach (double y in new[] { bb.Min.Y, bb.Max.Y })
            foreach (double z in new[] { bb.Min.Z, bb.Max.Z })
            {
                XYZ q = bb.Transform.OfPoint(new XYZ(x, y, z));
                x0 = Math.Min(x0, q.X); y0 = Math.Min(y0, q.Y); z0 = Math.Min(z0, q.Z);
                x1 = Math.Max(x1, q.X); y1 = Math.Max(y1, q.Y); z1 = Math.Max(z1, q.Z);
            }
            double t = LinkedProximityToleranceFeet;
            return p.X >= x0 - t && p.X <= x1 + t &&
                   p.Y >= y0 - t && p.Y <= y1 + t &&
                   p.Z >= z0 - t && p.Z <= z1 + t;
        }

        public static bool IsWall(Element e) =>
            e is Wall && CategoryIs(e, BuiltInCategory.OST_Walls);
        public static bool IsCeiling(Element e) =>
            CategoryIs(e, BuiltInCategory.OST_Ceilings);

        private static bool IsExcludedHorizontalHost(Element host) =>
            host is Floor || host is RoofBase ||
            CategoryIs(host, BuiltInCategory.OST_Floors) ||
            CategoryIs(host, BuiltInCategory.OST_Roofs) ||
            CategoryIs(host, BuiltInCategory.OST_Ramps) ||
            CategoryIs(host, BuiltInCategory.OST_Stairs) ||
            CategoryIs(host, BuiltInCategory.OST_StairsRuns) ||
            CategoryIs(host, BuiltInCategory.OST_StairsLandings) ||
            CategoryIs(host, BuiltInCategory.OST_StructuralFoundation);

        public static bool CategoryIs(Element e, BuiltInCategory bic)
        {
            try
            {
                Category c = e?.Category;
                return c != null && c.Id.Value == (long)bic;
            }
            catch { return false; }
        }

        private static string FaceNote(FamilyInstance fi)
        {
            try
            {
                Reference r = fi.HostFace;
                if (r == null) return " | HostFace: none";
                string text = " | HostFace: element " + r.ElementId;
                if (r.LinkedElementId != null && r.LinkedElementId != ElementId.InvalidElementId)
                    text += ", linked element " + r.LinkedElementId;
                return text;
            }
            catch { return " | HostFace: unavailable"; }
        }

        private static string DescribeElement(Element e)
        {
            try
            {
                return (e.Category?.Name ?? "no category") + " " + e.Id +
                       " [" + e.GetType().Name + "] '" + SafeName(e) + "'";
            }
            catch { return "unknown element"; }
        }
        private static string DescribeCategory(Element e)
        {
            try { return (e.Category?.Name ?? e.GetType().Name) + " " + e.Id; }
            catch { return "unknown host"; }
        }
        private static string SafeUniqueId(Element e)
        {
            try { return e?.UniqueId ?? ""; } catch { return ""; }
        }
        private static string SafeName(Element e)
        {
            try { return e?.Name ?? "?"; } catch { return "?"; }
        }
        private static string SafeTitle(Document d)
        {
            try { return d.Title; } catch { return "?"; }
        }
    }
}

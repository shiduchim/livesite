using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EK.LastSimilar.Services
{
    public static class HeightModes
    {
        public const string Last = "last";
        public const string Standard = "standard";

        public static bool IsStandard(string mode) =>
            string.Equals(mode, Standard, StringComparison.OrdinalIgnoreCase);
    }

    public static class RecentItemKinds
    {
        public const string Family = "family";
        public const string DetailLine = "detail-line";
        public const string ModelLine = "model-line";
        public const string RoomTag = "room-tag";

        // v4.1: other annotation tags. "tag" = IndependentTag (category, multi-category
        // and material tags). Like Room Tags they are placed natively and never get
        // height settings.
        public const string Tag = "tag";
        public const string SpaceTag = "space-tag";
        public const string AreaTag = "area-tag";

        public static bool IsRoomTag(string kind) =>
            string.Equals(kind, RoomTag, StringComparison.OrdinalIgnoreCase);

        public static bool IsIndependentTag(string kind) =>
            string.Equals(kind, Tag, StringComparison.OrdinalIgnoreCase);

        public static bool IsSpaceTag(string kind) =>
            string.Equals(kind, SpaceTag, StringComparison.OrdinalIgnoreCase);

        public static bool IsAreaTag(string kind) =>
            string.Equals(kind, AreaTag, StringComparison.OrdinalIgnoreCase);

        /// <summary>Any annotation tag kind (Room, Space, Area or category/multi-category/material tag).</summary>
        public static bool IsTag(string kind) =>
            IsRoomTag(kind) || IsIndependentTag(kind) || IsSpaceTag(kind) || IsAreaTag(kind);

        // v4.2: any other element Revit places with its own tool (text notes, walls, MEP runs,
        // accessories, stairs, railings, groups, callouts, framing, columns, regions,
        // dimensions, spot elevations). Re-placed natively; never height-corrected.
        // RecentTypeState.ElementKind says which one.
        public const string Element = "element";

        public static bool IsElement(string kind) =>
            string.Equals(kind, Element, StringComparison.OrdinalIgnoreCase);

        /// <summary>Kinds that never carry or get heights: lines, tags and native elements.</summary>
        public static bool HasNoHeight(string kind) =>
            IsLine(kind) || IsTag(kind) || IsElement(kind);

        public static bool IsLine(string kind) =>
            string.Equals(kind, DetailLine, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(kind, ModelLine, StringComparison.OrdinalIgnoreCase);

        public static bool IsDetailLine(string kind) =>
            string.Equals(kind, DetailLine, StringComparison.OrdinalIgnoreCase);

        public static bool IsModelLine(string kind) =>
            string.Equals(kind, ModelLine, StringComparison.OrdinalIgnoreCase);
    }

    // NOTE: DataContractJsonSerializer does NOT run constructors or property
    // initializers when reading JSON. Every consumer must tolerate nulls.
    [DataContract]
    public class AppState
    {
        [DataMember] public int Version { get; set; } = 8;

        // Recent 5 visual preferences. Nullable so older state files can use
        // the intended defaults when these fields do not exist yet.
        [DataMember] public bool? UseFamilyThumbnails { get; set; } = true;
        [DataMember] public int? FamilyThumbnailSize { get; set; } = 24;

        // Troubleshooting is intentionally OFF by default. When enabled,
        // the detailed rolling log and skipped-placement warning dialogs are active.
        [DataMember] public bool? DiagnosticsEnabled { get; set; } = false;

        // Global preference for ALL projects; absent in earlier JSON means enabled.
        [DataMember] public bool? HeightCorrectionsEnabled { get; set; } = true;

        // v4.2: warn after an EK placement when the placed item is not visible in the view.
        // Absent in earlier JSON means enabled.
        [DataMember] public bool? WarnHiddenPlacements { get; set; } = true;

        [DataMember] public Dictionary<string, DocumentState> Documents { get; set; }
            = new Dictionary<string, DocumentState>();
    }

    [DataContract]
    public class DocumentState
    {
        [DataMember] public string LastSymbolUniqueId { get; set; }
        [DataMember] public List<RecentTypeState> History { get; set; }
            = new List<RecentTypeState>();

        // v3.2: used only to prune projects that have not been touched for a long time.
        [DataMember] public long LastTouchedUtcTicks { get; set; }
    }

    [DataContract]
    public class RecentTypeState
    {
        // Historical name kept for backward compatibility. For families this is the
        // FamilySymbol.UniqueId. For lines it is a synthetic stable key based on
        // line kind + GraphicsStyle.UniqueId.
        [DataMember] public string SymbolUniqueId { get; set; }

        // Missing/null in old state files means Family.
        [DataMember] public string ItemKind { get; set; } = RecentItemKinds.Family;

        // Line style is line-only; source element is also used by native Room Tag placement.
        [DataMember] public string LineStyleUniqueId { get; set; }
        [DataMember] public string SourceElementUniqueId { get; set; }

        // v4.2: for ItemKind "element" only: which element (see ElementKinds).
        [DataMember] public string ElementKind { get; set; }

        [DataMember] public string FamilyName { get; set; }
        [DataMember] public string TypeName { get; set; }
        [DataMember] public string CategoryName { get; set; }

        // BuiltInCategory as a 64-bit value (language independent). Null in v1 state files.
        [DataMember] public long? CategoryIdValue { get; set; }

        // "last" or "standard"
        [DataMember] public string HeightMode { get; set; } = HeightModes.Last;

        [DataMember] public double? LastWallHeightFeet { get; set; }
        [DataMember] public double? StandardHeightMm { get; set; }

        // Per-family-type preference; absent in earlier JSON means enabled.
        [DataMember] public bool? HeightCorrectionEnabled { get; set; } = true;
        [DataMember] public bool Favorite { get; set; }

        // Settings-window-only ordering preference. This does NOT change true placement
        // chronology or Recent 5. A real new placement clears it automatically.
        [DataMember] public bool SettingsBottom { get; set; }
        // Ordering only inside Settings. Larger/newer values are farther down.
        [DataMember] public long SettingsBottomOrderTicks { get; set; }

        // Updated ONLY when an instance of this type is actually placed.
        [DataMember] public long LastUsedUtcTicks { get; set; }
    }

    /// <summary>
    /// Plain data describing one real placement. Built from Revit objects OUTSIDE the
    /// state-file lock, then written by StateStore.RecordPlacement.
    /// </summary>
    public sealed class PlacementRecord
    {
        public string SymbolUniqueId { get; set; }
        public string ItemKind { get; set; } = RecentItemKinds.Family;
        public string LineStyleUniqueId { get; set; }
        public string SourceElementUniqueId { get; set; }
        public string ElementKind { get; set; }

        public string FamilyName { get; set; }
        public string TypeName { get; set; }
        public string CategoryName { get; set; }
        public long? CategoryIdValue { get; set; }
        public double? LearnedWallHeightFeet { get; set; }
    }

    public class RecentResolvedItem
    {
        public RecentTypeState State { get; set; }
        public Autodesk.Revit.DB.FamilySymbol Symbol { get; set; }
        public Autodesk.Revit.DB.GraphicsStyle LineStyle { get; set; }
        public Autodesk.Revit.DB.CurveElement SourceCurve { get; set; }
        public System.Windows.Media.ImageSource Icon { get; set; }
        public double VisualSize { get; set; } = 18;

        public bool IsLine => RecentItemKinds.IsLine(State?.ItemKind);

        /// <summary>v4.2 native element (wall, duct, text note, ...). Its type is ElementType.</summary>
        public bool IsElement => RecentItemKinds.IsElement(State?.ItemKind);

        /// <summary>Type of a native element. For family-based ones (beams, columns,
        /// accessories) this is the same FamilySymbol as Symbol.</summary>
        public Autodesk.Revit.DB.ElementType ElementType { get; set; }

        /// <summary>Only family types (not tags, lines or native elements) have height settings.</summary>
        public bool HasHeightSettings => State != null && !IsLine && !IsTag && !IsElement;
        public bool IsRoomTag => RecentItemKinds.IsRoomTag(State?.ItemKind) ||
            Symbol is Autodesk.Revit.DB.Architecture.RoomTagType;

        /// <summary>Any annotation tag: no height settings, native tag placement.</summary>
        public bool IsTag => IsRoomTag || RecentItemKinds.IsTag(State?.ItemKind);

        public string PrimaryText
        {
            get
            {
                string type = State?.TypeName ?? "";
                return string.IsNullOrWhiteSpace(type)
                    ? (State?.FamilyName ?? "")
                    : type;
            }
        }

        public string FamilyText => State?.FamilyName ?? "";

        public string CategoryText => State?.CategoryName ?? "";

        public string SecondaryText
        {
            get
            {
                string family = FamilyText;
                string category = CategoryText;
                if (string.IsNullOrWhiteSpace(category))
                    return family;
                if (string.IsNullOrWhiteSpace(family))
                    return category;
                return family + "  /  " + category;
            }
        }

        public string ToolTipText
        {
            get
            {
                string text = FamilyText + " : " + PrimaryText;
                return string.IsNullOrWhiteSpace(CategoryText) ? text : text + "\n" + CategoryText;
            }
        }

        public string HeightText
        {
            get
            {
                if (!HasHeightSettings) return "";
                if (State.HeightCorrectionEnabled == false) return "Height off";
                if (HeightModes.IsStandard(State.HeightMode))
                {
                    return State.StandardHeightMm.HasValue
                        ? $"Fixed {State.StandardHeightMm.Value / 10.0:0.#} cm"
                        : "Fixed (not set)";
                }

                return State.LastWallHeightFeet.HasValue
                    ? $"Last {State.LastWallHeightFeet.Value * 30.48:0.#} cm"
                    : "Not learned yet";
            }
        }

        public string FavoriteText => State != null && State.Favorite ? "★" : "";

    }
}

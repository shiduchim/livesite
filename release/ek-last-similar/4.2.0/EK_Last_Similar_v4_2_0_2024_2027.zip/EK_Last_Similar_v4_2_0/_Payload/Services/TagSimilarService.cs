using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace EK.LastSimilar.Services
{
    // Annotation tags other than Room Tags:
    //   - IndependentTag: category tags (fixture, device, equipment, conduit, ...),
    //     multi-category tags and material tags,
    //   - Space Tags and Area Tags.
    // Same rules as RoomTagSimilarService: native Revit placement of the exact
    // remembered tag type only. No application transaction, no family capture
    // session, no height correction, never a default-type substitution and never
    // a custom pick/create loop. Keynote tags are deliberately not tracked: their
    // element/material/user keynote mode is not part of the tag type.
    internal static class TagSimilarService
    {
        internal static string KindOf(Element e)
        {
            if (e is IndependentTag) return RecentItemKinds.Tag;
            if (e is Autodesk.Revit.DB.Mechanical.SpaceTag) return RecentItemKinds.SpaceTag;
            if (e is AreaTag) return RecentItemKinds.AreaTag;
            return null;
        }

        /// <summary>
        /// A single tag the user placed. addedInSameCommit lets "Tag on Placement" be
        /// recognised: a category tag of an element created in the same commit is an
        /// automatic companion of that placement, not a tag placement of its own.
        /// </summary>
        internal static bool IsTrackable(Element tag, ICollection<ElementId> addedInSameCommit)
        {
            try
            {
                if (KindOf(tag) == null || !tag.IsValidObject)
                    return false;

                if (tag.GroupId != ElementId.InvalidElementId)
                    return false;

                if (tag.OwnerViewId == ElementId.InvalidElementId)
                    return false;

                Category c = tag.Category;
                if (c != null && c.Id.Value == (long)BuiltInCategory.OST_KeynoteTags)
                    return false;

                if (!StateStore.IsUsableSymbol(GetTagType(tag)))
                    return false;

                if (tag is IndependentTag it && TagsElementAddedInSameCommit(it, addedInSameCommit))
                    return false;

                return true;
            }
            catch
            {
                return false;
            }
        }

        internal static PlacementRecord BuildRecord(Element tag)
        {
            string kind = KindOf(tag);
            if (kind == null)
                return null;

            PlacementRecord record = StateStore.BuildRecord(GetTagType(tag));
            if (record == null)
                return null;

            record.ItemKind = kind;
            record.SourceElementUniqueId = tag.UniqueId;
            record.LearnedWallHeightFeet = null;
            return record;
        }

        internal static Result Start(UIApplication uiapp, FamilySymbol type, RecentTypeState entry)
        {
            UIDocument uidoc = uiapp?.ActiveUIDocument;
            if (uidoc == null || !StateStore.IsUsableSymbol(type))
                return Result.Cancelled;

            string kind = entry?.ItemKind ?? RecentItemKinds.Tag;
            string label = Label(kind);

            try
            {
                // Category / multi-category / material tags: only start where Revit allows tagging.
                if (RecentItemKinds.IsIndependentTag(kind))
                {
                    RevitCommandId tagCommand = RevitCommandId.LookupPostableCommandId(PostableCommand.TagByCategory);
                    if (tagCommand == null || !uiapp.CanPostCommand(tagCommand))
                    {
                        CommandRunner.SafeDialog("Tagging is not available in the current view. Open a view where Revit allows tags.");
                        return Result.Cancelled;
                    }
                }

                if (uidoc.CanPlaceElementType(type))
                {
                    // Queue the precise tag type: Revit's own tag tool with that type.
                    uidoc.PostRequestForElementTypePlacement(type);
                    RunLog.Add(label + " native placement queued: " + type.FamilyName + " : " + type.Name +
                        " | type=" + type.Id.Value + " | height correction disabled");
                    VisibilityWatch.Expect(uidoc.Document, uidoc.ActiveView, type.Id, label + " \"" + type.Name + "\"");
                    return Result.Succeeded;
                }

                // Some tag types cannot be queued through the ElementType API. Use native
                // Create Similar only with an actual tag of that exact type in the current
                // view; never silently use the default tag type.
                Element source = FindSource(uidoc, type, entry, kind);
                if (source == null)
                {
                    CommandRunner.SafeDialog("Revit cannot start this " + label + " type directly here. " +
                        "Place one tag of this type in the current view, then use Last Similar.");
                    return Result.Cancelled;
                }

                ICollection<ElementId> oldSelection = uidoc.Selection.GetElementIds();
                bool posted = false;
                try
                {
                    uidoc.Selection.SetElementIds(new List<ElementId> { source.Id });
                    RevitCommandId similar = RevitCommandId.LookupPostableCommandId(PostableCommand.CreateSimilar);
                    if (similar == null || !uiapp.CanPostCommand(similar))
                    {
                        CommandRunner.SafeDialog("Revit Create Similar is not available for this " + label + " in the current view.");
                        return Result.Cancelled;
                    }

                    uiapp.PostCommand(similar);
                    posted = true;
                    RunLog.Add(label + " Create Similar queued from tag " + source.Id.Value +
                        " | type=" + type.Id.Value + " | height correction disabled");
                    VisibilityWatch.Expect(uidoc.Document, uidoc.ActiveView, type.Id, label + " \"" + type.Name + "\"");
                    return Result.Succeeded;
                }
                finally
                {
                    if (!posted)
                        try { uidoc.Selection.SetElementIds(oldSelection); } catch { }
                }
            }
            catch (Exception ex)
            {
                RunLog.Add(label + " placement unavailable: " + ex.Message);
                CommandRunner.SafeDialog("Could not start native " + label + " placement.\n\n" + ex.Message);
                return Result.Cancelled;
            }
        }

        // ------------------------------------------------------------------

        internal static FamilySymbol GetTagType(Element tag)
        {
            try
            {
                return tag?.Document?.GetElement(tag.GetTypeId()) as FamilySymbol;
            }
            catch
            {
                return null;
            }
        }

        private static bool TagsElementAddedInSameCommit(IndependentTag tag, ICollection<ElementId> added)
        {
            if (added == null || added.Count == 0)
                return false;

            try
            {
                foreach (ElementId id in tag.GetTaggedLocalElementIds())
                {
                    if (id != null && added.Contains(id))
                        return true;
                }
            }
            catch
            {
                // Unknown: treat as a companion tag so it can never hide a real
                // family placement in the same commit.
                return true;
            }

            return false;
        }

        private static Element FindSource(UIDocument uidoc, FamilySymbol type, RecentTypeState entry, string kind)
        {
            Document doc = uidoc.Document;
            View view = uidoc.ActiveView;
            if (doc == null || view == null)
                return null;

            Element source = null;
            if (!string.IsNullOrEmpty(entry?.SourceElementUniqueId))
            {
                try { source = doc.GetElement(entry.SourceElementUniqueId); } catch { }
            }

            if (Matches(source, type, view, kind))
                return source;

            // Room/Space/Area tags must be collected as SpatialElementTag (Revit rejects
            // OfClass on the derived API classes). IndependentTag is a native class.
            Type cls = RecentItemKinds.IsIndependentTag(kind) ? typeof(IndependentTag) : typeof(SpatialElementTag);

            return new FilteredElementCollector(doc, view.Id)
                .OfClass(cls)
                .FirstOrDefault(x => Matches(x, type, view, kind));
        }

        private static bool Matches(Element tag, FamilySymbol type, View view, string kind)
        {
            try
            {
                return tag != null &&
                       string.Equals(KindOf(tag), kind, StringComparison.OrdinalIgnoreCase) &&
                       IsTrackable(tag, null) &&
                       tag.GetTypeId() == type.Id &&
                       tag.OwnerViewId == view.Id;
            }
            catch
            {
                return false;
            }
        }

        private static string Label(string kind)
        {
            if (RecentItemKinds.IsSpaceTag(kind)) return "Space Tag";
            if (RecentItemKinds.IsAreaTag(kind)) return "Area Tag";
            return "Tag";
        }
    }
}

using System;
using Autodesk.Revit.DB;

namespace EK.LastSimilar.Services
{
    // Read-only resolver. A referenced family face is NOT necessarily in document
    // coordinates. Follow its exact reference through the geometry tree and retain
    // each GeometryInstance.Transform. Never guess by face index, area or proximity.
    internal sealed class HostFaceGeometry
    {
        internal Face Face { get; private set; }
        internal Transform FaceToModel { get; private set; }

        internal static bool TryResolve(FamilyInstance fi, out HostFaceGeometry result, out string reason)
        {
            result = null;
            reason = "";
            try
            {
                Element host = fi.Host;
                Reference reference = fi.HostFace;
                RevitLinkInstance link = host as RevitLinkInstance;
                if (link != null)
                    host = link.GetLinkDocument()?.GetElement(reference?.LinkedElementId);
                return TryResolve(host, reference, link, out result, out reason);
            }
            catch (Exception ex) { reason = "host face resolution failed: " + ex.Message; return false; }
        }

        internal static bool TryResolve(Element host, Reference reference, RevitLinkInstance link,
            out HostFaceGeometry result, out string reason)
        {
            result = null;
            reason = "";
            try
            {
                if (host == null || reference == null || host is RevitLinkInstance)
                { reason = "host/face unavailable or nested link unsupported"; return false; }
                Reference local = link == null ? reference : reference.CreateReferenceInLink();
                if (local == null || local.ElementId != host.Id)
                { reason = "face reference does not identify the resolved host"; return false; }
                string stable = local.ConvertToStableRepresentation(host.Document);
                if (string.IsNullOrEmpty(stable))
                { reason = "face reference has no stable identity"; return false; }

                // GetSymbolGeometry() retains original references. Its overload with
                // a transform and GetInstanceGeometry() return copies; do not use them.
                using (var options = new Options { ComputeReferences = true, IncludeNonVisibleObjects = true })
                {
                    GeometryElement root = host.get_Geometry(options);
                    int budget = 20000, matches = 0;
                    HostFaceGeometry found = null;
                    Walk(root, link == null ? Transform.Identity : link.GetTotalTransform(),
                        host.Document, stable, 0, ref budget, ref matches, ref found);
                    if (matches != 1)
                    {
                        reason = matches == 0 ? "exact host face not found in original geometry" :
                            "host face geometry is ambiguous";
                        return false;
                    }
                    result = found;
                }
                return true;
            }
            catch (Exception ex) { reason = "host face resolution failed: " + ex.Message; return false; }
        }

        private static void Walk(GeometryElement geometry, Transform toModel, Document doc, string stable,
            int depth, ref int budget, ref int matches, ref HostFaceGeometry found)
        {
            if (geometry == null) return;
            if (depth > 16) throw new InvalidOperationException("geometry nesting limit reached");
            foreach (GeometryObject item in geometry)
            {
                if (--budget < 0) throw new InvalidOperationException("geometry inspection limit reached");
                if (item is GeometryInstance instance)
                    Walk(instance.GetSymbolGeometry(), toModel.Multiply(instance.Transform), doc, stable,
                        depth + 1, ref budget, ref matches, ref found);
                else if (item is Solid solid)
                    foreach (Face face in solid.Faces)
                    {
                        if (--budget < 0) throw new InvalidOperationException("geometry inspection limit reached");
                        Match(face, toModel, doc, stable, ref matches, ref found);
                    }
                else if (item is Face face)
                    Match(face, toModel, doc, stable, ref matches, ref found);
            }
        }

        private static void Match(Face face, Transform toModel, Document doc, string stable,
            ref int matches, ref HostFaceGeometry found)
        {
            Reference candidate = face.Reference;
            if (candidate == null || !string.Equals(candidate.ConvertToStableRepresentation(doc), stable,
                StringComparison.Ordinal)) return;
            matches++;
            found = new HostFaceGeometry { Face = face, FaceToModel = toModel };
        }

        internal bool TryProject(XYZ point, out XYZ projected, out XYZ normal, out string reason)
        {
            projected = null;
            normal = null;
            reason = "";
            try
            {
                XYZ local = FaceToModel.Inverse.OfPoint(point);
                IntersectionResult hit = Face.Project(local);
                if (hit?.XYZPoint == null || hit.UVPoint == null || !Face.IsInside(hit.UVPoint))
                { reason = "point projects outside the trimmed host face"; return false; }
                projected = FaceToModel.OfPoint(hit.XYZPoint);
                normal = FaceToModel.OfVector(Face.ComputeNormal(hit.UVPoint)).Normalize();
                return true;
            }
            catch (Exception ex) { reason = "host face projection failed: " + ex.Message; return false; }
        }

        internal bool ValidateMove(XYZ before, XYZ target, out XYZ offset, out string reason)
        {
            offset = null;
            if (!TryProject(before, out XYZ onBefore, out XYZ normalBefore, out reason)) return false;
            if (!TryProject(target, out XYZ onTarget, out XYZ normalTarget, out reason)) return false;
            if (Math.Abs(normalBefore.Z) > 0.12 || Math.Abs(normalTarget.Z) > 0.12)
            { reason = "mounting face is not vertical in model coordinates"; return false; }
            offset = before - onBefore;
            if (offset.GetLength() > 100.0 / 304.8)
            { reason = "original insertion point is over 100 mm from its host face"; return false; }
            // Preserve the existing family mounting offset, including its side of
            // the face. A Z-only correction must not move it away from the surface.
            if ((target - onTarget).DistanceTo(offset) > 0.5 / 304.8)
            { reason = "vertical correction would change the mounting offset"; return false; }
            return true;
        }

        internal static bool SameBasis(Transform before, Transform after)
        {
            // Compare physical axes, not LocationPoint.Rotation, which Revit can
            // report differently for an unchanged face-hosted orientation.
            return before != null && after != null &&
                before.BasisX.DistanceTo(after.BasisX) <= 1e-6 &&
                before.BasisY.DistanceTo(after.BasisY) <= 1e-6 &&
                before.BasisZ.DistanceTo(after.BasisZ) <= 1e-6;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;

namespace EK.LastSimilar.Services
{
    public enum CorrectionStatus
    {
        NoChangeNeeded,
        Corrected,
        Skipped,   // not attempted: rules/parameters say "do not touch"
        Failed     // attempted, verified wrong or rejected => rolled back, element untouched
    }

    public sealed class CorrectionResult
    {
        public CorrectionStatus Status { get; set; }
        public string Message { get; set; }

        // ---- Diagnostics (v3.9.4). Never used for decisions. ----

        /// <summary>True once a correction transaction was actually started for this element.</summary>
        public bool Attempted { get; set; }

        /// <summary>none / not started / committed / rolled back ...</summary>
        public string Transaction { get; set; } = "none";

        public LevelPick Pick { get; set; }
        public double? TargetFeet { get; set; }

        /// <summary>Element state after the correction (or after its rollback).</summary>
        public string After { get; set; }

        /// <summary>Orientation before/after comparison. Logged only, never blocks.</summary>
        public string Orientation { get; set; }

        public List<string> Notes { get; } = new List<string>();

        public CorrectionResult Set(CorrectionStatus s, string msg)
        {
            Status = s;
            Message = msg;
            return this;
        }

        public static CorrectionResult Of(CorrectionStatus s, string msg) =>
            new CorrectionResult { Status = s, Message = msg };
    }

    public sealed class LevelZ
    {
        public Level Level { get; set; }
        public double Z { get; set; }   // Level.ProjectElevation (same frame as LocationPoint.Z)
    }

    /// <summary>The chosen level plus everything needed to explain the choice in the log.</summary>
    public sealed class LevelPick
    {
        public LevelZ Chosen { get; set; }
        public string Rule { get; set; } = "";
        public List<LevelZ> Twins { get; } = new List<LevelZ>();
        public LevelZ NextBelow { get; set; }
        public LevelZ NextAbove { get; set; }

        public string Describe()
        {
            var sb = new StringBuilder();

            if (Chosen == null)
                sb.Append("NONE (").Append(Rule).Append(")");
            else
                sb.Append(LevelHeightService.LevelText(Chosen)).Append("  [").Append(Rule).Append("]");

            if (Twins.Count > 1)
            {
                sb.Append("  | same-elevation levels: ");
                sb.Append(string.Join(", ", Twins.Select(t => LevelHeightService.LevelText(t))));
            }

            sb.Append("  | next lower: ").Append(NextBelow == null ? "-" : LevelHeightService.LevelText(NextBelow));
            sb.Append("  | next higher: ").Append(NextAbove == null ? "-" : LevelHeightService.LevelText(NextAbove));
            return sb.ToString();
        }
    }

    /// <summary>
    /// Read-only orientation snapshot for diagnostics and physical flip-state checks.
    /// v4.0.3: physical instance axes and flip states must survive a height correction.
    /// Changing Schedule Level / Elevation from Level should not rotate an instance.
    /// LocationPoint.Rotation is not a well-defined angle for instances hosted on a
    /// vertical face (especially after a 90-degree spacebar rotation), so comparing it
    /// could reject a perfectly valid correction.
    /// </summary>
    public sealed class OrientationInfo
    {
        private const double AngleTol = Math.PI / 1800.0; // 0.1 degree

        public bool HasRotation { get; private set; }
        public double Rotation { get; private set; }
        public XYZ Facing { get; private set; }
        public XYZ Hand { get; private set; }
        public bool FacingFlipped { get; private set; }
        public bool HandFlipped { get; private set; }
        public bool Mirrored { get; private set; }

        public static OrientationInfo Capture(FamilyInstance fi)
        {
            var s = new OrientationInfo();
            if (fi == null)
                return s;

            try
            {
                if (fi.Location is LocationPoint lp)
                {
                    s.HasRotation = true;
                    s.Rotation = lp.Rotation;
                }
            }
            catch { }

            try
            {
                XYZ v = fi.FacingOrientation;
                if (v != null && v.GetLength() > 1e-9)
                    s.Facing = v.Normalize();
            }
            catch { }

            try
            {
                XYZ v = fi.HandOrientation;
                if (v != null && v.GetLength() > 1e-9)
                    s.Hand = v.Normalize();
            }
            catch { }

            try { s.FacingFlipped = fi.FacingFlipped; } catch { }
            try { s.HandFlipped = fi.HandFlipped; } catch { }
            try { s.Mirrored = fi.Mirrored; } catch { }

            return s;
        }

        public string Describe()
        {
            return "LocationPoint.Rotation " +
                   (HasRotation ? Deg(Rotation) + " deg" : "n/a") +
                   " | Hand " + Vec(Hand) +
                   " | Facing " + Vec(Facing) +
                   " | FacingFlipped " + FacingFlipped +
                   ", HandFlipped " + HandFlipped +
                   ", Mirrored " + Mirrored;
        }

        public static string CompareForLog(OrientationInfo a, OrientationInfo b)
        {
            if (a == null || b == null)
                return "not compared";

            var diffs = new List<string>();
            AddVectorDiff(diffs, "Hand", a.Hand, b.Hand);
            AddVectorDiff(diffs, "Facing", a.Facing, b.Facing);
            if (a.FacingFlipped != b.FacingFlipped) diffs.Add("FacingFlipped changed");
            if (a.HandFlipped != b.HandFlipped) diffs.Add("HandFlipped changed");
            if (a.Mirrored != b.Mirrored) diffs.Add("Mirrored changed");

            string rotationNote = null;
            if (a.HasRotation && b.HasRotation)
            {
                double d = Wrapped(a.Rotation, b.Rotation);
                if (d > AngleTol)
                {
                    rotationNote = "LocationPoint.Rotation reads " + Deg(a.Rotation) + " -> " + Deg(b.Rotation) +
                                   " deg (this value is unreliable for wall-face instances; not used)";
                }
            }

            string text = diffs.Count == 0
                ? "unchanged (Hand/Facing directions and flip states identical)"
                : "WARNING " + string.Join("; ", diffs) + " (logged only; EK never writes rotation)";

            return rotationNote == null ? text : text + "; NOTE " + rotationNote;
        }

        private static void AddVectorDiff(List<string> diffs, string name, XYZ a, XYZ b)
        {
            if (a == null && b == null)
                return;

            if (a == null || b == null)
            {
                diffs.Add(name + " direction availability changed");
                return;
            }

            try
            {
                double d = a.AngleTo(b);
                if (d > AngleTol)
                    diffs.Add(name + " direction changed by " + Deg(d) + " deg");
            }
            catch
            {
                diffs.Add(name + " direction not comparable");
            }
        }

        private static double Wrapped(double a, double b)
        {
            double d = Math.Abs(a - b) % (2.0 * Math.PI);
            return d > Math.PI ? (2.0 * Math.PI - d) : d;
        }

        private static string Deg(double radians) =>
            (radians * 180.0 / Math.PI).ToString("0.000", CultureInfo.InvariantCulture);

        private static string Vec(XYZ v)
        {
            if (v == null)
                return "n/a";

            return "(" + v.X.ToString("0.000", CultureInfo.InvariantCulture) + ", " +
                   v.Y.ToString("0.000", CultureInfo.InvariantCulture) + ", " +
                   v.Z.ToString("0.000", CultureInfo.InvariantCulture) + ")";
        }
    }

    public static class LevelHeightService
    {
        public const double MmPerFoot = 304.8;

        // 1 mm verification tolerance.
        private const double Tol = 1.0 / MmPerFoot;

        // 0.1 mm: an instance sitting exactly on a level belongs to that level.
        private const double LevelPickTol = 0.1 / MmPerFoot;

        // ------------------------------------------------------------------
        // Read-only helpers
        // ------------------------------------------------------------------

        public static List<LevelZ> GetLevelsSorted(Document doc)
        {
            // ProjectElevation only. Never mix with Level.Elevation, which depends on the
            // level type's Elevation Base and would break shared-coordinate projects.
            // v3.9.4: ties are ordered by element id, so the order never depends on the
            // (unspecified) order of FilteredElementCollector.
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .Select(l => new LevelZ { Level = l, Z = l.ProjectElevation })
                .OrderBy(x => x.Z)
                .ThenBy(x => x.Level.Id.Value)
                .ToList();
        }

        /// <summary>
        /// Rule (unchanged): the HIGHEST host-project level whose ProjectElevation is at or
        /// below z (0.1 mm tolerance).
        ///
        /// Several levels can share that elevation ("twins", e.g. "Level 03" and "Level 11.0"
        /// both at +11.00 m). The physical result is identical for every twin; only the
        /// Schedule Level name differs. Before v3.9.4 the twin that came LAST in Revit's
        /// collector order won whenever the instance was not already on one of them.
        /// Now the choice is deterministic:
        ///   1. the instance's current Schedule Level (never swap between twins),
        ///   2. the level of the view the user placed in,
        ///   3. a level marked "Building Story",
        ///   4. the lowest element id.
        /// </summary>
        public static LevelPick PickLevelUnder(
            IList<LevelZ> levels,
            double z,
            ElementId currentLevelId,
            ElementId preferredLevelId)
        {
            var pick = new LevelPick();

            if (levels == null || levels.Count == 0)
            {
                pick.Rule = "the project has no levels";
                return pick;
            }

            int bestIndex = -1;
            for (int i = 0; i < levels.Count; i++)
            {
                if (levels[i].Z <= z + LevelPickTol)
                    bestIndex = i;
            }

            if (bestIndex < 0)
            {
                pick.Rule = "no host level at or below the instance";
                pick.NextAbove = levels[0];
                return pick;
            }

            double bestZ = levels[bestIndex].Z;

            foreach (LevelZ l in levels)
            {
                if (Math.Abs(l.Z - bestZ) <= LevelPickTol && l.Z <= z + LevelPickTol)
                    pick.Twins.Add(l);
            }

            for (int i = bestIndex; i >= 0; i--)
            {
                if (levels[i].Z < bestZ - LevelPickTol)
                {
                    pick.NextBelow = levels[i];
                    break;
                }
            }

            for (int i = bestIndex + 1; i < levels.Count; i++)
            {
                if (levels[i].Z > bestZ + LevelPickTol)
                {
                    pick.NextAbove = levels[i];
                    break;
                }
            }

            if (pick.Twins.Count <= 1)
            {
                pick.Chosen = levels[bestIndex];
                pick.Rule = "highest host level at or below the placed Z";
                return pick;
            }

            LevelZ chosen = pick.Twins.FirstOrDefault(t => SameId(t.Level.Id, currentLevelId));
            if (chosen != null)
            {
                pick.Chosen = chosen;
                pick.Rule = "same-elevation levels: kept the instance's current Schedule Level";
                return pick;
            }

            chosen = pick.Twins.FirstOrDefault(t => SameId(t.Level.Id, preferredLevelId));
            if (chosen != null)
            {
                pick.Chosen = chosen;
                pick.Rule = "same-elevation levels: the level of the view you placed in";
                return pick;
            }

            chosen = pick.Twins
                .Where(t => IsBuildingStory(t.Level))
                .OrderBy(t => t.Level.Id.Value)
                .FirstOrDefault();
            if (chosen != null)
            {
                pick.Chosen = chosen;
                pick.Rule = "same-elevation levels: Building Story level (lowest id)";
                return pick;
            }

            pick.Chosen = pick.Twins.OrderBy(t => t.Level.Id.Value).First();
            pick.Rule = "same-elevation levels: lowest element id";
            return pick;
        }

        /// <summary>Compatibility wrapper (tracker height learning). Same rule as PickLevelUnder.</summary>
        public static LevelZ FindLevelUnder(IList<LevelZ> levels, double z, ElementId currentLevelId = null)
        {
            return PickLevelUnder(levels, z, currentLevelId, null).Chosen;
        }

        /// <summary>Point-located instances only. No bounding-box guessing.</summary>
        public static bool TryGetPoint(FamilyInstance fi, out XYZ point)
        {
            point = null;
            try
            {
                if (fi.Location is LocationPoint lp && lp.Point != null)
                {
                    point = lp.Point;
                    return true;
                }
            }
            catch { }

            return false;
        }

        public static double? GetHeightAboveLevelUnder(FamilyInstance fi)
        {
            if (!TryGetPoint(fi, out XYZ p))
                return null;

            LevelZ lvl = FindLevelUnder(GetLevelsSorted(fi.Document), p.Z);
            if (lvl == null)
                return null;

            return p.Z - lvl.Z;
        }

        /// <summary>
        /// Height to apply this session, or null = "not learned yet, adopt placed height".
        /// </summary>
        public static double? GetConfiguredTargetFeet(RecentTypeState entry)
        {
            if (entry == null)
                return null;

            if (HeightModes.IsStandard(entry.HeightMode))
            {
                if (entry.StandardHeightMm.HasValue && entry.StandardHeightMm.Value > 0)
                    return entry.StandardHeightMm.Value / MmPerFoot;

                // Fixed mode without a value: fall back to learned height (never invent one).
            }

            return entry.LastWallHeightFeet;
        }

        /// <summary>Plain-language description of where this run's wall height comes from.</summary>
        public static string DescribeTarget(RecentTypeState entry)
        {
            if (entry == null)
                return "no history entry -> ADOPT: keeps its placed height";

            string learned = entry.LastWallHeightFeet.HasValue
                ? MmText(entry.LastWallHeightFeet.Value) + " mm"
                : "none";

            if (HeightModes.IsStandard(entry.HeightMode))
            {
                if (entry.StandardHeightMm.HasValue && entry.StandardHeightMm.Value > 0)
                {
                    return "FIXED " + entry.StandardHeightMm.Value.ToString("0.#", CultureInfo.InvariantCulture) +
                           " mm (Settings: Fixed height; learned value " + learned + " is not used)";
                }

                return entry.LastWallHeightFeet.HasValue
                    ? "Fixed mode WITHOUT a value -> uses the learned height " + learned
                    : "Fixed mode WITHOUT a value and nothing learned -> ADOPT: keeps its placed height and learns it";
            }

            return entry.LastWallHeightFeet.HasValue
                ? "LAST PLACED height " + learned + " (learned)"
                : "Last placed height, nothing learned yet -> ADOPT: first use keeps its placed height and learns it";
        }

        /// <summary>Z, Schedule Level, Elevation from Level (and Level, if present). Read-only, never throws.</summary>
        public static string DescribeState(Document doc, FamilyInstance fi)
        {
            var sb = new StringBuilder();
            try
            {
                if (TryGetPoint(fi, out XYZ p))
                    sb.Append("Z ").Append(MmText(p.Z)).Append(" mm (internal, same frame as ProjectElevation)");
                else
                    sb.Append("Z n/a (not point-located)");

                AppendLevelParam(sb, doc, fi, BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM, "Schedule Level");

                Parameter pe = fi.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM);
                if (pe != null && pe.StorageType == StorageType.Double)
                {
                    sb.Append(" | Elevation from Level ").Append(MmText(pe.AsDouble())).Append(" mm");
                    if (pe.IsReadOnly)
                        sb.Append(" [read-only]");
                }
                else
                {
                    sb.Append(" | Elevation from Level <no parameter>");
                }

                Parameter pf = fi.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM);
                if (pf != null && pf.StorageType == StorageType.ElementId)
                    AppendLevelParam(sb, doc, fi, BuiltInParameter.FAMILY_LEVEL_PARAM, "Level");
            }
            catch (Exception ex)
            {
                sb.Append(" | state read error: ").Append(ex.Message);
            }

            return sb.ToString();
        }

        private static void AppendLevelParam(
            StringBuilder sb,
            Document doc,
            FamilyInstance fi,
            BuiltInParameter bip,
            string label)
        {
            Parameter p = fi.get_Parameter(bip);
            if (p == null || p.StorageType != StorageType.ElementId)
            {
                sb.Append(" | ").Append(label).Append(" <no parameter>");
                return;
            }

            ElementId id = p.AsElementId();
            Level l = null;
            if (id != null && id != ElementId.InvalidElementId)
                l = doc.GetElement(id) as Level;

            sb.Append(" | ").Append(label).Append(" ")
              .Append(l == null ? "<none>" : LevelText(new LevelZ { Level = l, Z = l.ProjectElevation }));

            if (p.IsReadOnly)
                sb.Append(" [read-only]");
        }

        /// <summary>All host-project levels, low to high, plus any same-elevation groups.</summary>
        public static string DescribeLevels(IList<LevelZ> levels)
        {
            if (levels == null || levels.Count == 0)
                return "none";

            var sb = new StringBuilder();
            sb.Append(levels.Count).Append(" level(s), low to high: ");

            for (int i = 0; i < levels.Count; i++)
            {
                if (i >= 80)
                {
                    sb.Append(" | ...");
                    break;
                }

                if (i > 0)
                    sb.Append(" | ");

                sb.Append("'").Append(SafeLevelName(levels[i].Level)).Append("' ").Append(MmText(levels[i].Z));
            }

            var twins = new List<string>();
            for (int i = 1; i < levels.Count; i++)
            {
                if (Math.Abs(levels[i].Z - levels[i - 1].Z) <= LevelPickTol)
                {
                    twins.Add("'" + SafeLevelName(levels[i - 1].Level) + "' = '" +
                              SafeLevelName(levels[i].Level) + "' @ " + MmText(levels[i].Z) + " mm");
                }
            }

            if (twins.Count > 0)
                sb.Append("  || SAME ELEVATION: ").Append(string.Join("; ", twins));

            return sb.ToString();
        }

        // ------------------------------------------------------------------
        // WALL rule
        // ------------------------------------------------------------------

        /// <summary>
        /// Schedule Level = highest level under the instance; Elevation from Level = target.
        /// targetFeet == null => adopt the placed height (no vertical move).
        /// Runs in its OWN transaction (atomic per instance) and verifies the result
        /// (XY unchanged, Z exact, Schedule Level stuck) before committing. Anything
        /// unexpected => rollback, element left as placed. The user's rotation is never
        /// written. Raw Rotation is diagnostic only; actual instance axes are verified.
        /// </summary>
        public static CorrectionResult CorrectWallInstance(
            Document doc,
            FamilyInstance fi,
            double? targetFeet,
            IList<LevelZ> levels,
            ElementId preferredLevelId,
            out double appliedHeightFeet,
            HostInfo verifiedVerticalHost = null)
        {
            appliedHeightFeet = double.NaN;
            var r = new CorrectionResult();

            if (!TryGetPoint(fi, out XYZ p0))
                return r.Set(CorrectionStatus.Skipped, "not point-located (no LocationPoint)");

            Parameter pLevel = fi.get_Parameter(BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM);
            Parameter pElev = fi.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM);

            if (pLevel == null || pElev == null)
                return r.Set(CorrectionStatus.Skipped,
                    "family has no Schedule Level / Elevation from Level parameter");

            if (pLevel.IsReadOnly || pElev.IsReadOnly)
                return r.Set(CorrectionStatus.Skipped,
                    "Schedule Level or Elevation from Level is read-only");

            if (pLevel.StorageType != StorageType.ElementId || pElev.StorageType != StorageType.Double)
                return r.Set(CorrectionStatus.Skipped, "unexpected parameter storage types");

            LevelPick pick = PickLevelUnder(levels, p0.Z, pLevel.AsElementId(), preferredLevelId);
            r.Pick = pick;

            LevelZ lvl = pick.Chosen;
            if (lvl == null)
                return r.Set(CorrectionStatus.Skipped,
                    "no host level at or below the instance (placed Z " + MmText(p0.Z) + " mm)");

            double target = targetFeet ?? (p0.Z - lvl.Z);
            r.TargetFeet = target;

            if (double.IsNaN(target) || double.IsInfinity(target) || target < -Tol)
                return r.Set(CorrectionStatus.Skipped, "invalid target height");

            // Diagnostics only (never block): explain unusual level choices in the log.
            foreach (LevelZ other in levels)
            {
                if (other.Z > lvl.Z + LevelPickTol && other.Z < lvl.Z + target - LevelPickTol)
                {
                    r.Notes.Add("host level " + LevelText(other) +
                                " lies between the chosen Schedule Level and the final height");
                }
            }

            if (preferredLevelId != null &&
                preferredLevelId != ElementId.InvalidElementId &&
                !SameId(lvl.Level.Id, preferredLevelId))
            {
                LevelZ viewLevel = levels.FirstOrDefault(x => SameId(x.Level.Id, preferredLevelId));
                r.Notes.Add("chosen level differs from the level of the view you placed in: view level " +
                            (viewLevel != null ? LevelText(viewLevel) : "id " + preferredLevelId.Value) +
                            " (compare with the placed Z above)");
            }

            bool levelAlreadyOk = SameId(pLevel.AsElementId(), lvl.Level.Id);
            bool zAlreadyOk = Math.Abs(p0.Z - (lvl.Z + target)) <= Tol;
            bool elevAlreadyOk = levelAlreadyOk && Math.Abs(pElev.AsDouble() - target) <= Tol;

            if (levelAlreadyOk && zAlreadyOk && elevAlreadyOk)
            {
                appliedHeightFeet = target;
                r.After = "unchanged (already correct)";
                r.Orientation = "not touched";
                return r.Set(CorrectionStatus.NoChangeNeeded,
                    $"already {Mm(target)} mm above {lvl.Level.Name}");
            }

            XYZ mountingOffset = null;
            Transform instanceAxes;
            try
            {
                // Reject an invalid target before writing either level or height.
                if (verifiedVerticalHost != null && !string.IsNullOrEmpty(verifiedVerticalHost.FaceStableReference))
                {
                    if (!HostFaceGeometry.TryResolve(fi, out HostFaceGeometry geometry, out string faceReason) ||
                        !geometry.ValidateMove(p0, new XYZ(p0.X, p0.Y, lvl.Z + target), out mountingOffset, out faceReason))
                        return r.Set(CorrectionStatus.Skipped, "host face preflight: " + faceReason);
                    r.Notes.Add("host face preflight passed in model coordinates; original mounting offset " +
                        MmText(mountingOffset.GetLength()) + " mm");
                }
                instanceAxes = fi.GetTransform();
            }
            catch (Exception ex) { return r.Set(CorrectionStatus.Skipped, "cannot verify safe correction: " + ex.Message); }

            OrientationInfo orientation0 = OrientationInfo.Capture(fi);
            string okMessage = SafeLevelName(lvl.Level) + " + " + Mm(target) + " mm";

            using (var t = new Transaction(doc, "EK Last Similar - Wall height"))
            {
                var pre = new RollbackOnErrorPreprocessor();
                try
                {
                    if (t.Start() != TransactionStatus.Started)
                    {
                        r.Transaction = "not started";
                        return r.Set(CorrectionStatus.Failed, "could not start transaction");
                    }

                    r.Attempted = true;
                    ApplyPreprocessor(t, pre);

                    if (!levelAlreadyOk)
                    {
                        if (!pLevel.Set(lvl.Level.Id))
                            throw new InvalidOperationException("Revit rejected Schedule Level");

                        // Elevation from Level is measured from the Schedule Level: regenerate
                        // and re-acquire the parameter before setting it.
                        doc.Regenerate();
                    }

                    Parameter pElevNow = fi.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM);
                    if (pElevNow == null || pElevNow.IsReadOnly)
                        throw new InvalidOperationException("Elevation from Level became unavailable after the level change");

                    if (!pElevNow.Set(target))
                        throw new InvalidOperationException("Revit rejected Elevation from Level");

                    doc.Regenerate();

                    // ---- verify before committing ----
                    if (!TryGetPoint(fi, out XYZ p1))
                        throw new InvalidOperationException("location lost after change");

                    double xyMove = Math.Sqrt(
                        (p1.X - p0.X) * (p1.X - p0.X) + (p1.Y - p0.Y) * (p1.Y - p0.Y));
                    if (xyMove > Tol)
                        throw new InvalidOperationException(
                            $"instance moved horizontally by {Mm(xyMove)} mm (sloped/odd host)");

                    double expectedZ = lvl.Z + target;
                    if (Math.Abs(p1.Z - expectedZ) > Tol)
                        throw new InvalidOperationException(
                            $"unexpected result height (got {Mm(p1.Z - lvl.Z)} mm, wanted {Mm(target)} mm)");

                    Parameter pLevelNow = fi.get_Parameter(BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM);
                    if (pLevelNow == null || !SameId(pLevelNow.AsElementId(), lvl.Level.Id))
                        throw new InvalidOperationException("Schedule Level did not stick");

                    // Preserve the same wall/face host for every hosted correction.
                    if (verifiedVerticalHost != null &&
                        !HostClassifier.VerifySameVerticalHost(fi, verifiedVerticalHost, out string hostError))
                        throw new InvalidOperationException("vertical host verification failed: " + hostError);

                    if (mountingOffset != null)
                    {
                        if (!HostFaceGeometry.TryResolve(fi, out HostFaceGeometry finalFace, out string finalReason) ||
                            !finalFace.TryProject(p1, out XYZ onFinalFace, out XYZ finalNormal, out finalReason))
                            throw new InvalidOperationException("host face final verification: " + finalReason);
                        if ((p1 - onFinalFace).DistanceTo(mountingOffset) > 0.5 / 304.8)
                            throw new InvalidOperationException("mounting offset changed after correction");
                    }

                    OrientationInfo orientation1 = OrientationInfo.Capture(fi);
                    if (!HostFaceGeometry.SameBasis(instanceAxes, fi.GetTransform()) ||
                        orientation0.FacingFlipped != orientation1.FacingFlipped ||
                        orientation0.HandFlipped != orientation1.HandFlipped ||
                        orientation0.Mirrored != orientation1.Mirrored)
                        throw new InvalidOperationException("instance orientation changed after correction");
                    r.Orientation = OrientationInfo.CompareForLog(orientation0, orientation1);

                    TransactionStatus status = t.Commit();
                    if (status != TransactionStatus.Committed)
                    {
                        r.Transaction = "rolled back by Revit (" + status + ")";
                        r.After = DescribeState(doc, fi);
                        return r.Set(CorrectionStatus.Failed,
                            "Revit rolled back: " + (pre.FirstError ?? status.ToString()));
                    }

                    r.Transaction = "committed";
                    appliedHeightFeet = target;
                    r.After = DescribeState(doc, fi);
                    return r.Set(CorrectionStatus.Corrected, okMessage);
                }
                catch (Exception ex)
                {
                    // If the commit already happened, the edit IS in the model: report it as
                    // corrected, or the caller would roll the whole group back by mistake.
                    if (IsCommitted(t))
                    {
                        r.Transaction = "committed";
                        r.Notes.Add("diagnostic error after commit (correction kept): " + ex.Message);
                        r.After = DescribeState(doc, fi);
                        appliedHeightFeet = target;
                        return r.Set(CorrectionStatus.Corrected, okMessage);
                    }

                    SafeRollBack(t);
                    if (r.Attempted)
                        r.Transaction = "rolled back";
                    if (string.IsNullOrEmpty(r.Orientation))
                        r.Orientation = "not compared (rolled back before the check)";
                    r.After = DescribeState(doc, fi);
                    return r.Set(CorrectionStatus.Failed, ex.Message);
                }
            }
        }

        // ------------------------------------------------------------------
        // UNHOSTED / LEVEL-BASED ELECTRICAL EQUIPMENT rule (best effort)
        // ------------------------------------------------------------------

        /// <summary>
        /// Assign the highest level under the instance while preserving the exact global
        /// position. If the level is already right: no edit at all. Otherwise the change is
        /// verified geometrically (XYZ unchanged within 1 mm) or rolled back.
        /// </summary>
        public static CorrectionResult CorrectFreeElectricalEquipment(
            Document doc,
            FamilyInstance fi,
            IList<LevelZ> levels,
            ElementId preferredLevelId)
        {
            if (!HostClassifier.CategoryIs(fi, BuiltInCategory.OST_ElectricalEquipment))
                return CorrectionResult.Of(CorrectionStatus.Skipped, "not Electrical Equipment");

            Reference face = null;
            try { face = fi.HostFace; } catch { }
            if (face != null)
                return CorrectionResult.Of(CorrectionStatus.Skipped, "face-hosted (not free)");

            if (!TryGetPoint(fi, out XYZ p0))
                return CorrectionResult.Of(CorrectionStatus.Skipped, "not point-located");

            Parameter pLevel = fi.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM);
            if (pLevel == null || pLevel.IsReadOnly || pLevel.StorageType != StorageType.ElementId)
                return CorrectionResult.Of(CorrectionStatus.Skipped, "Level parameter not writable");

            var r = new CorrectionResult();
            LevelPick pick = PickLevelUnder(levels, p0.Z, pLevel.AsElementId(), preferredLevelId);
            r.Pick = pick;

            LevelZ lvl = pick.Chosen;
            if (lvl == null)
                return r.Set(CorrectionStatus.Skipped, "no level below the instance");

            if (SameId(pLevel.AsElementId(), lvl.Level.Id))
            {
                r.After = "unchanged (already correct)";
                return r.Set(CorrectionStatus.NoChangeNeeded, "already on " + lvl.Level.Name);
            }

            string okEquipmentMessage = "level -> " + SafeLevelName(lvl.Level) + ", global position preserved";

            using (var t = new Transaction(doc, "EK Last Similar - Equipment level"))
            {
                var pre = new RollbackOnErrorPreprocessor();
                try
                {
                    if (t.Start() != TransactionStatus.Started)
                    {
                        r.Transaction = "not started";
                        return r.Set(CorrectionStatus.Failed, "could not start transaction");
                    }

                    r.Attempted = true;
                    ApplyPreprocessor(t, pre);

                    if (!pLevel.Set(lvl.Level.Id))
                        throw new InvalidOperationException("Revit rejected Level");

                    doc.Regenerate();

                    if (!TryGetPoint(fi, out XYZ p1))
                        throw new InvalidOperationException("location lost after level change");

                    if (p1.DistanceTo(p0) > Tol)
                    {
                        // Revit kept the offset and moved the element: restore global Z through
                        // whichever offset parameter actually moves it. Verified, or rolled back.
                        double dz = p0.Z - p1.Z;
                        bool restored = false;

                        foreach (BuiltInParameter bip in new[]
                                 {
                                     BuiltInParameter.INSTANCE_ELEVATION_PARAM,
                                     BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM
                                 })
                        {
                            Parameter po = fi.get_Parameter(bip);
                            if (po == null || po.IsReadOnly || po.StorageType != StorageType.Double)
                                continue;

                            using (var st = new SubTransaction(doc))
                            {
                                st.Start();
                                bool setOk = po.Set(po.AsDouble() + dz);
                                if (setOk)
                                {
                                    doc.Regenerate();
                                    if (TryGetPoint(fi, out XYZ p2) && p2.DistanceTo(p0) <= Tol)
                                    {
                                        st.Commit();
                                        restored = true;
                                        break;
                                    }
                                }

                                st.RollBack();
                                doc.Regenerate();
                            }
                        }

                        if (!restored)
                            throw new InvalidOperationException("could not preserve global position");
                    }

                    if (!TryGetPoint(fi, out XYZ pFinal) || pFinal.DistanceTo(p0) > Tol)
                        throw new InvalidOperationException("final position check failed");

                    TransactionStatus status = t.Commit();
                    if (status != TransactionStatus.Committed)
                    {
                        r.Transaction = "rolled back by Revit (" + status + ")";
                        r.After = DescribeState(doc, fi);
                        return r.Set(CorrectionStatus.Failed,
                            "Revit rolled back: " + (pre.FirstError ?? status.ToString()));
                    }

                    r.Transaction = "committed";
                    r.After = DescribeState(doc, fi);
                    return r.Set(CorrectionStatus.Corrected, okEquipmentMessage);
                }
                catch (Exception ex)
                {
                    if (IsCommitted(t))
                    {
                        r.Transaction = "committed";
                        r.Notes.Add("diagnostic error after commit (correction kept): " + ex.Message);
                        r.After = DescribeState(doc, fi);
                        return r.Set(CorrectionStatus.Corrected, okEquipmentMessage);
                    }

                    SafeRollBack(t);
                    if (r.Attempted)
                        r.Transaction = "rolled back";
                    r.After = DescribeState(doc, fi);
                    return r.Set(CorrectionStatus.Failed, ex.Message);
                }
            }
        }

        // ------------------------------------------------------------------
        // Helpers
        // ------------------------------------------------------------------

        private static void ApplyPreprocessor(Transaction t, IFailuresPreprocessor pre)
        {
            FailureHandlingOptions options = t.GetFailureHandlingOptions();
            options.SetFailuresPreprocessor(pre);
            options.SetClearAfterRollback(true);
            t.SetFailureHandlingOptions(options);
        }

        private static void SafeRollBack(Transaction t)
        {
            try
            {
                if (t.GetStatus() == TransactionStatus.Started)
                    t.RollBack();
            }
            catch { }
        }

        private static bool IsCommitted(Transaction t)
        {
            try { return t.GetStatus() == TransactionStatus.Committed; }
            catch { return false; }
        }

        private static bool IsBuildingStory(Level l)
        {
            try
            {
                Parameter p = l.get_Parameter(BuiltInParameter.LEVEL_IS_BUILDING_STORY);
                return p != null && p.StorageType == StorageType.Integer && p.AsInteger() == 1;
            }
            catch
            {
                return false;
            }
        }

        private static bool SameId(ElementId a, ElementId b) =>
            a != null && b != null && a.Value == b.Value;

        private static string Mm(double feet) =>
            (feet * MmPerFoot).ToString("0.#", CultureInfo.InvariantCulture);

        /// <summary>Feet -> "1234.5" mm text, culture independent (log).</summary>
        public static string MmText(double feet) =>
            (feet * MmPerFoot).ToString("0.0", CultureInfo.InvariantCulture);

        public static string LevelText(LevelZ l)
        {
            if (l == null || l.Level == null)
                return "-";

            long id = 0;
            try { id = l.Level.Id.Value; } catch { }

            return "'" + SafeLevelName(l.Level) + "' (id " + id + ", ProjectElevation " + MmText(l.Z) + " mm)";
        }

        private static string SafeLevelName(Level l)
        {
            try { return l?.Name ?? "?"; }
            catch { return "?"; }
        }
    }

    /// <summary>
    /// Any Error-severity failure while committing a correction => roll back THAT
    /// instance's transaction. Never resolves errors by deleting elements.
    /// Warnings are left for Revit to show normally.
    /// </summary>
    internal sealed class RollbackOnErrorPreprocessor : IFailuresPreprocessor
    {
        public string FirstError { get; private set; }

        public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
        {
            foreach (FailureMessageAccessor m in failuresAccessor.GetFailureMessages())
            {
                FailureSeverity severity = m.GetSeverity();
                if (severity == FailureSeverity.Error || severity == FailureSeverity.DocumentCorruption)
                {
                    try { FirstError = m.GetDescriptionText(); } catch { FirstError = "Revit error"; }
                    return FailureProcessingResult.ProceedWithRollBack;
                }
            }

            return FailureProcessingResult.Continue;
        }
    }
}

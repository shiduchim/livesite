using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace EK.LastSimilar.Services
{
    /// <summary>
    /// Starts Revit's own Create Similar command for the remembered straight line.
    ///
    /// This intentionally uses the native Revit command instead of implementing a custom
    /// two-point drawing tool. That preserves Revit's normal temporary dimensions, snaps,
    /// chain/arc options, work-plane behavior, and the exact remembered line style.
    ///
    /// The selection is only used internally as the input Revit requires for Create Similar.
    /// It never defines what EK considers "Last"; the passive tracker does that from actual
    /// committed placements only.
    /// </summary>
    internal static class LineSimilarService
    {
        public static Result Start(UIApplication uiapp, RecentResolvedItem item)
        {
            if (uiapp == null || item == null || !item.IsLine || item.State == null)
                return Result.Cancelled;

            UIDocument uidoc = uiapp.ActiveUIDocument;
            if (uidoc == null)
                return Result.Cancelled;

            Document doc = uidoc.Document;
            CurveElement source = FindBestSource(doc, uidoc.ActiveView, item);
            if (source == null)
            {
                CommandRunner.SafeDialog(
                    "The remembered line style is \"" + (item.State.TypeName ?? "Line") + "\", " +
                    "but EK could not find an existing " + FriendlyKind(item.State.ItemKind) +
                    " to start Revit Create Similar from.\n\n" +
                    "Draw one line with that style normally in Revit. It will immediately become Last Similar.");
                return Result.Cancelled;
            }

            ICollection<ElementId> oldSelection = null;
            bool posted = false;
            try
            {
                try { oldSelection = uidoc.Selection.GetElementIds(); }
                catch { }

                uidoc.Selection.SetElementIds(new List<ElementId> { source.Id });

                RevitCommandId commandId =
                    RevitCommandId.LookupPostableCommandId(PostableCommand.CreateSimilar);

                if (commandId == null || !uiapp.CanPostCommand(commandId))
                {
                    CommandRunner.SafeDialog(
                        "Revit Create Similar is not available in the current view.");
                    return Result.Cancelled;
                }

                uiapp.PostCommand(commandId);
                posted = true;

                RunLog.Add(
                    "Line Similar posted: " + FriendlyKind(item.State.ItemKind) +
                    " / " + (item.State.TypeName ?? "") +
                    " using source id " + source.Id.Value + ".");

                try
                {
                    if (source.LineStyle is GraphicsStyle style)
                        VisibilityWatch.ExpectLines(doc, uidoc.ActiveView, style.Id,
                            FriendlyKind(item.State.ItemKind) + " \"" + (item.State.TypeName ?? "") + "\"");
                }
                catch { }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                RunLog.Add("Line Similar failed: " + ex);
                CommandRunner.SafeDialog(
                    "Could not start Revit Create Similar for this line.\n\n" + ex.Message);
                return Result.Cancelled;
            }
            finally
            {
                // The temporary selection is only the seed Create Similar needs.
                if (!posted && oldSelection != null)
                {
                    try { uidoc.Selection.SetElementIds(oldSelection); }
                    catch { }
                }
            }
        }

        private static CurveElement FindBestSource(
            Document doc,
            View activeView,
            RecentResolvedItem item)
        {
            if (doc == null || item?.State == null)
                return null;

            // 1) Prefer the actual last line if it still exists and is suitable.
            CurveElement source = item.SourceCurve;
            if (Matches(source, item.State, item.LineStyle, activeView, requireCurrentViewForDetail: true))
                return source;

            // 2) Prefer any matching line already in the current view.
            try
            {
                IEnumerable<CurveElement> inView = new FilteredElementCollector(doc, activeView.Id)
                    .WhereElementIsNotElementType()
                    .ToElements()
                    .OfType<CurveElement>();

                CurveElement found = inView.FirstOrDefault(
                    x => Matches(x, item.State, item.LineStyle, activeView, requireCurrentViewForDetail: true));

                if (found != null)
                    return found;
            }
            catch { }

            // 3) Model lines are project-wide; any matching model line is a valid seed.
            if (RecentItemKinds.IsModelLine(item.State.ItemKind))
            {
                try
                {
                    IEnumerable<CurveElement> all = new FilteredElementCollector(doc)
                        .WhereElementIsNotElementType()
                        .ToElements()
                        .OfType<CurveElement>();

                    CurveElement found = all.FirstOrDefault(
                        x => Matches(x, item.State, item.LineStyle, activeView, requireCurrentViewForDetail: false));

                    if (found != null)
                        return found;
                }
                catch { }
            }

            // 4) Final attempt: the stored detail-line source from another view. Revit may
            // allow it as a Create Similar seed depending on the current context.
            if (Matches(source, item.State, item.LineStyle, activeView, requireCurrentViewForDetail: false))
                return source;

            return null;
        }

        private static bool Matches(
            CurveElement curve,
            RecentTypeState state,
            GraphicsStyle wantedStyle,
            View activeView,
            bool requireCurrentViewForDetail)
        {
            if (!StateStore.IsUsableStraightLine(curve) || state == null)
                return false;

            bool wantDetail = RecentItemKinds.IsDetailLine(state.ItemKind);
            if (wantDetail != (curve is DetailCurve))
                return false;

            if (!wantDetail && !(curve is ModelCurve))
                return false;

            if (wantDetail && requireCurrentViewForDetail)
            {
                try
                {
                    if (activeView == null || curve.OwnerViewId != activeView.Id)
                        return false;
                }
                catch
                {
                    return false;
                }
            }

            try
            {
                GraphicsStyle actual = curve.LineStyle as GraphicsStyle;
                if (actual == null)
                    return false;

                if (wantedStyle != null && actual.Id == wantedStyle.Id)
                    return true;

                if (!string.IsNullOrWhiteSpace(state.LineStyleUniqueId) &&
                    string.Equals(actual.UniqueId, state.LineStyleUniqueId, StringComparison.Ordinal))
                    return true;

                return string.Equals(actual.Name, state.TypeName, StringComparison.Ordinal);
            }
            catch
            {
                return false;
            }
        }

        private static string FriendlyKind(string kind)
        {
            return RecentItemKinds.IsModelLine(kind) ? "Model Line" : "Detail Line";
        }
    }
}

# EK Last Similar 3.9.2

Final requested UI cleanup:
- Settings title bar no longer shows the Revit process icon.
- Removed the Last badge from Settings rows.
- Removed Ctrl/Shift/Alt ribbon-key/modifier controls and their command behavior entirely.
- Last Similar is always the true last placed type.
- Recent 5 is only the dedicated Revit command and can have its own Revit shortcut.
- Main ribbon icon changed to two muted-blue square-top tablets/documents with exactly five lines each.
- Settings button remains text-only (no ribbon icon).
- Save still saves and closes; Close still cancels unsaved Settings changes.
- Family thumbnails remain available in both Recent 5 and Settings.

No host, level, height, linked-model, ceiling-protection, placement, or tracker safety behavior was changed.

# EK Last Similar — code review v1.0.0 → v1.0.1

## Problems found (priority order) and fixes

### Critical
1. **Placements could be rolled back by Revit.** Revit undoes everything a command did when it
   returns Failed/Cancelled. In v1 any exception after placement (state file locked by OneDrive /
   antivirus / a 2nd Revit, a finalize transaction error) escaped `Execute` → `Result.Failed` →
   every switch the user just placed disappeared.
   *Fix:* placement + finalize never throw (`PlaceAndFinalize` returns an outcome), state saving
   never throws, and the command returns Succeeded whenever ≥1 instance was placed.
2. **Shift popup: "click away closes it" did not work inside Revit.** `ShowDialog` disables the
   Revit window, so clicking Revit only beeps/flashes; `Deactivated` never fires.
   *Fix:* context-menu style mouse capture; a click anywhere outside the card closes it.
3. **Shift popup flash / jump.** Rows were built and the window positioned in `Loaded`, i.e. after it
   was already visible at a default position.
   *Fix:* rows built + measured in the constructor, position set in `SourceInitialized` (before
   visible), window kept transparent until the first frame is rendered and position re-verified.
4. **Shift popup DPI / multi-monitor.** WinForms cursor pixels converted with the window's own
   DPI, clamped to the whole virtual screen (can land in gaps between monitors / off a smaller
   monitor). *Fix:* Win32 cursor + work area of the monitor under the cursor, per-monitor DPI
   when Revit runs per-monitor aware, flip left/up near edges.
5. **Installer could not build on a normal PC.** `%VSWHERE%` was set and used inside the same
   parenthesised block (expands to empty → "MSBuild was not found"), and the SDK-style project was
   built without `/restore` (NETSDK1004). *Fix:* rewritten installer: refuses while Revit runs,
   validates RevitAPI/RevitAPIUI, `dotnet build` with MSBuild fallback, log file, CRLF, relative
   .addin path, state folder untouched.

### High
6. **Undo/redo during the listener window** could report OLD (previously deleted) instances as
   "added". *Fix:* only `UndoOperation.TransactionCommitted` is recorded.
7. **Correction atomicity.** A `SubTransaction` does not cover commit-time failure processing: one
   bad instance could roll back all corrections or show Revit's "Delete element" dialog.
   *Fix:* one Transaction per instance with a rollback-on-error preprocessor (never deletes),
   inside a TransactionGroup assimilated as one undo step. Each correction is verified before
   commit (Schedule Level read back, final Z = level + target, no XY movement).
8. **Linked host classification.** Category-name fallback ("wall" substring, English only) could
   classify e.g. *Curtain Wall Mullions* as Wall; a `LinkedElementId` from a nested link resolved
   in the parent link could hit an unrelated Wall. *Fix:* BuiltInCategory checks + proof that the
   instance actually sits on that linked element; otherwise Other (untouched).
9. **Electrical equipment path never ran / unverified.** Level-based equipment returns the *Level*
   as `Host`, so v1 classified it as Other. When it did run, it assumed parameter semantics.
   *Fix:* Level/None handled; no edit when the level is already right; otherwise global position
   verified unchanged or rolled back.

### Medium / low
10. Bounding-box centre was used as "Z" for non point-located instances → removed (point only).
11. Detail components / annotations / group members are skipped explicitly.
12. `ProjectElevation` with silent fallback to `Elevation` (different reference) → ProjectElevation only.
13. Shift detection: WPF `Keyboard.Modifiers` + `GetKeyState` + `GetAsyncKeyState`, read first in `Execute`.
14. Opening *Recent Heights* with a selection silently changed the Last type → now only adds/pre-selects.
15. State file: two Revit sessions overwrote each other; delete+move not atomic; a corrupt file
    wiped all history. → named mutex, per-document merge, `File.Replace`, corrupt-file backup.
16. Owner HWND was assigned in `SourceInitialized` (too late for CenterOwner) → constructor.
17. In-listener document match by ProjectInformation key (two open copies of the same project
    share it) → document identity.
18. Type activation failure (workshared, type borrowed by someone else) threw → handled.
19. Icons had different drawing bounds → inconsistent scaling; ribbon received DrawingImages of
    arbitrary size → fixed 26×26 frame, category-first classification (language independent),
    ribbon bitmaps at 16/32 rendered @2x.
20. Obsolete `[Regeneration]` attribute removed; `ElementId.Value` used (2025+ ready).
21. First-use "adopt": the learned height is now decided once per session, so instances placed
    in the same first session are never moved to the first one's height.

## Verified as correct in v1 (kept)
* Subscribe immediately before `PromptForFamilyInstancePlacement`, unsubscribe in `finally`,
  correct only afterwards. (Now also: static guard, command-level `finally`, `OnShutdown`.)
* Read-only handler that records ids only.
* `INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM` (Schedule Level) + `INSTANCE_ELEVATION_PARAM`
  (Elevation from Level) for hosted instances.
* Linked host via `FamilyInstance.HostFace.LinkedElementId` + `RevitLinkInstance.GetLinkDocument()`.
* Symbol activation in its own transaction before the prompt (no open transaction during it).

## Second pass — "could it edit the wrong element?"
| Path | Guard |
|---|---|
| Old elements re-added by undo/redo | Only `TransactionCommitted` |
| Changes in another open document | Document identity check |
| Type switched in Properties during placement | Exact type id, checked in listener AND again before editing |
| Nested shared components | `SuperComponent == null` |
| Element deleted/undone before finalize | Re-fetched, `IsValidObject` |
| Nested link id resolved in wrong doc | Proximity proof, else untouched |
| Sloped/odd wall face moves the item sideways | XY verification → rollback |
| Elevation semantics differ for a family | Final-Z verification → rollback |
| Revit error at commit | Per-instance rollback, never "delete element" |
| Ceiling hosts | Never edited |
| Group members, detail items | Never edited |
| Listener survives | `finally` + idempotent detach + command `finally` + `OnShutdown`; if still attached, NO corrections are made |

---

# v3.2 max review (of v3.1)

See `VERSION_3_2_NOTES.md` for the full list. Key safety additions:

| Attack | Guard added in v3.2 |
|---|---|
| Other-type placements during a run + Cancelled result | Succeeded whenever anything was committed during placement |
| Auto-generated fittings / bulk paste / sync / view duplication becoming "Last" | Tracker counts one fresh single-instance commit only, with category exclusions and sync suppression |
| Projects from one template sharing history | Project identity in the key (central path / creation GUID / path), legacy history copied once |
| Locked state file treated as corrupt -> other projects wiped | Unreadable file is never overwritten; corrupt file kept; `.bak` recovery |
| Stale snapshot overwriting newer history | Atomic lock + read + targeted change + write for every save |
| Tracker learning a pre-correction height | Tracker skips height learning for the type an active run is placing |
| Twin levels flipping | Current level kept when another level shares the same elevation |


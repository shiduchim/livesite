# EK Last Similar 3.7.0

## Settings behavior
- Real Revit family/type preview thumbnails are also shown in Settings when thumbnails are enabled.
- Thumbnail size applies to both Recent 5 and Settings.
- `Set as Last` was removed from the Settings UI.
- New `Move to bottom` button sits beside `Remove from list`.
- Move to bottom affects Settings ordering only; it does not falsify true Recent 5 placement order.
- A real placement automatically brings that type back out of the manual bottom group.
- `Save` now saves staged Settings changes and closes the window.
- `Close` is a true cancel: staged edits, removals, ordering changes, modifier choice, and thumbnail options are discarded.
- `Place` saves staged changes first, then starts placement.

## Ribbon
- Settings ribbon button has no icon.
- Main Last Similar icon is brighter, contains no mouse pointer, and uses two straight duplicate glyphs.
- This icon is temporary pending selection from the five concept options.

## Safety
- No model placement, host classification, linked-wall logic, ceiling protection, or transient correction behavior changed.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Automation;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using EK.LastSimilar.Services;

namespace EK.LastSimilar.UI
{
    /// <summary>
    /// Context-palette style picker shown beside the cursor by the dedicated Recent 5 command.
    ///
    /// Behaviour notes (why it is built this way):
    /// - Rows are built and measured in the constructor, and the window is positioned in
    ///   SourceInitialized (HWND exists, nothing visible yet) in physical pixels on the
    ///   monitor under the cursor. It stays fully transparent until the first frame has
    ///   rendered and the final position is verified => no flash, no jump.
    /// - ShowDialog() keeps Revit disabled (no re-entrancy while we are inside a command).
    ///   Because a disabled Revit window would only beep when clicked, the popup captures
    ///   the mouse (like a WPF ContextMenu) so a click anywhere outside closes it.
    /// - Owned by Revit's main window, tool-window style: no taskbar button, no Alt+Tab entry.
    /// - Rows are plain Borders (not Buttons) so nothing steals the mouse capture.
    /// </summary>
    public partial class RecentFivePopup : Window
    {
        /// <summary>Quiet, Revit-friendly colours. Dark is used when Revit's UI theme is dark.</summary>
        private sealed class Palette
        {
            public Brush Surface;
            public Brush Border;
            public Brush Text;
            public Brush Muted;
            public Brush Faint;
            public Brush Hover;
            public double ShadowOpacity;
        }

        private static readonly Palette LightPalette = new Palette
        {
            Surface = Freeze(new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF))),
            Border = Freeze(new SolidColorBrush(Color.FromRgb(0xC5, 0xCB, 0xD3))),
            Text = Freeze(new SolidColorBrush(Color.FromRgb(0x1E, 0x22, 0x28))),
            Muted = Freeze(new SolidColorBrush(Color.FromRgb(0x68, 0x6F, 0x7A))),
            Faint = Freeze(new SolidColorBrush(Color.FromRgb(0x9A, 0xA1, 0xAB))),
            Hover = Freeze(new SolidColorBrush(Color.FromRgb(0xE8, 0xEE, 0xF6))),
            ShadowOpacity = 0.22
        };

        private static readonly Palette DarkPalette = new Palette
        {
            Surface = Freeze(new SolidColorBrush(Color.FromRgb(0x2B, 0x2F, 0x36))),
            Border = Freeze(new SolidColorBrush(Color.FromRgb(0x4A, 0x51, 0x5B))),
            Text = Freeze(new SolidColorBrush(Color.FromRgb(0xEC, 0xEE, 0xF1))),
            Muted = Freeze(new SolidColorBrush(Color.FromRgb(0xA6, 0xAD, 0xB8))),
            Faint = Freeze(new SolidColorBrush(Color.FromRgb(0x80, 0x88, 0x94))),
            Hover = Freeze(new SolidColorBrush(Color.FromRgb(0x3A, 0x41, 0x4B))),
            ShadowOpacity = 0.45
        };

        // Offsets from the cursor hot-spot to the visible card (DIPs).
        private const double CursorOffsetX = 12;
        private const double CursorOffsetY = 6;

        private readonly List<RecentResolvedItem> _items;
        private readonly List<Border> _rows = new List<Border>();
        private readonly Palette _palette;
        private readonly bool _dark;
        private readonly bool _useThumbnails;
        private readonly int _thumbnailSize;

        private NativeMethods.POINT _cursor;
        private bool _haveCursor;

        private int _highlight;
        private int _pressed = -1;
        private bool _ready;
        private bool _closing;

        public RecentResolvedItem Selected { get; private set; }

        public RecentFivePopup(IntPtr revitMainWindow, IEnumerable<RecentResolvedItem> items, bool dark)
        {
            InitializeComponent();

            _dark = dark;
            StateStore.GetRecentFiveVisualOptions(out _useThumbnails, out _thumbnailSize);
            _palette = dark ? DarkPalette : LightPalette;

            _items = (items ?? Enumerable.Empty<RecentResolvedItem>())
                .Where(x => x != null)
                .Take(5)
                .ToList();

            // Owner BEFORE the HWND exists: owned by Revit, never in the taskbar,
            // always above Revit, returns focus to Revit when closed.
            if (revitMainWindow != IntPtr.Zero)
                new WindowInteropHelper(this).Owner = revitMainWindow;

            // Where the user clicked (ribbon button) or where the mouse is (shortcut key).
            _haveCursor = NativeMethods.GetCursorPos(out _cursor);

            ApplyPalette();
            BuildRows();
            UpdateHighlight();

            AutomationProperties.SetName(this, "Recent families and lines");

            SourceInitialized += OnSourceInitialized;
            ContentRendered += OnContentRendered;
            PreviewKeyDown += OnPreviewKeyDown;
            PreviewMouseDown += OnPreviewMouseDown;
            LostMouseCapture += OnLostMouseCapture;
            Deactivated += OnDeactivated;
            Closing += (s, e) => _closing = true;
        }

        // ------------------------------------------------------------------
        // Visuals
        // ------------------------------------------------------------------

        private void ApplyPalette()
        {
            Card.Background = _palette.Surface;
            Card.BorderBrush = _palette.Border;

            ShadowLayer.Background = _palette.Surface;
            ShadowLayer.Effect = new DropShadowEffect
            {
                BlurRadius = 12,
                ShadowDepth = 2,
                Direction = 270,
                Color = Colors.Black,
                Opacity = _palette.ShadowOpacity
            };
        }

        private void BuildRows()
        {
            ItemsPanel.Children.Clear();
            _rows.Clear();

            for (int i = 0; i < _items.Count; i++)
            {
                int index = i;
                RecentResolvedItem item = _items[i];

                var grid = new Grid();
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                bool useRealThumbnail = _useThumbnails && !item.IsLine;
                double visualSize = useRealThumbnail ? _thumbnailSize : 18;
                var icon = new Image
                {
                    Source = useRealThumbnail
                        ? PreviewImageFactory.GetOrFallback(item.ElementType ?? item.Symbol, item.State, _thumbnailSize, _dark)
                        : CategoryIconFactory.Create(item.State, _dark),
                    Width = visualSize,
                    Height = visualSize,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(1, 0, 9, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                // Keep real Revit previews crisp when a 128px cached source is shown
                // at a much smaller DIP size.
                RenderOptions.SetBitmapScalingMode(icon, BitmapScalingMode.HighQuality);
                RenderOptions.SetEdgeMode(icon, EdgeMode.Unspecified);
                Grid.SetColumn(icon, 0);
                grid.Children.Add(icon);

                var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };

                text.Children.Add(new TextBlock
                {
                    Text = item.PrimaryText,
                    FontWeight = FontWeights.SemiBold,
                    FontSize = 12,
                    Foreground = _palette.Text,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    LineStackingStrategy = LineStackingStrategy.BlockLineHeight,
                    LineHeight = 15
                });

                var secondary = new TextBlock
                {
                    Text = item.FamilyText,
                    FontSize = 11,
                    Foreground = _palette.Muted,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    LineStackingStrategy = LineStackingStrategy.BlockLineHeight,
                    LineHeight = 14
                };
                text.Children.Add(secondary);

                Grid.SetColumn(text, 1);
                grid.Children.Add(text);

                // Keyboard accelerator on the right, like a context menu.
                var key = new TextBlock
                {
                    Text = (i + 1).ToString(),
                    FontSize = 11,
                    Foreground = _palette.Faint,
                    Margin = new Thickness(12, 0, 1, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetColumn(key, 2);
                grid.Children.Add(key);

                var row = new Border
                {
                    Child = grid,
                    Padding = new Thickness(6, 4, 8, 4),
                    CornerRadius = new CornerRadius(4),
                    Background = Brushes.Transparent,
                    ToolTip = item.ToolTipText
                };
                ToolTipService.SetInitialShowDelay(row, 700);

                row.MouseEnter += (s, e) => { _highlight = index; UpdateHighlight(); };
                row.MouseLeftButtonDown += (s, e) => { _pressed = index; e.Handled = true; };
                row.MouseLeftButtonUp += (s, e) =>
                {
                    e.Handled = true;
                    if (_pressed == index)
                        Choose(index);
                    _pressed = -1;
                };

                _rows.Add(row);
                ItemsPanel.Children.Add(row);
            }
        }

        private void UpdateHighlight()
        {
            for (int i = 0; i < _rows.Count; i++)
                _rows[i].Background = i == _highlight ? _palette.Hover : Brushes.Transparent;
        }

        // ------------------------------------------------------------------
        // Positioning (physical pixels, monitor under the cursor)
        // ------------------------------------------------------------------

        private void OnSourceInitialized(object sender, EventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;

            try
            {
                long ex = NativeMethods.GetWindowLongPtr(hwnd, NativeMethods.GWL_EXSTYLE).ToInt64();
                NativeMethods.SetWindowLongPtr(
                    hwnd,
                    NativeMethods.GWL_EXSTYLE,
                    new IntPtr(ex | NativeMethods.WS_EX_TOOLWINDOW));
            }
            catch { }

            PositionWindow(hwnd, useActualSize: false);
        }

        private void OnContentRendered(object sender, EventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;

            // Re-check with the real window size (covers any DPI rescale), still invisible.
            PositionWindow(hwnd, useActualSize: true);

            Opacity = 1;

            if (!IsActive)
                Activate();
            Keyboard.Focus(this);

            _ready = true;

            // Context-menu style: all mouse input of this UI thread comes to us, so a click
            // on Revit (or anywhere) outside the card closes the popup instead of beeping.
            Mouse.Capture(this, CaptureMode.SubTree);
        }

        private void PositionWindow(IntPtr hwnd, bool useActualSize)
        {
            try
            {
                if (!_haveCursor)
                    _haveCursor = NativeMethods.GetCursorPos(out _cursor);
                if (!_haveCursor || hwnd == IntPtr.Zero)
                    return;

                IntPtr monitor = NativeMethods.MonitorFromPoint(_cursor, NativeMethods.MONITOR_DEFAULTTONEAREST);
                var mi = new NativeMethods.MONITORINFO { cbSize = Marshal.SizeOf(typeof(NativeMethods.MONITORINFO)) };
                if (!NativeMethods.GetMonitorInfo(monitor, ref mi))
                    return;

                NativeMethods.RECT work = mi.rcWork;
                double scale = GetScale(hwnd, monitor);

                int w, h;
                if (useActualSize &&
                    NativeMethods.GetWindowRect(hwnd, out NativeMethods.RECT wr) &&
                    wr.Right > wr.Left && wr.Bottom > wr.Top)
                {
                    w = wr.Right - wr.Left;
                    h = wr.Bottom - wr.Top;
                }
                else
                {
                    Size desired = MeasureDesired();
                    w = (int)Math.Ceiling(desired.Width * scale);
                    h = (int)Math.Ceiling(desired.Height * scale);
                }

                // Window edge is 'margin' outside the visible card (shadow area).
                int margin = (int)Math.Round(Root.Margin.Left * scale);
                int offX = (int)Math.Round(CursorOffsetX * scale);
                int offY = (int)Math.Round(CursorOffsetY * scale);

                // Prefer right/below the cursor; flip to the other side near monitor edges.
                int x = _cursor.X + offX - margin;
                if (x + w - margin > work.Right)
                    x = _cursor.X - offX - (w - margin);

                int y = _cursor.Y + offY - margin;
                if (y + h - margin > work.Bottom)
                    y = _cursor.Y - offY - (h - margin);

                // Keep the visible card fully inside this monitor's work area.
                x = Clamp(x, work.Left - margin, work.Right - w + margin);
                y = Clamp(y, work.Top - margin, work.Bottom - h + margin);

                NativeMethods.SetWindowPos(
                    hwnd, IntPtr.Zero, x, y, 0, 0,
                    NativeMethods.SWP_NOSIZE | NativeMethods.SWP_NOZORDER | NativeMethods.SWP_NOACTIVATE);
            }
            catch
            {
                // Positioning is cosmetic; never fail the command over it.
            }
        }

        private Size MeasureDesired()
        {
            var content = Content as UIElement;
            if (content == null)
                return new Size(340, 260);

            content.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            Size s = content.DesiredSize;
            return (s.Width > 0 && s.Height > 0) ? s : new Size(340, 260);
        }

        private static double GetScale(IntPtr hwnd, IntPtr monitor)
        {
            // Per-monitor-aware thread: the target monitor's DPI decides the pixel size.
            uint dpi = NativeMethods.GetPerMonitorDpiOrZero(monitor);
            if (dpi > 0)
                return dpi / 96.0;

            // System-aware (typical for Revit): Windows scales with the system DPI,
            // which is exactly WPF's device transform for this window.
            try
            {
                HwndSource src = HwndSource.FromHwnd(hwnd);
                if (src?.CompositionTarget != null)
                {
                    double m = src.CompositionTarget.TransformToDevice.M11;
                    if (m > 0)
                        return m;
                }
            }
            catch { }

            return 1.0;
        }

        private static int Clamp(int v, int min, int max)
        {
            if (max < min)
                return min;
            return v < min ? min : (v > max ? max : v);
        }

        // ------------------------------------------------------------------
        // Input
        // ------------------------------------------------------------------

        private void OnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Escape:
                    e.Handled = true;
                    Cancel();
                    return;

                case Key.Enter:
                    e.Handled = true;
                    Choose(_highlight);
                    return;

                case Key.Tab when (Keyboard.Modifiers & ModifierKeys.Shift) != 0:
                case Key.Up:
                    e.Handled = true;
                    if (_rows.Count > 0)
                    {
                        _highlight = (_highlight - 1 + _rows.Count) % _rows.Count;
                        UpdateHighlight();
                    }
                    return;

                case Key.Down:
                case Key.Tab:
                    e.Handled = true;
                    if (_rows.Count > 0)
                    {
                        _highlight = (_highlight + 1) % _rows.Count;
                        UpdateHighlight();
                    }
                    return;

                case Key.Home:
                    e.Handled = true;
                    _highlight = 0;
                    UpdateHighlight();
                    return;

                case Key.End:
                    e.Handled = true;
                    _highlight = Math.Max(0, _rows.Count - 1);
                    UpdateHighlight();
                    return;
            }

            int index = -1;
            if (e.Key == Key.D1 || e.Key == Key.NumPad1) index = 0;
            else if (e.Key == Key.D2 || e.Key == Key.NumPad2) index = 1;
            else if (e.Key == Key.D3 || e.Key == Key.NumPad3) index = 2;
            else if (e.Key == Key.D4 || e.Key == Key.NumPad4) index = 3;
            else if (e.Key == Key.D5 || e.Key == Key.NumPad5) index = 4;

            if (index >= 0)
            {
                e.Handled = true;
                Choose(index);
            }
        }

        private void OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!_ready)
                return;

            // With capture, clicks outside the window arrive here with outside coordinates.
            Point p = e.GetPosition(Card);
            bool inside = p.X >= 0 && p.Y >= 0 && p.X <= Card.ActualWidth && p.Y <= Card.ActualHeight;
            if (!inside)
            {
                e.Handled = true;
                Cancel();
            }
        }

        private void OnLostMouseCapture(object sender, MouseEventArgs e)
        {
            if (_closing || !_ready)
                return;

            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (_closing)
                    return;

                if (!IsActive)
                {
                    Cancel();
                    return;
                }

                if (Mouse.Captured == null)
                    Mouse.Capture(this, CaptureMode.SubTree);
            }), DispatcherPriority.Input);
        }

        private void OnDeactivated(object sender, EventArgs e)
        {
            // Alt+Tab, click into another application, etc.
            if (_ready)
                Cancel();
        }

        // ------------------------------------------------------------------
        // Result
        // ------------------------------------------------------------------

        private void Choose(int index)
        {
            if (_closing || index < 0 || index >= _items.Count)
                return;

            Selected = _items[index];
            Finish(true);
        }

        private void Cancel()
        {
            if (_closing)
                return;

            Selected = null;
            Finish(false);
        }

        private void Finish(bool result)
        {
            _closing = true;

            try
            {
                // Release our capture (only this UI thread's capture can exist here).
                if (Mouse.Captured != null)
                    Mouse.Capture(null);
            }
            catch { }

            try
            {
                DialogResult = result; // closes a ShowDialog window
            }
            catch
            {
                try { Close(); } catch { }
            }
        }

        private static Brush Freeze(Brush b)
        {
            b.Freeze();
            return b;
        }
    }
}

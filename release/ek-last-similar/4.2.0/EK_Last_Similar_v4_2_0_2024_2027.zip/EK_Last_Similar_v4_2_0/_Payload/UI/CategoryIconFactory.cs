using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using EK.LastSimilar.Services;
using BIC = Autodesk.Revit.DB.BuiltInCategory;

namespace EK.LastSimilar.UI
{
    public enum IconKind
    {
        Switch,
        Socket,
        Lamp,
        Fire,
        Panel,
        Line,
        Tag,
        Text,
        Wall,
        Run,
        Structure,
        Stair,
        Group,
        Callout,
        Region,
        Dimension,
        Generic
    }

    /// <summary>
    /// One small line-icon language on a fixed 20x20 grid: same stroke weight, round caps,
    /// one accent colour per kind. Category decides first (language independent); names
    /// are only a fallback for unmapped categories and old state files.
    /// </summary>
    public static class CategoryIconFactory
    {
        public const double Frame = 20.0;
        private const double Stroke = 1.45;

        private static readonly Dictionary<string, ImageSource> Cache =
            new Dictionary<string, ImageSource>();

        public static ImageSource Create(RecentTypeState entry, bool dark)
        {
            return Get(Classify(entry), dark);
        }

        public static ImageSource Get(IconKind kind, bool dark)
        {
            string key = kind + (dark ? ":d" : ":l");
            if (!Cache.TryGetValue(key, out ImageSource image))
            {
                var di = new DrawingImage(BuildDrawing(kind, Accent(kind, dark)));
                di.Freeze();
                image = di;
                Cache[key] = image;
            }

            return image;
        }

        // ------------------------------------------------------------------
        // Classification
        // ------------------------------------------------------------------

        public static IconKind Classify(RecentTypeState entry)
        {
            if (RecentItemKinds.IsLine(entry?.ItemKind))
                return IconKind.Line;

            // Tags first: a "Lighting Fixture Tag" must not borrow the lamp icon from its name.
            if (RecentItemKinds.IsTag(entry?.ItemKind))
                return IconKind.Tag;

            if (RecentItemKinds.IsElement(entry?.ItemKind))
                return ClassifyElement(entry.ElementKind);

            string names = ((entry?.FamilyName ?? "") + " " + (entry?.TypeName ?? "")).ToLowerInvariant();

            long? cat = entry?.CategoryIdValue;
            if (cat.HasValue)
            {
                long c = cat.Value;
                if (c == (long)BIC.OST_FireAlarmDevices) return IconKind.Fire;
                if (c == (long)BIC.OST_LightingDevices) return IconKind.Switch;
                if (c == (long)BIC.OST_LightingFixtures) return IconKind.Lamp;
                if (c == (long)BIC.OST_ElectricalEquipment) return IconKind.Panel;

                if (c == (long)BIC.OST_ElectricalFixtures)
                {
                    // Many offices model switches and detectors as Electrical Fixtures.
                    if (ContainsAny(names, "smoke", "fire alarm", "heat detector")) return IconKind.Fire;
                    if (ContainsAny(names, "switch", "dimmer")) return IconKind.Switch;
                    return IconKind.Socket;
                }
            }

            // Unmapped category or v1 state file: names as a fallback only.
            string all = ((entry?.CategoryName ?? "") + " " + names).ToLowerInvariant();

            if (ContainsAny(all, "fire alarm", "smoke", "heat detector"))
                return IconKind.Fire;
            if (ContainsAny(all, "switch", "lighting device", "dimmer"))
                return IconKind.Switch;
            if (ContainsAny(all, "socket", "receptacle", "outlet", "electrical fixture"))
                return IconKind.Socket;
            if (ContainsAny(all, "lighting fixture", "luminaire", "lamp", "light"))
                return IconKind.Lamp;
            if (ContainsAny(all, "electrical equipment", "panel", "board"))
                return IconKind.Panel;

            return IconKind.Generic;
        }

        private static IconKind ClassifyElement(string kind)
        {
            switch (kind)
            {
                case ElementKinds.TextNote: return IconKind.Text;
                case ElementKinds.Wall:
                case ElementKinds.CurtainWall: return IconKind.Wall;
                case ElementKinds.Duct:
                case ElementKinds.FlexDuct:
                case ElementKinds.Pipe:
                case ElementKinds.FlexPipe:
                case ElementKinds.Conduit:
                case ElementKinds.CableTray:
                case ElementKinds.DuctAccessory:
                case ElementKinds.PipeAccessory: return IconKind.Run;
                case ElementKinds.Beam:
                case ElementKinds.Brace:
                case ElementKinds.Column:
                case ElementKinds.StructuralColumn: return IconKind.Structure;
                case ElementKinds.Stair:
                case ElementKinds.Railing: return IconKind.Stair;
                case ElementKinds.ModelGroup:
                case ElementKinds.DetailGroup: return IconKind.Group;
                case ElementKinds.Callout: return IconKind.Callout;
                case ElementKinds.FilledRegion:
                case ElementKinds.MaskingRegion: return IconKind.Region;
                case ElementKinds.Dimension:
                case ElementKinds.SpotElevation:
                case ElementKinds.SpotCoordinate:
                case ElementKinds.SpotSlope: return IconKind.Dimension;
                default: return IconKind.Generic;
            }
        }

        private static bool ContainsAny(string text, params string[] words)
        {
            foreach (string w in words)
                if (text.IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;
            return false;
        }

        // ------------------------------------------------------------------
        // Colours
        // ------------------------------------------------------------------

        public static Color Accent(IconKind kind, bool dark)
        {
            switch (kind)
            {
                case IconKind.Switch: return dark ? Rgb(0x86, 0xB0, 0xF2) : Rgb(0x25, 0x63, 0xC9);
                case IconKind.Socket: return dark ? Rgb(0x6F, 0xCC, 0x9F) : Rgb(0x1E, 0x7D, 0x52);
                case IconKind.Lamp: return dark ? Rgb(0xF0, 0xC2, 0x5E) : Rgb(0xB0, 0x72, 0x10);
                case IconKind.Fire: return dark ? Rgb(0xF2, 0x8B, 0x82) : Rgb(0xC4, 0x30, 0x2B);
                case IconKind.Panel: return dark ? Rgb(0xB9, 0xC2, 0xCE) : Rgb(0x47, 0x55, 0x69);
                case IconKind.Line: return dark ? Rgb(0x9A, 0xB4, 0xDF) : Rgb(0x68, 0x82, 0xB6);
                case IconKind.Tag: return dark ? Rgb(0xC3, 0xA6, 0xEE) : Rgb(0x6D, 0x4A, 0xB5);
                // Annotation (text, callouts, regions, dimensions) shares one slate blue.
                case IconKind.Text:
                case IconKind.Callout:
                case IconKind.Region:
                case IconKind.Dimension: return dark ? Rgb(0xA9, 0xB6, 0xE8) : Rgb(0x4A, 0x5A, 0x9A);
                case IconKind.Wall:
                case IconKind.Stair: return dark ? Rgb(0xD9, 0xB7, 0x7A) : Rgb(0x8A, 0x63, 0x2A);
                case IconKind.Run: return dark ? Rgb(0x6F, 0xD0, 0xD8) : Rgb(0x0E, 0x76, 0x80);
                case IconKind.Structure: return dark ? Rgb(0xEE, 0x9F, 0x86) : Rgb(0xA3, 0x48, 0x2A);
                case IconKind.Group: return dark ? Rgb(0xA7, 0xAF, 0xBA) : Rgb(0x55, 0x5E, 0x6B);
                default: return dark ? Rgb(0xA7, 0xAF, 0xBA) : Rgb(0x6B, 0x72, 0x80);
            }
        }

        private static Color Rgb(byte r, byte g, byte b) => Color.FromRgb(r, g, b);

        // ------------------------------------------------------------------
        // Glyphs (20 x 20)
        // ------------------------------------------------------------------

        public static Drawing BuildDrawing(IconKind kind, Color accent)
        {
            var ink = new SolidColorBrush(accent);
            ink.Freeze();

            var pen = new Pen(ink, Stroke)
            {
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round,
                LineJoin = PenLineJoin.Round
            };
            pen.Freeze();

            var group = new DrawingGroup();
            using (DrawingContext dc = group.Open())
            {
                // Fixed frame: identical bounds for every icon => identical scaling.
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, Frame, Frame));

                switch (kind)
                {
                    case IconKind.Switch:
                        // Wall plate with a tilted rocker.
                        dc.DrawRoundedRectangle(null, pen, new Rect(4.5, 2.5, 11, 15), 2.2, 2.2);
                        dc.DrawGeometry(ink, null, Geometry.Parse("M 7.8,6.6 L 12.2,5.6 L 12.2,14.4 L 7.8,13.4 Z"));
                        break;

                    case IconKind.Socket:
                        // Socket face: round face, two pins.
                        dc.DrawEllipse(null, pen, new Point(10, 10), 7, 7);
                        dc.DrawEllipse(ink, null, new Point(7.3, 10), 1.35, 1.35);
                        dc.DrawEllipse(ink, null, new Point(12.7, 10), 1.35, 1.35);
                        break;

                    case IconKind.Lamp:
                        // Bulb with screw base.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 7.6,13.2 C 5.6,11.9 4.8,10.2 4.8,8.3 C 4.8,5.2 7.1,2.8 10,2.8 " +
                            "C 12.9,2.8 15.2,5.2 15.2,8.3 C 15.2,10.2 14.4,11.9 12.4,13.2 Z"));
                        dc.DrawLine(pen, new Point(7.8, 15.2), new Point(12.2, 15.2));
                        dc.DrawLine(pen, new Point(8.6, 17.4), new Point(11.4, 17.4));
                        break;

                    case IconKind.Fire:
                        // Flame.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 10,2.4 C 12.9,5.6 15,7.8 14.6,11.5 C 14.2,15 12.2,17.4 9.8,17.4 " +
                            "C 6.9,17.4 5,15 5.3,12 C 5.6,9.6 7.2,8.6 7.6,6.2 " +
                            "C 8.7,7.3 9.4,8.4 9.4,9.9 C 11,8.5 11.4,5.8 10,2.4 Z"));
                        break;

                    case IconKind.Panel:
                        // Distribution board with bolt.
                        dc.DrawRoundedRectangle(null, pen, new Rect(4.2, 2.5, 11.6, 15), 1.2, 1.2);
                        dc.DrawGeometry(ink, null, Geometry.Parse(
                            "M 11.1,4.9 L 7.6,10.5 L 10.1,10.5 L 8.9,15.1 L 12.6,9.3 L 10.1,9.3 Z"));
                        break;

                    case IconKind.Line:
                        // Straight line style: a bold sample segment with endpoint dots.
                        dc.DrawLine(pen, new Point(3.2, 14.6), new Point(16.8, 5.4));
                        dc.DrawEllipse(ink, null, new Point(3.2, 14.6), 1.25, 1.25);
                        dc.DrawEllipse(ink, null, new Point(16.8, 5.4), 1.25, 1.25);
                        break;

                    case IconKind.Text:
                        // Letter A.
                        dc.DrawGeometry(null, pen, Geometry.Parse("M 4.8,16.6 L 10,3.4 L 15.2,16.6 M 6.9,11.6 L 13.1,11.6"));
                        break;

                    case IconKind.Wall:
                        // Wall in plan: outline with hatch.
                        dc.DrawRectangle(null, pen, new Rect(2.8, 6.6, 14.4, 6.8));
                        dc.DrawGeometry(null, pen, Geometry.Parse("M 5.4,13.4 L 9.6,6.6 M 9.6,13.4 L 13.8,6.6"));
                        break;

                    case IconKind.Run:
                        // Pipe/duct segment with two flanges.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 2.6,7.4 L 17.4,7.4 M 2.6,12.6 L 17.4,12.6 M 6,5 L 6,15 M 14,5 L 14,15"));
                        break;

                    case IconKind.Structure:
                        // I-section.
                        dc.DrawGeometry(null, pen, Geometry.Parse("M 4.4,3.6 L 15.6,3.6 M 4.4,16.4 L 15.6,16.4 M 10,3.6 L 10,16.4"));
                        break;

                    case IconKind.Stair:
                        // Steps.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 3,16.6 L 6.6,16.6 L 6.6,12.9 L 10.2,12.9 L 10.2,9.2 L 13.8,9.2 L 13.8,5.5 L 17,5.5 L 17,3.4"));
                        break;

                    case IconKind.Group:
                        // Corner brackets around a block.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 3,7 L 3,3 L 7,3 M 13,3 L 17,3 L 17,7 M 17,13 L 17,17 L 13,17 M 7,17 L 3,17 L 3,13"));
                        dc.DrawRectangle(ink, null, new Rect(7.2, 7.2, 5.6, 5.6));
                        break;

                    case IconKind.Callout:
                        // Rounded callout bubble with a leader.
                        dc.DrawRoundedRectangle(null, pen, new Rect(3, 3, 14, 9.6), 3.2, 3.2);
                        dc.DrawGeometry(null, pen, Geometry.Parse("M 7.4,12.6 L 4.6,17 M 4.6,17 L 9.4,15.4"));
                        break;

                    case IconKind.Region:
                        // Region with hatch.
                        dc.DrawRoundedRectangle(null, pen, new Rect(3, 3, 14, 14), 1.2, 1.2);
                        dc.DrawGeometry(null, pen, Geometry.Parse("M 3.6,10.6 L 10.6,3.6 M 6.4,16.4 L 16.4,6.4 M 11.8,16.4 L 16.4,11.8"));
                        break;

                    case IconKind.Dimension:
                        // Dimension line with extension lines and ticks.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 3,10.6 L 17,10.6 M 3,5.4 L 3,15 M 17,5.4 L 17,15 M 1.9,12.2 L 4.6,9 M 15.4,12.2 L 18.1,9"));
                        break;

                    case IconKind.Tag:
                        // Label tag with a punched hole.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 3.2,7.2 L 7.6,3.4 L 16.8,3.4 L 16.8,16.6 L 7.6,16.6 L 3.2,12.8 Z"));
                        dc.DrawEllipse(ink, null, new Point(7.4, 10), 1.3, 1.3);
                        dc.DrawLine(pen, new Point(10.6, 8), new Point(14.2, 8));
                        dc.DrawLine(pen, new Point(10.6, 12), new Point(13.2, 12));
                        break;

                    default:
                        // Generic family: isometric box.
                        dc.DrawGeometry(null, pen, Geometry.Parse(
                            "M 10,2.6 L 16.2,6 L 16.2,13.6 L 10,17 L 3.9,13.6 L 3.9,6 Z " +
                            "M 3.9,6 L 10,9.4 L 16.2,6 M 10,9.4 L 10,17"));
                        break;
                }
            }

            group.Freeze();
            return group;
        }
    }
}

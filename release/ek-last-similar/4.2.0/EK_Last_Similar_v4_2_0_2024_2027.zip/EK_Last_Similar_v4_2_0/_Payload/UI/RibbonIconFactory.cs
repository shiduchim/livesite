using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace EK.LastSimilar.UI
{
    /// <summary>
    /// Ribbon images as real bitmaps at exact 16/32 DIP sizes, rendered at 2x pixel density
    /// so they stay sharp on 150-200 % displays. Mid-tone colours read on light and dark ribbons.
    ///
    /// One shared language on the 20x20 icon grid: a blue "family" block is the placed type,
    /// slate grey marks the action around it.
    ///   Last Similar : a clockwise repeat arrow around a family block ("place it again").
    ///   Recent 5     : a short list of types with a blue "5" badge ("pick one of the last 5").
    ///   Settings     : a gear.
    /// </summary>
    public static class RibbonIconFactory
    {
        private static readonly Color Slate = Color.FromRgb(0x76, 0x82, 0x95);
        private static readonly Color Blue = Color.FromRgb(0x2B, 0x6C, 0xD4);
        private static readonly Color BlueLight = Color.FromRgb(0x7F, 0xA8, 0xEA);
        private static readonly Color BlueDark = Color.FromRgb(0x1F, 0x4F, 0x9E);

        public static ImageSource CreateMainIcon(int sizeDip)
        {
            var group = new DrawingGroup();
            using (DrawingContext dc = group.Open())
            {
                DrawFrame(dc);

                // Clockwise repeat arrow, open at the top, arrow head at the upper left.
                dc.DrawGeometry(null, MakePen(Slate, 1.8), Geometry.Parse("M 15.82,5.31 A 7.6,7.6 0 1 1 4.63,4.83"));
                dc.DrawGeometry(MakeBrush(Slate), null, Geometry.Parse("M 6.75,2.7 L 2.72,3.2 L 6.25,6.74 Z"));

                DrawFamilyBlock(dc);
            }

            group.Freeze();
            return Render(group, sizeDip);
        }

        public static ImageSource CreateRecentFiveIcon(int sizeDip)
        {
            var group = new DrawingGroup();
            using (DrawingContext dc = group.Open())
            {
                DrawFrame(dc);

                Brush slate = MakeBrush(Slate);
                Pen row = MakePen(Slate, 1.5);

                // Four list rows; the lower two are short so the badge has room.
                double[] ys = { 3.4, 7.1, 10.8, 14.5 };
                for (int i = 0; i < ys.Length; i++)
                {
                    double y = ys[i];
                    dc.DrawRectangle(slate, null, new Rect(2.2, y - 1.2, 2.4, 2.4));
                    dc.DrawLine(row, new Point(6.8, y), new Point(i < 2 ? 17.6 : 8.0, y));
                }

                // "5" badge.
                dc.DrawEllipse(MakeBrush(Blue), null, new Point(14.4, 14.6), 5.0, 5.0);
                dc.DrawGeometry(null, MakePen(Colors.White, 1.25), Geometry.Parse(
                    "M 16.4,11.9 H 13.4 L 13.1,14.3 C 13.8,13.9 14.6,13.8 15.3,14.0 " +
                    "C 16.8,14.4 17.1,16.4 15.9,17.2 C 15.1,17.8 13.8,17.7 12.9,17.0"));
            }

            group.Freeze();
            return Render(group, sizeDip);
        }

        public static ImageSource CreateSettingsIcon(int sizeDip)
        {
            var group = new DrawingGroup();
            using (DrawingContext dc = group.Open())
            {
                DrawFrame(dc);

                // Eight-tooth gear with a centre hole (path mini-language default: even-odd fill).
                dc.DrawGeometry(MakeBrush(Slate), null, Geometry.Parse(
                    "M 8.34,3.82 L 8.73,1.49 L 11.27,1.49 L 11.66,3.82 L 13.2,4.46 L 15.12,3.09 " +
                    "L 16.91,4.88 L 15.54,6.8 L 16.18,8.34 L 18.51,8.73 L 18.51,11.27 L 16.18,11.66 " +
                    "L 15.54,13.2 L 16.91,15.12 L 15.12,16.91 L 13.2,15.54 L 11.66,16.18 L 11.27,18.51 " +
                    "L 8.73,18.51 L 8.34,16.18 L 6.8,15.54 L 4.88,16.91 L 3.09,15.12 L 4.46,13.2 " +
                    "L 3.82,11.66 L 1.49,11.27 L 1.49,8.73 L 3.82,8.34 L 4.46,6.8 L 3.09,4.88 " +
                    "L 4.88,3.09 L 6.8,4.46 Z " +
                    "M 12.7,10 A 2.7,2.7 0 1 0 7.3,10 A 2.7,2.7 0 1 0 12.7,10 Z"));
            }

            group.Freeze();
            return Render(group, sizeDip);
        }

        /// <summary>Isometric block = "a family type", three shaded faces.</summary>
        private static void DrawFamilyBlock(DrawingContext dc)
        {
            dc.DrawGeometry(MakeBrush(BlueLight), null, Geometry.Parse("M 10,6.17 L 14.4,8.59 L 10,11.01 L 5.6,8.59 Z"));
            dc.DrawGeometry(MakeBrush(Blue), null, Geometry.Parse("M 5.6,8.59 L 10,11.01 L 10,15.63 L 5.6,13.21 Z"));
            dc.DrawGeometry(MakeBrush(BlueDark), null, Geometry.Parse("M 10,11.01 L 14.4,8.59 L 14.4,13.21 L 10,15.63 Z"));
        }

        /// <summary>Fixed transparent frame: identical bounds for every icon => identical scaling.</summary>
        private static void DrawFrame(DrawingContext dc)
        {
            dc.DrawRectangle(
                Brushes.Transparent,
                null,
                new Rect(0, 0, CategoryIconFactory.Frame, CategoryIconFactory.Frame));
        }

        private static Brush MakeBrush(Color color)
        {
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }

        private static Pen MakePen(Color color, double width)
        {
            var pen = new Pen(MakeBrush(color), width)
            {
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round,
                LineJoin = PenLineJoin.Round
            };
            pen.Freeze();
            return pen;
        }

        private static ImageSource Render(Drawing drawing, int sizeDip)
        {
            const int density = 2;
            int px = sizeDip * density;

            var visual = new DrawingVisual();
            using (DrawingContext dc = visual.RenderOpen())
            {
                double s = sizeDip / CategoryIconFactory.Frame;
                dc.PushTransform(new ScaleTransform(s, s));
                dc.DrawDrawing(drawing);
                dc.Pop();
            }

            var bmp = new RenderTargetBitmap(px, px, 96.0 * density, 96.0 * density, PixelFormats.Pbgra32);
            bmp.Render(visual);
            bmp.Freeze();
            return bmp;
        }
    }
}

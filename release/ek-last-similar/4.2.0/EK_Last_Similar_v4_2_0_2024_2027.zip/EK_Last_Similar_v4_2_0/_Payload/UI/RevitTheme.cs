using System;
using System.Reflection;

namespace EK.LastSimilar.UI
{
    /// <summary>
    /// Reads Revit's UI theme (Light/Dark) if the running Revit exposes it.
    /// Reflection only: no Revit year can fail to compile or load because of it.
    /// </summary>
    internal static class RevitTheme
    {
        public static bool IsDark()
        {
            try
            {
                Assembly uiAssembly = typeof(Autodesk.Revit.UI.UIApplication).Assembly;
                Type manager = uiAssembly.GetType("Autodesk.Revit.UI.UIThemeManager", false);
                PropertyInfo current = manager?.GetProperty("CurrentTheme", BindingFlags.Public | BindingFlags.Static);
                object value = current?.GetValue(null, null);
                return value != null &&
                       value.ToString().IndexOf("Dark", StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch
            {
                return false;
            }
        }
    }
}

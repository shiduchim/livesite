# Read-only diagnostic collection. Does not change Revit, shortcuts, or EK settings.
[CmdletBinding()]
param([string]$OutputFolder = [Environment]::GetFolderPath('Desktop'))
$ErrorActionPreference = 'Stop'
$source = Join-Path $env:APPDATA 'EK\LastSimilar'
if (-not (Test-Path -LiteralPath $source)) { throw 'No EK Last Similar diagnostic folder found. Enable Troubleshooting and repeat the test first.' }
if (-not $OutputFolder) { $OutputFolder = Split-Path -Parent $PSScriptRoot }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$name = 'EK_Last_Similar_Diagnostics_' + $stamp + '_' + [Guid]::NewGuid().ToString('N').Substring(0,6)
$stage = Join-Path ([IO.Path]::GetTempPath()) $name
$zip = Join-Path $OutputFolder ($name + '.zip')
$notes = New-Object System.Collections.Generic.List[string]
$notes.Add('EK Last Similar diagnostic collection, UTC ' + [DateTime]::UtcNow.ToString('o'))
$notes.Add('This ZIP contains logs and filtered journal command lines, not model files or state-csharp.json.')
$notes.Add('Command names and local document/file paths can appear in these diagnostics.')
New-Item -ItemType Directory -Path $stage -Force | Out-Null
try {
    $files = @()
    $traceDir = Join-Path $source 'Diagnostics'
    if (Test-Path -LiteralPath $traceDir) {
        $files += @(Get-ChildItem -LiteralPath $traceDir -Filter 'trace-*.log' -File |
            Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 12)
    }
    $legacy = Join-Path $source 'last-run.log'
    if (Test-Path -LiteralPath $legacy) { $files += Get-Item -LiteralPath $legacy }
    if ($files.Count -eq 0) { throw 'No logs found. Enable Troubleshooting in EK Last Similar Settings and repeat the test.' }
    $journals = @{}
    $copied = 0
    foreach ($file in $files) {
        try {
            $destination = Join-Path $stage $file.Name
            Copy-Item -LiteralPath $file.FullName -Destination $destination
            $copied++
            foreach ($line in Get-Content -LiteralPath $destination -Encoding UTF8) {
                if ($line -match 'JOURNAL PATH: (.+)$') { $journals[$Matches[1].Trim()] = $true }
            }
        } catch { $notes.Add('Could not copy ' + $file.FullName + ': ' + $_.Exception.Message) }
    }
    if ($copied -eq 0) { throw 'No diagnostic logs could be copied.' }
    $index = 0
    foreach ($path in $journals.Keys) {
        $index++
        try {
            $commands = New-Object System.Collections.Generic.List[string]
            $commands.Add('Source: ' + $path)
            $commands.Add('Collected UTC: ' + [DateTime]::UtcNow.ToString('o'))
            $commands.Add('Filtered from the last 6000 lines. A live journal may not yet have flushed all commands.')
            $remaining = 0
            foreach ($line in Get-Content -LiteralPath $path -Tail 6000) {
                $trimmed = $line.Trim()
                if ($trimmed -match 'Jrn\.Command|EKLS_DIAG') { $remaining = 3 }
                if ($remaining -gt 0) {
                    $commands.Add($trimmed)
                    if ($trimmed.EndsWith('_')) { $remaining-- } else { $remaining = 0 }
                }
            }
            $commands | Set-Content -LiteralPath (Join-Path $stage ('journal-commands-' + $index + '.txt')) -Encoding UTF8
        } catch { $notes.Add('Could not read journal ' + $path + ': ' + $_.Exception.Message) }
    }
    $notes | Set-Content -LiteralPath (Join-Path $stage 'COLLECTION_INFO.txt') -Encoding UTF8
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip
    Write-Host ('Created: ' + $zip) -ForegroundColor Green
    Write-Host 'Send that ZIP after testing LL and the EK Last Similar ribbon button.'
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}

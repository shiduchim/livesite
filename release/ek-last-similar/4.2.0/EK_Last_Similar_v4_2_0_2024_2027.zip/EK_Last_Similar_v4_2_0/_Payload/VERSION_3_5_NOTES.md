# EK Last Similar v3.5

Changes from v3.4:

- Added optional real Revit family/type thumbnails to Recent 5.
- Added Settings toggle: **Use Revit type thumbnails**.
- Added thumbnail sizes: 20, 24, 28, 32, 40 px.
- Default is thumbnails ON at 24 px for new/older state files.
- Preview images are cached; unavailable previews fall back to the existing category icon.
- Recent 5 second line now shows only the family name; category text is no longer repeated.
- Dedicated Recent 5 Revit command and all v3.2/v3.4 safety logic are unchanged.

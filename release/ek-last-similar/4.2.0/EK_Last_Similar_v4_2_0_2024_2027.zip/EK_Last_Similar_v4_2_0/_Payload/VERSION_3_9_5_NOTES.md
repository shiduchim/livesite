# EK Last Similar 4.0.0

## Quiet normal mode + opt-in troubleshooting

New Settings option:

    Troubleshooting
    [ ] Enable diagnostic log + warnings

Default: OFF.

When OFF:
- `last-run.log` is not written or appended to.
- forensic/skipped-correction warning dialogs are suppressed.
- normal placement remains quiet.
- true placement errors that prevent Revit from placing the family can still show an error.

When ON:
- the v3.9.4 rolling forensic `last-run.log` is active.
- skipped-correction/type/unsafe-host diagnostic warning dialogs are active.
- passive tracker diagnostic lines are active.

The option is global and persists in `state-csharp.json`.
Older state files default to OFF.

Save/Close behavior is preserved:
- Save commits this option and closes Settings.
- Close cancels an unsaved change to this option.

Existing `last-run.log` files are not deleted when troubleshooting is turned off;
they are simply no longer updated, preserving old evidence.

All v3.9.4 height/level/host fixes remain unchanged.

@echo off
setlocal
title EK Last Similar - Uninstall

tasklist /FI "IMAGENAME eq Revit.exe" 2>nul | find /I "Revit.exe" >nul
if not errorlevel 1 goto :revit_running

set "ROAM=%APPDATA%\Autodesk"

if exist "%ROAM%\ApplicationPlugins\EKLastSimilar.bundle" rmdir /s /q "%ROAM%\ApplicationPlugins\EKLastSimilar.bundle"
if exist "%ROAM%\EKLastSimilar.install-staging" rmdir /s /q "%ROAM%\EKLastSimilar.install-staging"
if exist "%ROAM%\EKLastSimilar.install-previous" rmdir /s /q "%ROAM%\EKLastSimilar.install-previous"

for %%Y in (2024 2025 2026 2027) do (
  if exist "%ROAM%\Revit\Addins\%%Y\EKLastSimilar.addin" del /q "%ROAM%\Revit\Addins\%%Y\EKLastSimilar.addin"
  if exist "%ROAM%\Revit\Addins\%%Y\EKLastSimilar" rmdir /s /q "%ROAM%\Revit\Addins\%%Y\EKLastSimilar"
)

if not exist "%ROAM%\ApplicationPlugins\EKLastSimilar.bundle" goto :removed
echo WARNING: the bundle folder could not be removed completely:
echo   "%ROAM%\ApplicationPlugins\EKLastSimilar.bundle"
pause
exit /b 1

:removed

echo.
echo EK Last Similar was uninstalled.
echo Your recent types and heights in %%APPDATA%%\EK\LastSimilar were kept.
echo.
pause
exit /b 0

:revit_running
echo Revit is running. Close ALL Revit sessions first.
pause
exit /b 1

# 4.1.0 — tags

New item kinds in history (`ItemKind`): `tag` (IndependentTag: category, multi-category,
material tags), `space-tag`, `area-tag`. `room-tag` is unchanged. `RecentItemKinds.IsTag`
covers all four; everything that excluded Room Tags from heights now excludes all tags.

Files:
- `Services/TagSimilarService.cs` (new): tracking rules and native start for the new kinds.
  Same contract as `RoomTagSimilarService`: `CanPlaceElementType` → `PostRequestForElementTypePlacement`,
  else `Create Similar` from an exact-type tag in the active view, else a message. No transaction,
  no default-type substitution, no custom pick loop, no height workflow.
- `LastPlacedTracker`: a commit counts when it adds exactly one trackable item. A category tag
  whose tagged element was added in the same commit ("Tag on Placement") is ignored, so the family
  is recorded. Keynote tags, group members, view duplication, Undo/Redo and sync stay excluded.
- `CommandRunner`: tag kinds dispatch to `TagSimilarService` before the family workflow.
- `StateStore`/`StateModels`/`SettingsWindow`: tag kinds never store or show heights.
- `CategoryIconFactory`: tag icon; tags no longer borrow a fixture icon from their family name.
- `RoomTagSimilarService`: fallback collector fixed (`OfClass(typeof(SpatialElementTag)).OfType<RoomTag>()`;
  Revit throws for `OfClass(typeof(RoomTag))`).

API used (2024–2027): `IndependentTag`, `IndependentTag.GetTaggedLocalElementIds()` (2022+),
`Autodesk.Revit.DB.Mechanical.SpaceTag`, `AreaTag`, `SpatialElementTag`, `Element.GetTypeId()`,
`UIDocument.CanPlaceElementType/PostRequestForElementTypePlacement`, `PostableCommand.TagByCategory/CreateSimilar`,
`BuiltInCategory.OST_KeynoteTags`. No `IntegerValue`.

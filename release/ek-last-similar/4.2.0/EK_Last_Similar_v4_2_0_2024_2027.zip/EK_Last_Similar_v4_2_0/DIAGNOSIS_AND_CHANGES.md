# Investigation and release changes — 4.0.3

## What the logs prove

| Evidence | Proven result |
|---|---|
| October 18, process 29096, add-in 4.0.0 | Glass devices 1793572/1793611 were captured. Their linked curtain panels were resolved correctly but classified as unsupported `Other`. Regular-wall device 1793633 was corrected. |
| October 18, 12:00:19–22 background events | Four `VerticalFace` devices (1798148, 1798187, 1798237, 1798287) and one `Wall` device (1798381) were recorded with no active EK family-placement session. These lines do not themselves identify a process or add-in version. |
| October 18, process 27468, explicitly 4.0.1 | Regular-wall device 1798476 was captured and corrected. There is no corresponding captured glass placement in that command. |
| October 19, process 28640, explicitly 4.0.1 | Glass devices 1824224/1824273 were captured by LL, recognized as linked vertical faces on panel 1556273, and attempted height correction. Both rolled back at the test that the new point lies on/near the host face. |
| October 19 installer excerpt labeled 4.0.2 | Revit 2024 build succeeded on the user's machine. The excerpt ends at the 2025 build start. It does not show completed 2025–2027 builds or installation success. |

Older 3.9.2/3.9.4 records are also present. The shared append-only log mixes runs and processes. Its version headers identify **EK versions**, not the running Revit major version. A model filename ending in R25 does not establish the running Revit version. The background `VerticalFace` entries cannot be assigned to the preceding 4.0.0 header: 4.0.0 did not have that classification. Thus the original narrative of exactly five glass clicks and one wall click cannot be reconstructed conclusively from those records.

The October 19 evidence changes the diagnosis: a capture-only explanation does not explain the later failures. They reached the height transaction. The saved fixed height was read as 1100 mm; the separately learned 200 mm value was explicitly ignored. Both failures restored their original Z values (740/780 mm).

## Source comparison and placement workflow

4.0.0 recognized only wall/ceiling linked hosts for these corrections. Its panel rejection was intentional code behavior, not failure to identify the linked element. 4.0.1 added `VerticalFace`, face-normal classification, and same-host/same-face/post-correction surface checks, but assumed the returned face was already in the host document's coordinate system.

The existing model-family workflow remains:

1. LL invokes `LastSimilarCommand.Execute`; it resolves the true last placed type and its saved height settings. Recent 5/Settings selection dispatches through `CommandRunner.Place` too.
2. `PlacementService.PlaceAndFinalize` activates the type if needed, marks the requested type active and attaches a temporary read-only `DocumentChanged` handler before `PromptForFamilyInstancePlacement`.
3. Fresh commits in the same document contribute new eligible `FamilyInstance` IDs of exactly the requested type. A changed Type Selector is logged separately and those other types are not corrected. Undo/Redo are not fresh placements.
4. The permanent `LastPlacedTracker` independently updates JSON history. During an active EK session of the same type it does not learn the pre-correction height. Outside such a session it records history only; it never moves anything.
5. Ending the native prompt detaches the temporary handler and clears the active session. The captured IDs are then processed. Classification therefore happens **after capture**, not as a condition for setting the active-session flag.
6. Linked hosts are resolved using `FamilyInstance.Host` as the link instance, `HostFace.LinkedElementId`, the loaded link document and `CreateReferenceInLink`. Excluded host categories are rejected before geometric eligibility.
7. The existing height rule selects the highest host-document level at/below the clicked Z. Fixed height remains 1100 mm above that level. In the October 19 case the chosen level is 590 mm, giving target absolute Z 1690 mm.
8. The correction uses existing Schedule Level/Elevation parameters, regenerates, verifies, and commits or rolls back its transaction. It does not delete/recreate, rotate or rehost the family. Successful corrections remain assimilated into the existing single correction Undo step; native placement keeps its existing transaction behavior. The command returns success when native placement committed anything, even if correction failed, so placed devices are retained.

## Confirmed defect versus unresolved causes

**Confirmed source defect:** 4.0.1 `HostClassifier.IsPointNearCurrentHostFace` projected a point transformed only into link-document coordinates onto the face returned by `GetGeometryObjectFromReference`. Its normal classification had the same incomplete transform assumption. A family/panel face may be in geometry-instance/symbol coordinates. The needed mapping is the composed link transform and every enclosing geometry-instance transform. Applying just the link transform is insufficient; always applying a family transform would also be wrong for solids already at document level.

A deterministic regression fixture reproduces a valid panel position rejected by the old calculation and accepted by the corrected calculation. Ordinary wall geometry commonly follows a different coordinate path, and 4.0.1 applied its extra surface-boundary postcheck only to `VerticalFace`, explaining a relevant code-path difference.

**Confirmed failure stage:** the October 19 glass attempts failed the post-move surface check. By the order of checks in 4.0.1, XY, expected Z, Schedule Level, host identity and stable face-reference checks had already passed. That is evidence the API could make the attempted parameter change before rollback, not proof it is safe for every family or target.

**Still unproven for the actual panel:** the log does not contain the panel's geometry-instance transforms or trimmed face bounds. The transform defect is a plausible explanation, but a target actually outside the panel, or a family insertion offset outside the prior tolerance, can also produce that failure. A live model or the new resolved-face trace is needed to separate them. The fix preserves those safety rejections.

**Original outside-EK events:** the label means the observing assembly's active family-session flag was unset at the event. It does not prove which shortcut was pressed or which command Revit ran. Duplicate LL bindings, native Create Similar, another loaded add-in assembly/process, or a command finishing before a native placement are hypotheses, not established causes. No unsafe background auto-correction has been added to conceal this uncertainty. Optional diagnostics now correlate process, Revit/add-in versions, assembly load, command run, shortcut entries, journal command markers, prompt boundaries and tracker events.

## Small functional correction

`HostFaceGeometry` walks original geometry, matches the exact stable face reference, and composes `GeometryInstance.Transform` values with the link transform. Top-level document solids receive no extra family transform. Missing, ambiguous or unsupported references fail closed.

Before writing parameters it verifies both points project inside the trimmed face, both normals are vertical in model coordinates, the original mounting offset is within 100 mm, and the requested Z change preserves that offset within 0.5 mm. Existing approximately 7-degree classification tolerance remains; the offset-preservation test additionally rejects unsafe movement on sloped faces. Floors, roofs, ceilings and the existing excluded categories stay excluded even if they expose a vertical edge face.

After regeneration it checks host identity, stable face, final trimmed-face projection, mounting offset, XY and target height, physical basis vectors and flip/mirror state. A failed check rolls back. Physical axes are checked instead of relying only on `LocationPoint.Rotation`, whose reported value is not a sufficient description of face-hosted orientation. Traditional wall-hosted families without a HostFace retain their same-wall path.

## Independent Room Tag addition

`RoomTag` is an annotation; `RoomTagType` derives from `FamilySymbol`. Sharing the type/history container therefore does not justify using family-instance placement.

The passive tracker now recognizes one actual `RoomTag` placement and records its `RoomTagType` unique ID plus source tag ID. Existing chronology, distinct-type Recent 5, favorites, view-duplication/Undo/group/bulk-operation exclusions and atomic JSON storage remain. Type changes selected within native placement are naturally tracked when an actual tag is committed.

`CommandRunner` dispatches RoomTagType **before** the model-family workflow. `RoomTagSimilarService` checks native room-tagging availability, calls `CanPlaceElementType`, and queues the exact type using `PostRequestForElementTypePlacement`. Where direct queueing is unsupported, it uses native Create Similar only from an exact-type tag in the current view. Failure restores selection; it never substitutes the default tag type or starts a custom pick/create loop. No application transaction, model-family capture session or height correction surrounds this queued native operation.

Native Revit handles local/linked room selection, view restrictions, leaders, orientation and Undo. Linked rooms must be available to native tagging; overlapping local rooms take native precedence. The tracker listens to tags created in the host document, not edits within a linked document. Height display/settings/write paths explicitly exclude Room Tags. XAML layouts, ribbon IDs and shortcut registration are unchanged. Hash comparison confirms adding Room Tags did not alter the face resolver, classifier, correction service, placement service or face diagnostics.

## Verification and sources

See `Verification/README.md` and logs. Results are 32 geometry/host fixtures, 22 Room Tag/history checks and 18 diagnostics checks passing; C# API compile checks pass for 2024–2027. A fixture is not the Revit geometry kernel. No live Revit placement/Undo test or complete Windows WPF production build was possible in this environment. This ZIP supplies the existing Windows build/install workflow; it does not pass validation-stub DLLs off as production DLLs.

Primary API references used in the investigation:

- [Autodesk GeometryInstance: transforms and top-level solids](https://help.autodesk.com/cloudhelp/2026/ENU/Revit-API-MainReference/files/html/fe25b14f-5866-ca0f-a660-c157484c3a56.htm).
- [The Building Coder: picked instance face geometry in local versus world coordinates](https://jeremytammik.github.io/tbc/a/1573_family_inst_lcs_wcs.html), including a reproduced API case.
- [Autodesk PostRequestForElementTypePlacement: queued native UI and transactions](https://help.autodesk.com/cloudhelp/2026/ENU/Revit-API-MainReference/files/html/f9bf4ed3-0354-6bc1-6db3-e34fcbace950.htm).
- [Autodesk Tag a Room: native controls and overlapping linked-room behavior](https://help.autodesk.com/cloudhelp/2023/ENU/Revit-ArchDesign/files/GUID-5FBF2AA2-B811-4443-9DBB-9DE62191F332.htm).

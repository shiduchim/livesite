@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_Payload\Collect-Diagnostics.ps1"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%

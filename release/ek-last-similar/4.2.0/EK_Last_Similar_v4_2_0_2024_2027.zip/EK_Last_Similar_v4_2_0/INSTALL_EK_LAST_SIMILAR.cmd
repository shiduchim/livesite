@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_Payload\INSTALL_EK_LAST_SIMILAR_ALL_2024_2027.cmd"
exit /b %errorlevel%

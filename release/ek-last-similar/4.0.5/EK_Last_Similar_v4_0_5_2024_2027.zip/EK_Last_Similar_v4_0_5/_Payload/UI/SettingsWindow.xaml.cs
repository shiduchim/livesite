using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using EK.LastSimilar.Services;

namespace EK.LastSimilar.UI
{
    /// <summary>
    /// Settings edits are staged in this window. Nothing is written merely by browsing,
    /// changing a field, removing a row, moving a row, or changing thumbnail options.
    /// Save commits the staged changes and closes. Close discards every staged change.
    /// Place commits the staged changes first, then starts placement.
    /// </summary>
    public partial class SettingsWindow : Window
    {
        private const double MaxFixedHeightMm = 20000;

        private readonly Autodesk.Revit.DB.Document _doc;
        private List<RecentResolvedItem> _items = new List<RecentResolvedItem>();

        private readonly HashSet<string> _dirtyUids = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _removedUids = new HashSet<string>(StringComparer.Ordinal);
        private readonly Dictionary<string, string> _pendingHeightText =
            new Dictionary<string, string>(StringComparer.Ordinal);

        private bool _loadingThumbnailOptions;
        private bool _loadingControls;

        public StateSession Session { get; private set; }
        public Autodesk.Revit.DB.FamilySymbol SymbolToPlace { get; private set; }
        public RecentTypeState EntryToPlace { get; private set; }

        public SettingsWindow(IntPtr revitMainWindow, Autodesk.Revit.DB.Document doc)
        {
            InitializeComponent();

            _doc = doc;

            // Transparent fallback prevents WPF from falling back to Revit's process icon.
            // Win32 cleanup below also removes the icon slot from the native caption.
            Icon = CreateTransparentWindowIcon();

            // Revit's process icon otherwise appears in the WPF title bar.
            // Attach before setting the owner so we cannot miss SourceInitialized.
            SourceInitialized += (s2, e2) => NativeMethods.HideWindowTitleIcon(this);

            if (revitMainWindow != IntPtr.Zero)
                new WindowInteropHelper(this).Owner = revitMainWindow;

            try { HeaderTitle.Text = "Recent types in " + doc.Title; }
            catch { }

            Session = StateStore.Open(_doc);
            LoadThumbnailOptions();
            DiagnosticsCheck.IsChecked = StateStore.GetDiagnosticsEnabled();
            GlobalHeightCorrectionCheck.IsChecked = StateStore.GetHeightCorrectionsEnabled();

            RecentList.PreviewKeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    e.Handled = true;
                    PlaceCurrent();
                }
            };

            RefreshLocalList(null);
        }

        private static ImageSource CreateTransparentWindowIcon()
        {
            byte[] pixels = new byte[4];
            BitmapSource bmp = BitmapSource.Create(
                1, 1, 96, 96, PixelFormats.Bgra32, null, pixels, 4);
            bmp.Freeze();
            return bmp;
        }

        private RecentResolvedItem Current =>
            RecentList.SelectedItem as RecentResolvedItem;


        private void LoadThumbnailOptions()
        {
            _loadingThumbnailOptions = true;
            try
            {
                StateStore.GetRecentFiveVisualOptions(out bool useThumbnails, out int thumbnailSize);
                UseThumbnailsCheck.IsChecked = useThumbnails;

                foreach (object item in ThumbnailSizeBox.Items)
                {
                    ComboBoxItem combo = item as ComboBoxItem;
                    if (combo != null &&
                        string.Equals(
                            combo.Content?.ToString(),
                            thumbnailSize.ToString(CultureInfo.InvariantCulture),
                            StringComparison.Ordinal))
                    {
                        ThumbnailSizeBox.SelectedItem = combo;
                        break;
                    }
                }

                if (ThumbnailSizeBox.SelectedItem == null)
                    ThumbnailSizeBox.SelectedIndex = 1;

                ThumbnailSizeBox.IsEnabled = useThumbnails;
            }
            finally
            {
                _loadingThumbnailOptions = false;
            }
        }

        // Shared by the thumbnail check box and the size box
        // (SelectionChangedEventArgs is a RoutedEventArgs).
        private void ThumbnailVisual_Changed(object sender, RoutedEventArgs e)
        {
            if (_loadingThumbnailOptions)
                return;

            ThumbnailSizeBox.IsEnabled = UseThumbnailsCheck.IsChecked == true;
            RefreshLocalList(Current?.State?.SymbolUniqueId);
        }


        private void GetThumbnailUiValues(out bool use, out int size)
        {
            use = UseThumbnailsCheck.IsChecked == true;
            size = 24;

            ComboBoxItem selected = ThumbnailSizeBox.SelectedItem as ComboBoxItem;
            if (selected != null)
                int.TryParse(
                    selected.Content?.ToString(),
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out size);

            size = StateStore.NormalizeFamilyThumbnailSize(size);
        }

        private void RefreshLocalList(string selectUid)
        {
            _items = StateStore.GetSettingsOrder(Session.Doc, _doc);

            GetThumbnailUiValues(out bool useThumbnails, out int thumbnailSize);
            foreach (RecentResolvedItem item in _items)
            {
                if (item == null)
                    continue;

                item.VisualSize = useThumbnails ? thumbnailSize : 18;
                item.Icon = useThumbnails
                    ? PreviewImageFactory.GetOrFallback(item.Symbol, item.State, thumbnailSize, false)
                    : CategoryIconFactory.Create(item.State, false);
            }

            RecentList.ItemsSource = null;
            RecentList.ItemsSource = _items;

            int index = 0;
            if (!string.IsNullOrEmpty(selectUid))
            {
                int found = _items.FindIndex(x =>
                    string.Equals(x.State?.SymbolUniqueId, selectUid, StringComparison.Ordinal));
                if (found >= 0)
                    index = found;
            }

            if (_items.Count > 0)
            {
                RecentList.SelectedIndex = Math.Min(index, _items.Count - 1);
                RecentList.ScrollIntoView(_items[RecentList.SelectedIndex]);
            }
            else
            {
                LoadCurrentControls();
            }
        }

        private void RecentList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!_loadingControls && e.RemovedItems != null && e.RemovedItems.Count > 0)
            {
                RecentResolvedItem previous = e.RemovedItems[0] as RecentResolvedItem;
                if (previous != null)
                    CaptureControlsInto(previous, false);
            }

            LoadCurrentControls();
        }

        private void RecentList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DependencyObject source = e.OriginalSource as DependencyObject;
            if (ItemsControl.ContainerFromElement(RecentList, source) is ListBoxItem)
                PlaceCurrent();
        }

        private void LoadCurrentControls()
        {
            _loadingControls = true;
            try
            {
                RecentResolvedItem current = Current;
                bool has = current != null;

                FavoriteCheck.IsEnabled = has;
                bool canAdjust = has && !current.IsRoomTag && !current.IsLine;
                TypeHeightCorrectionCheck.IsEnabled = canAdjust;
                LastHeightRadio.IsEnabled = canAdjust;
                FixedHeightRadio.IsEnabled = canAdjust;

                if (!has)
                {
                    SelectedTitle.Text = "No type selected";
                    SelectedSubtitle.Text = "";
                    LearnedText.Text = "";
                    HeightBox.Text = "";
                    FavoriteCheck.IsChecked = false;
                    TypeHeightCorrectionCheck.IsChecked = false;
                    LastHeightRadio.IsChecked = false;
                    FixedHeightRadio.IsChecked = false;
                    return;
                }

                RecentTypeState state = current.State;
                SelectedTitle.Text = current.PrimaryText;
                SelectedSubtitle.Text = current.SecondaryText;

                if (current.IsRoomTag || current.IsLine)
                {
                    FavoriteCheck.IsChecked = state.Favorite;
                    TypeHeightCorrectionCheck.IsChecked = false;
                    LastHeightRadio.IsChecked = false;
                    FixedHeightRadio.IsChecked = false;
                    LearnedText.Text = "Not applicable to Room Tags or lines";
                    HeightBox.Text = "";
                    return;
                }
                TypeHeightCorrectionCheck.IsChecked = state.HeightCorrectionEnabled != false;
                bool fixedMode = HeightModes.IsStandard(state.HeightMode);

                FixedHeightRadio.IsChecked = fixedMode;
                LastHeightRadio.IsChecked = !fixedMode;
                FavoriteCheck.IsChecked = state.Favorite;

                LearnedText.Text = state.LastWallHeightFeet.HasValue
                    ? (state.LastWallHeightFeet.Value * 30.48)
                        .ToString("0.#", CultureInfo.InvariantCulture) + " cm"
                    : "not learned yet: the next placement keeps its own height";

                string uid = state.SymbolUniqueId ?? "";
                if (_pendingHeightText.TryGetValue(uid, out string pending))
                {
                    HeightBox.Text = pending;
                }
                else
                {
                    HeightBox.Text = state.StandardHeightMm.HasValue
                        ? (state.StandardHeightMm.Value / 10.0).ToString("0.#", CultureInfo.InvariantCulture)
                        : "";
                }
            }
            finally
            {
                _loadingControls = false;
            }
        }

        private static bool TryParseCm(string text, out double cm)
        {
            text = (text ?? "").Trim();
            return double.TryParse(
                       text,
                       NumberStyles.Float,
                       CultureInfo.InvariantCulture,
                       out cm) ||
                   double.TryParse(
                       text,
                       NumberStyles.Float,
                       CultureInfo.CurrentCulture,
                       out cm);
        }

        private bool CaptureControlsInto(RecentResolvedItem item, bool validate)
        {
            if (item == null || item.State == null)
                return true;

            RecentTypeState state = item.State;
            string uid = state.SymbolUniqueId ?? "";

            state.Favorite = FavoriteCheck.IsChecked == true;
            if (item.IsRoomTag || item.IsLine)
            {
                _dirtyUids.Add(uid);
                return true;
            }

            state.HeightCorrectionEnabled = TypeHeightCorrectionCheck.IsChecked == true;

            // The height choice is kept while correction is off for this type, so it
            // applies again when correction is switched back on (no forced reset to Last).
            // It is only enforced (validated) while correction is on.
            bool enforce = validate && state.HeightCorrectionEnabled != false;

            if (FixedHeightRadio.IsChecked == true)
            {
                state.HeightMode = HeightModes.Standard;
                _pendingHeightText[uid] = HeightBox.Text ?? "";

                if (!TryParseCm(HeightBox.Text, out double cm) ||
                    cm <= 0 ||
                    cm > (MaxFixedHeightMm / 10.0))
                {
                    if (enforce)
                    {
                        MessageBox.Show(
                            this,
                            "Enter the fixed wall height in centimeters (more than 0, at most 2000).",
                            "EK Last Similar",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        HeightBox.Focus();
                        HeightBox.SelectAll();
                        return false;
                    }
                }
                else
                {
                    // Persist in mm for backward compatibility with all existing state files.
                    state.StandardHeightMm = cm * 10.0;
                }
            }
            else
            {
                state.HeightMode = HeightModes.Last;
            }

            _dirtyUids.Add(uid);
            return true;
        }

        private bool ValidateAllPendingHeights()
        {
            foreach (RecentResolvedItem item in _items)
            {
                if (item?.State == null || item.IsRoomTag || item.IsLine ||
                    item.State.HeightCorrectionEnabled == false || !HeightModes.IsStandard(item.State.HeightMode))
                    continue;

                string uid = item.State.SymbolUniqueId ?? "";
                if (_pendingHeightText.TryGetValue(uid, out string pending))
                {
                    if (!TryParseCm(pending, out double cm) ||
                        cm <= 0 ||
                        cm > (MaxFixedHeightMm / 10.0))
                    {
                        RecentList.SelectedItem = item;
                        RecentList.ScrollIntoView(item);
                        LoadCurrentControls();

                        MessageBox.Show(
                            this,
                            "Enter the fixed wall height in centimeters (more than 0, at most 2000).",
                            "EK Last Similar",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        HeightBox.Focus();
                        HeightBox.SelectAll();
                        return false;
                    }

                    // Persist in mm for backward compatibility.
                    item.State.StandardHeightMm = cm * 10.0;
                }
            }

            return true;
        }

        private bool CommitStagedChanges()
        {
            if (!CaptureControlsInto(Current, true))
                return false;

            if (!ValidateAllPendingHeights())
                return false;

            GetThumbnailUiValues(out bool useThumbnails, out int thumbnailSize);

            bool ok = true;

            // Global UI preferences are intentionally written only when Save/Place is pressed.
            ok = StateStore.SaveRecentFiveVisualOptions(useThumbnails, thumbnailSize) && ok;
            ok = StateStore.SaveHeightCorrectionsEnabled(GlobalHeightCorrectionCheck.IsChecked == true) && ok;

            bool diagnosticsEnabled = DiagnosticsCheck.IsChecked == true;
            bool diagnosticsSaved = StateStore.SaveDiagnosticsEnabled(diagnosticsEnabled);
            ok = diagnosticsSaved && ok;

            // Apply the runtime switch only after the preference was safely saved.
            if (diagnosticsSaved)
                RunLog.SetEnabled(diagnosticsEnabled);

            // Apply removals first.
            foreach (string uid in _removedUids)
                ok = StateStore.RemoveEntry(Session, uid) && ok;

            // Save only rows the user actually edited/reordered and that were not removed.
            foreach (RecentResolvedItem item in _items)
            {
                if (item?.State == null)
                    continue;

                string uid = item.State.SymbolUniqueId ?? "";
                if (!_dirtyUids.Contains(uid) || _removedUids.Contains(uid))
                    continue;

                ok = StateStore.SaveTypeSettings(
                         Session,
                         item.State,
                         item.State.HeightMode,
                         item.State.StandardHeightMm,
                         item.State.Favorite,
                         item.State.HeightCorrectionEnabled != false) && ok;
            }

            if (!ok)
            {
                MessageBox.Show(
                    this,
                    "One or more settings could not be saved. The window will stay open.",
                    "EK Last Similar",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (CommitStagedChanges())
                DialogResult = false;
        }

        private void PlaceButton_Click(object sender, RoutedEventArgs e)
        {
            PlaceCurrent();
        }

        private void PlaceCurrent()
        {
            RecentResolvedItem current = Current;
            if (current == null)
                return;

            if (!CommitStagedChanges())
                return;

            SymbolToPlace = current.Symbol;
            EntryToPlace = current.State;
            DialogResult = true;
        }


        private void FavoriteCheck_Changed(object sender, RoutedEventArgs e)
        {
            if (_loadingControls)
                return;

            RecentResolvedItem current = Current;
            if (current?.State == null)
                return;

            // Favorite is a Settings-only visual/order preference.
            // It never changes Last or true Recent 5 placement chronology.
            current.State.Favorite = FavoriteCheck.IsChecked == true;
            _dirtyUids.Add(current.State.SymbolUniqueId ?? "");

            // Re-sort immediately so the user can see what Favorite does.
            RefreshLocalList(current.State.SymbolUniqueId);
        }

        private void MoveToBottomButton_Click(object sender, RoutedEventArgs e)
        {
            RecentResolvedItem current = Current;
            if (current?.State == null)
                return;

            if (!CaptureControlsInto(current, false))
                return;

            current.State.SettingsBottom = true;

            long maxBottomStamp = 0;
            foreach (RecentResolvedItem item in _items)
            {
                if (item?.State == null)
                    continue;
                if (item.State.SettingsBottomOrderTicks > maxBottomStamp)
                    maxBottomStamp = item.State.SettingsBottomOrderTicks;
            }

            current.State.SettingsBottomOrderTicks =
                Math.Max(DateTime.UtcNow.Ticks, maxBottomStamp + 1);

            _dirtyUids.Add(current.State.SymbolUniqueId ?? "");
            RefreshLocalList(current.State.SymbolUniqueId);
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            RecentResolvedItem current = Current;
            if (current?.State == null)
                return;

            string uid = current.State.SymbolUniqueId ?? "";
            _removedUids.Add(uid);
            _dirtyUids.Remove(uid);
            _pendingHeightText.Remove(uid);

            Session.Doc.History.RemoveAll(x =>
                string.Equals(x?.SymbolUniqueId, uid, StringComparison.Ordinal));

            if (string.Equals(Session.Doc.LastSymbolUniqueId, uid, StringComparison.Ordinal))
            {
                RecentTypeState newest = null;
                foreach (RecentTypeState e2 in Session.Doc.History)
                {
                    if (e2 == null)
                        continue;
                    if (newest == null || e2.LastUsedUtcTicks > newest.LastUsedUtcTicks)
                        newest = e2;
                }

                Session.Doc.LastSymbolUniqueId = newest?.SymbolUniqueId;
            }

            RefreshLocalList(null);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Nothing in this window is written until Save or Place, so Close is a true Cancel.
            DialogResult = false;
        }
    }
}

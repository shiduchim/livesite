using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Autodesk.Revit.DB;
using EK.LastSimilar.Services;

namespace EK.LastSimilar.UI
{
    /// <summary>
    /// Gets the same Revit type preview image used by native type/component UIs when the
    /// API supplies one. Reflection keeps this source independent of System.Drawing at
    /// compile time across Revit 2024 (.NET Framework) and modern Revit (.NET 8/10).
    /// Returned WPF images are frozen and cached. Failures simply fall back to category icons.
    /// </summary>
    internal static class PreviewImageFactory
    {
        private const int MaxCacheItems = 100;
        // Ask Revit for a comfortably larger source image, then let WPF scale it down
        // to the user's chosen display size. This keeps small thumbnails much sharper,
        // especially on 125-200% DPI displays.
        private const int PreviewSourcePixels = 128;
        private static readonly Dictionary<string, ImageSource> Cache = new Dictionary<string, ImageSource>();
        private static readonly Queue<string> CacheOrder = new Queue<string>();
        private static readonly object Sync = new object();

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        public static ImageSource GetOrFallback(FamilySymbol symbol, RecentTypeState state, int size, bool dark)
        {
            // 'size' is intentionally only the DISPLAY size (applied by the caller's Image
            // control). The cached source is always requested from Revit at PreviewSourcePixels.
            ImageSource preview = TryGet(symbol);
            return preview ?? CategoryIconFactory.Create(state, dark);
        }

        private static ImageSource TryGet(FamilySymbol symbol)
        {
            if (symbol == null || !symbol.IsValidObject)
                return null;

            string uid;
            try { uid = symbol.UniqueId ?? ""; }
            catch { return null; }
            if (string.IsNullOrWhiteSpace(uid))
                return null;

            string key = uid + "|preview:" + PreviewSourcePixels;
            lock (Sync)
            {
                if (Cache.TryGetValue(key, out ImageSource cached))
                    return cached;
            }

            object bitmap = null;
            IntPtr hBitmap = IntPtr.Zero;
            try
            {
                MethodInfo previewMethod = null;
                foreach (MethodInfo m in symbol.GetType().GetMethods(BindingFlags.Public | BindingFlags.Instance))
                {
                    if (m.Name == "GetPreviewImage" && m.GetParameters().Length == 1)
                    {
                        previewMethod = m;
                        break;
                    }
                }
                if (previewMethod == null)
                    return null;

                ParameterInfo parameter = previewMethod.GetParameters()[0];
                Type sizeType = parameter.ParameterType;
                object sizeArg = Activator.CreateInstance(sizeType, new object[] { PreviewSourcePixels, PreviewSourcePixels });
                bitmap = previewMethod.Invoke(symbol, new object[] { sizeArg });
                if (bitmap == null)
                    return null;

                MethodInfo getHbitmap = bitmap.GetType().GetMethod("GetHbitmap", Type.EmptyTypes);
                if (getHbitmap == null)
                    return null;

                object handleValue = getHbitmap.Invoke(bitmap, null);
                if (!(handleValue is IntPtr))
                    return null;
                hBitmap = (IntPtr)handleValue;
                if (hBitmap == IntPtr.Zero)
                    return null;

                BitmapSource source = Imaging.CreateBitmapSourceFromHBitmap(
                    hBitmap,
                    IntPtr.Zero,
                    Int32Rect.Empty,
                    // Preserve the pixels Revit actually returned. WPF will perform
                    // the final high-quality downscale in the Recent 5 Image control.
                    BitmapSizeOptions.FromEmptyOptions());
                source.Freeze();

                lock (Sync)
                {
                    if (!Cache.ContainsKey(key))
                    {
                        Cache[key] = source;
                        CacheOrder.Enqueue(key);
                        while (CacheOrder.Count > MaxCacheItems)
                        {
                            string old = CacheOrder.Dequeue();
                            Cache.Remove(old);
                        }
                    }
                }
                return source;
            }
            catch (Exception ex)
            {
                RunLog.Add("Type preview unavailable: " + ex.Message);
                return null;
            }
            finally
            {
                if (hBitmap != IntPtr.Zero)
                {
                    try { DeleteObject(hBitmap); } catch { }
                }
                if (bitmap is IDisposable disposable)
                {
                    try { disposable.Dispose(); } catch { }
                }
            }
        }
    }
}

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EK Last Similar")]
[assembly: AssemblyDescription("Fast last/recent family placement for Autodesk Revit.")]
[assembly: AssemblyCompany("EK")]
[assembly: AssemblyProduct("EK Last Similar")]
[assembly: AssemblyCopyright("© 2026 EK")]
[assembly: ComVisible(false)]
[assembly: Guid("9b1ff0e8-a1b8-4f7b-9f74-f10f936a2420")]
[assembly: AssemblyVersion("4.0.5.0")]
[assembly: AssemblyFileVersion("4.0.5.0")]

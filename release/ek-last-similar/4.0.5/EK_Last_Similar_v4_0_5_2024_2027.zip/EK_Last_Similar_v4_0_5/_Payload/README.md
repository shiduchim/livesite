Current release: **4.0.5**. Read `../README_FIRST.md` for the reorganized Settings window, new ribbon icons and bug fixes. `../DIAGNOSIS_AND_CHANGES.md` and the existing Verification results document earlier releases. The following notes are retained from earlier releases.

# EK Last Similar 4.0.1 (Revit 2024-2027)

Fast placement of the family type you placed last, for electrical/MEP work.

## Use

**Last Similar** places the family type you actually placed last in this project
(through Revit's own tools or through this add-in). No selection needed.
Selecting something, opening Settings or cancelling never changes Last.

**Recent 5** opens a small palette beside the mouse with your last
5 placed distinct types, in placement order (favorites never reorder it).
It is a separate Revit command, so it can have its own Revit keyboard shortcut.
Click a row, press **1-5**, or use **Up/Down + Enter**. **Esc** or a click anywhere
else closes it. It follows Revit's light/dark UI theme where Revit exposes it.

**Settings** lists the remembered types (favorites first) with the mounting height
each one gets: *Last placed height* (learned) or *Fixed height* in mm.
It also controls real Revit type thumbnails and thumbnail size. **Move to bottom** only
changes Settings order; it never changes true placement chronology or Recent 5.
**Save** commits the staged changes and closes. **Close** discards unsaved changes.

## What the add-in changes in the model

Only instances of the exact requested type that you place during a Last Similar run.

| Host | Rule |
|---|---|
| Wall (native, or a wall in a loaded link) | Schedule Level = highest level under the instance (`Level.ProjectElevation`); Elevation from Level = fixed height, else learned height, else the placed height is kept and learned. If several levels share that elevation: the instance's current level, else the level of the view you placed in, else a Building Story level, else the lowest element id. The rotation you chose is never written and never blocks a correction (4.0.0). |
| Verified vertical face (native or linked curtain panel, Generic Model, column, mullion, etc.) | Same saved/learned height rule as walls. Before committing, the app verifies that the same host face is retained, the final point is on that face, XY position is unchanged and the desired Z was reached. Failed checks cause rollback. Unverifiable faces are skipped with a diagnostic reason. |
| Ceiling (native or linked) | Never changed. |
| Unhosted / level-based Electrical Equipment | Only if its Level is not already the level under it: level changed while the exact position is preserved (verified). |
| Detail items, group members, floors/roofs/horizontal faces, unresolved hosts/links | Never changed. Since 4.0.0 this is reported (dialog) when the type has a wall height set, instead of being skipped silently. |
| Instances of ANOTHER type picked in the Type Selector during the run | Never changed. Wall and verified vertical-face ones are reported, because they look exactly like "the correction did not run". |

Every correction is its own transaction, verified before commit (level read back, final
height, no sideways movement; on newly supported vertical hosts, same physical host face) and rolled back on any doubt. All corrections are one undo
step: *EK Last Similar - Finalize Placement*.

If anything at all was committed during the placement (including instances of another type
you picked in the Properties palette), the command returns Succeeded, so Revit never rolls
your placements back.

## Listeners

* **Placement listener** (temporary, read-only): attached right before
  `PromptForFamilyInstancePlacement`, detached in `finally` before any correction.
* **Last-placed tracker** (Revit session, read-only): records the type of a single fresh
  placement into the history file. It never opens a transaction or edits anything.
  Ignored: Undo/Redo, family documents, links, Synchronize/Reload Latest, commits that add
  a view, commits that add 2+ instances (copy/paste/array), nested/group/in-place
  instances, conduit/cable tray/duct/pipe fittings, curtain panels/mullions, title blocks.

## Files

* History/settings: `%APPDATA%\EK\LastSimilar\state-csharp.json` (+ `.bak` = previous good copy)
  per project, max 30 types per project, max 60 projects.
* Diagnostics: Settings > Troubleshooting. When enabled, `%APPDATA%\EK\LastSimilar\last-run.log` is a rolling forensic log. It is OFF by default.
  (about the last 1 MB, newest run at the BOTTOM). Every placement run records each
  document event, and for every new instance: id, UniqueId, family/type/category, initial
  Z, Schedule Level, Elevation from Level, rotation, host (native/linked + linked
  category), target level and why, height mode and target, whether a correction was
  attempted, the exact skip reason, transaction committed/rolled back, and the final
  state. Placements made outside EK are logged as `[background] Tracker:` lines.
  Opening Settings or Recent 5 no longer erases the previous run.
* Install log: `_Payload\INSTALL_EK_LAST_SIMILAR.log`

## Build / install

Double-click `INSTALL_EK_LAST_SIMILAR.cmd` with Revit closed. See `ALL_VERSION_BUILD_NOTE.md`.

## v4.0.1 host correction update

- New: only **verified vertical mounting faces** outside the normal wall category
  (especially curtain panels, including loaded architectural Revit links) are eligible
  for configured mounting height corrections and learning last-placed height.
- Unchanged: ceiling, floor, roof, stairs, ramps, foundations and nonvertical
  surfaces are not height-corrected; level/work-plane/unhosted behavior stays as before.
- Conservative: if Revit cannot resolve the exact hosting face, or it is nonvertical, no longer near the corrected point, or changes during correction,
  the element is left at its placed location (transaction rolled back).
- Level selection still follows v4.0.0: highest project level at or below the clicked
  elevation; crowded multi-level models can still require clicking near the right level.
- Does not intercept Revit's own Create Similar, copy, or paste commands.
- The current installer compiles for each installed Revit version 2024-2027
  using that Revit version's local API assemblies. Test in Revit before broad deployment.

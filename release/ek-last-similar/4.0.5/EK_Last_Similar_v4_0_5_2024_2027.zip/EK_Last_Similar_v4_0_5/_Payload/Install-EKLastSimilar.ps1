# EK Last Similar - build + install for Revit 2024-2027 (per user, no admin rights needed).
# Started by INSTALL_EK_LAST_SIMILAR.cmd. Keep this file ASCII-only: Windows PowerShell 5.1
# reads files without a BOM as ANSI.
#
# What it does:
#   1. refuses to run while any Revit is open
#   2. finds which Revit versions (2024-2027) are installed and validates their API DLLs
#   3. builds ONLY those versions (dotnet build, Release R24/R25/R26/R27)
#   4. stages the new bundle OUTSIDE ApplicationPlugins and checks it
#   5. swaps it in with a rename; if anything fails, the previous install stays in place
#   6. only then removes older direct installs of EKLastSimilar (no other EK tool is touched)
# History and settings in %APPDATA%\EK\LastSimilar are never touched.

$ErrorActionPreference = 'Continue'

$AppVersion = '4.0.5.0'
$Here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project    = Join-Path $Here 'EKLastSimilar.csproj'
$Template   = Join-Path $Here 'bundle\EKLastSimilar.bundle'
$BuildRoot  = Join-Path $Here 'build'
$ObjRoot    = Join-Path $Here 'obj'
$LogFile    = Join-Path $Here 'INSTALL_EK_LAST_SIMILAR.log'

$ProgramFiles64 = $env:ProgramW6432
if (-not $ProgramFiles64) { $ProgramFiles64 = $env:ProgramFiles }

$AutodeskRoaming = Join-Path $env:APPDATA 'Autodesk'
$PluginsRoot     = Join-Path $AutodeskRoaming 'ApplicationPlugins'
$Dest            = Join-Path $PluginsRoot 'EKLastSimilar.bundle'
# Staging and the previous copy live OUTSIDE ApplicationPlugins (Revit never scans them)
# but on the same drive, so the final swap is an instant rename.
$Staging         = Join-Path $AutodeskRoaming 'EKLastSimilar.install-staging'
$Previous        = Join-Path $AutodeskRoaming 'EKLastSimilar.install-previous'

$Versions = @(
    @{ Year = 2024; Config = 'Release R24'; Sdk = 6;  Runtime = '.NET Framework 4.8' },
    @{ Year = 2025; Config = 'Release R25'; Sdk = 8;  Runtime = '.NET 8' },
    @{ Year = 2026; Config = 'Release R26'; Sdk = 8;  Runtime = '.NET 8' },
    @{ Year = 2027; Config = 'Release R27'; Sdk = 10; Runtime = '.NET 10' }
)

function Write-Log([string]$Message) {
    try { Add-Content -LiteralPath $LogFile -Value $Message -Encoding UTF8 } catch { }
}

function Say([string]$Message, [string]$Color = 'Gray') {
    Write-Host $Message -ForegroundColor $Color
    Write-Log $Message
}

function Stop-Install([string]$Message, [bool]$Changed = $false) {
    Say ''
    Say $Message 'Red'
    if (-not $Changed) { Say 'Nothing was changed. Your previous EK Last Similar install (if any) is untouched.' 'Yellow' }
    Say "Log: $LogFile"
    exit 1
}

function Remove-Dir([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
    }
}

function Find-RevitDir([int]$Year) {
    $candidates = New-Object System.Collections.Generic.List[string]

    $override = [Environment]::GetEnvironmentVariable("REVIT$($Year)_DIR")
    if ($override) { $candidates.Add($override) }

    $candidates.Add((Join-Path $ProgramFiles64 "Autodesk\Revit $Year"))

    try {
        $key = "HKLM:\SOFTWARE\Autodesk\Revit\$Year"
        if (Test-Path $key) {
            foreach ($sub in (Get-ChildItem $key -ErrorAction SilentlyContinue)) {
                $loc = (Get-ItemProperty -LiteralPath $sub.PSPath -ErrorAction SilentlyContinue).InstallationLocation
                if ($loc) { $candidates.Add([string]$loc) }
            }
        }
    } catch { }

    foreach ($c in $candidates) {
        if (-not $c) { continue }
        $dir = $c.Trim().TrimEnd('\')
        if ((Test-Path -LiteralPath (Join-Path $dir 'RevitAPI.dll')) -and
            (Test-Path -LiteralPath (Join-Path $dir 'RevitAPIUI.dll'))) {
            return $dir
        }
    }

    return $null
}

function Find-Dotnet {
    $cmd = Get-Command 'dotnet.exe' -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $p = Join-Path $ProgramFiles64 'dotnet\dotnet.exe'
    if (Test-Path -LiteralPath $p) { return $p }

    return $null
}

function Show-BuildErrors {
    $lines = Get-Content -LiteralPath $LogFile -ErrorAction SilentlyContinue
    if (-not $lines) { return }

    $errors = $lines |
        Where-Object { $_ -match '(?i)(\berror\s+(CS|MSB|NETSDK|NU|XC|MC)\d+|:\s*error\s*:)' } |
        Select-Object -Unique |
        Select-Object -Last 25

    Write-Host ''
    Write-Host '---------------- build errors ----------------' -ForegroundColor Yellow
    if ($errors) {
        foreach ($e in $errors) { Write-Host $e -ForegroundColor Red }
    } else {
        foreach ($l in ($lines | Select-Object -Last 40)) { Write-Host $l }
    }
    Write-Host '----------------------------------------------' -ForegroundColor Yellow
}

# ----------------------------------------------------------------------------
Set-Content -LiteralPath $LogFile -Value "EK Last Similar $AppVersion - install log - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -Encoding UTF8

Say ''
Say '=================================================='
Say "  EK Last Similar $AppVersion - Revit 2024-2027"
Say '=================================================='
Say ''

# 1. Revit must be closed (DLLs are locked while it runs).
if (Get-Process -Name 'Revit' -ErrorAction SilentlyContinue) {
    Stop-Install 'Revit is running. Close ALL Revit sessions, then run the installer again.'
}

# 2. Installed Revit versions.
$targets = @()
foreach ($v in $Versions) {
    $dir = Find-RevitDir $v.Year
    if ($dir) {
        $v['Dir'] = $dir
        $targets += $v
        Say ("Revit {0}: found  ({1})" -f $v.Year, $dir) 'Green'
    } else {
        Say ("Revit {0}: not installed - skipped" -f $v.Year) 'DarkGray'
    }
}

if ($targets.Count -eq 0) {
    Stop-Install ('No Revit 2024-2027 installation with RevitAPI.dll / RevitAPIUI.dll was found.' +
        [Environment]::NewLine + 'If Revit is installed in a custom folder, set REVIT2024_DIR (or 2025/2026/2027) first.')
}

# 3. Build tool.
$dotnet = Find-Dotnet
if (-not $dotnet) {
    Stop-Install 'The .NET SDK was not found. Install the .NET SDK (x64) from https://dotnet.microsoft.com and run the installer again.'
}

$sdkMajors = @()
foreach ($line in (& $dotnet --list-sdks 2>&1)) {
    if ([string]$line -match '^\s*(\d+)\.') { $sdkMajors += [int]$Matches[1] }
}
$maxSdk = 0
if ($sdkMajors.Count -gt 0) { $maxSdk = ($sdkMajors | Measure-Object -Maximum).Maximum }
Say ''
Say ("dotnet: {0}  (newest SDK major: {1})" -f $dotnet, $maxSdk)

$missingSdk = @($targets | Where-Object { $maxSdk -lt $_.Sdk })
if ($missingSdk.Count -gt 0) {
    # (Measure-Object -Property does not read hashtable keys in Windows PowerShell 5.1.)
    $need = ($missingSdk | ForEach-Object { $_.Sdk } | Measure-Object -Maximum).Maximum
    $years = ($missingSdk | ForEach-Object { $_.Year }) -join ', '
    Stop-Install ("Revit $years needs the .NET $need SDK (or newer) to build. Install it from https://dotnet.microsoft.com and run the installer again.")
}

# 4. Build every installed version. Any failure stops BEFORE anything is installed.
try {
    Remove-Dir $BuildRoot
    Remove-Dir $ObjRoot
} catch {
    Stop-Install "Could not clean old build folders: $($_.Exception.Message)"
}

$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'

foreach ($v in $targets) {
    Say ''
    Say ("Building for Revit {0} ({1}) ..." -f $v.Year, $v.Runtime) 'Cyan'

    $buildArgs = @(
        'build', $Project,
        '-c', $v.Config,
        '-p:Platform=x64',
        ("-p:RevitApiPath_{0}={1}" -f $v.Year, $v.Dir),
        '-nologo', '-v:minimal'
    )

    Write-Log ''
    Write-Log ("===== dotnet " + ($buildArgs -join ' ') + " =====")
    # Keep the full compiler output in the logfile without flooding CMD with
    # C# errors/warnings/source paths. On failure, Show-BuildErrors prints a concise
    # actionable excerpt. Each Revit version still gets an explicit progress line.
    & $dotnet @buildArgs 2>&1 | ForEach-Object {
        $buildLine = [string]$_
        Write-Log $buildLine
    }
    $code = $LASTEXITCODE
    Write-Log ("dotnet exited with code {0} at {1}" -f $code, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))

    $dll = Join-Path $BuildRoot ("{0}\EKLastSimilar.dll" -f $v.Year)
    if ($code -ne 0 -or -not (Test-Path -LiteralPath $dll)) {
        Show-BuildErrors
        Stop-Install ("Build FAILED for Revit {0}." -f $v.Year)
    }

    Say ("Revit {0}: build OK" -f $v.Year) 'Green'
}

# 5. Stage the new bundle and verify it.
try {
    Remove-Dir $Staging
    New-Item -ItemType Directory -Path $Staging -Force -ErrorAction Stop | Out-Null

    $components = ''
    foreach ($v in $targets) {
        $y = $v.Year
        $dstDir = Join-Path $Staging "Contents\$y"
        New-Item -ItemType Directory -Path $dstDir -Force -ErrorAction Stop | Out-Null

        Copy-Item -LiteralPath (Join-Path $Template "Contents\$y\EKLastSimilar.addin") -Destination $dstDir -Force -ErrorAction Stop
        Copy-Item -LiteralPath (Join-Path $BuildRoot "$y\EKLastSimilar.dll") -Destination $dstDir -Force -ErrorAction Stop

        $components += "  <Components Description=`"Revit $y`">`r`n"
        $components += "    <RuntimeRequirements OS=`"Win64`" Platform=`"Revit`" SeriesMin=`"R$y`" SeriesMax=`"R$y`" />`r`n"
        $components += "    <ComponentEntry AppName=`"EK Last Similar $y`" Version=`"$AppVersion`" ModuleName=`"./Contents/$y/EKLastSimilar.addin`" AppDescription=`"EK Last Similar`" />`r`n"
        $components += "  </Components>`r`n"
    }

    $years   = $targets | ForEach-Object { $_.Year }
    $minYear = ($years | Measure-Object -Minimum).Minimum
    $maxYear = ($years | Measure-Object -Maximum).Maximum

    $xml  = "<?xml version=`"1.0`" encoding=`"utf-8`"?>`r`n"
    $xml += "<ApplicationPackage SchemaVersion=`"1.0`" AutodeskProduct=`"Revit`" ProductType=`"Application`" Name=`"EK Last Similar`" AppVersion=`"$AppVersion`" Description=`"Fast last/recent family placement for Autodesk Revit.`" Author=`"EK`" ProductCode=`"{D56747A9-6214-4468-B912-6D7B73769046}`" UpgradeCode=`"{A5AF765D-FDD8-4F91-88EB-59696880B2B1}`">`r`n"
    $xml += "  <CompanyDetails Name=`"EK`" />`r`n"
    $xml += "  <RuntimeRequirements OS=`"Win64`" Platform=`"Revit`" SeriesMin=`"R$minYear`" SeriesMax=`"R$maxYear`" />`r`n"
    $xml += $components
    $xml += "</ApplicationPackage>`r`n"

    [System.IO.File]::WriteAllText((Join-Path $Staging 'PackageContents.xml'), $xml, (New-Object System.Text.UTF8Encoding($false)))

    # Files from a downloaded ZIP may carry "blocked" marks; the add-in must not.
    Get-ChildItem -LiteralPath $Staging -Recurse -File | ForEach-Object {
        try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch { }
    }

    if (-not (Test-Path -LiteralPath (Join-Path $Staging 'PackageContents.xml'))) { throw 'PackageContents.xml missing' }
    [xml](Get-Content -LiteralPath (Join-Path $Staging 'PackageContents.xml') -Raw) | Out-Null
    foreach ($v in $targets) {
        foreach ($f in @('EKLastSimilar.addin', 'EKLastSimilar.dll')) {
            if (-not (Test-Path -LiteralPath (Join-Path $Staging ("Contents\{0}\{1}" -f $v.Year, $f)))) {
                throw ("{0} missing for Revit {1}" -f $f, $v.Year)
            }
        }
    }
} catch {
    try { Remove-Dir $Staging } catch { }
    Stop-Install "Could not prepare the new bundle: $($_.Exception.Message)"
}

# 6. Swap in. If the final rename fails, the previous install is put back.
try {
    if (-not (Test-Path -LiteralPath $PluginsRoot)) {
        New-Item -ItemType Directory -Path $PluginsRoot -Force -ErrorAction Stop | Out-Null
    }

    Remove-Dir $Previous

    if (Test-Path -LiteralPath $Dest) {
        Move-Item -LiteralPath $Dest -Destination $Previous -ErrorAction Stop
    }
} catch {
    try { Remove-Dir $Staging } catch { }
    Stop-Install "Could not replace the existing install (is a file in it open?): $($_.Exception.Message)"
}

try {
    Move-Item -LiteralPath $Staging -Destination $Dest -ErrorAction Stop
} catch {
    $reason = $_.Exception.Message
    $restored = $true
    if ((Test-Path -LiteralPath $Previous) -and -not (Test-Path -LiteralPath $Dest)) {
        try { Move-Item -LiteralPath $Previous -Destination $Dest -ErrorAction Stop }
        catch { $restored = $false }
    }
    try { Remove-Dir $Staging } catch { }

    if ($restored) {
        Stop-Install "Could not install the new bundle: $reason"
    } else {
        Stop-Install ("Could not install the new bundle: $reason" + [Environment]::NewLine +
            "The previous install could not be put back automatically. It is kept here:" + [Environment]::NewLine +
            "  $Previous" + [Environment]::NewLine +
            "Rename it to $Dest or simply run the installer again.") $true
    }
}

try { Remove-Dir $Previous } catch { Say "Note: could not delete $Previous (harmless; Revit does not load it)." 'Yellow' }

# 7. Remove older DIRECT installs of EKLastSimilar only (they would load twice).
foreach ($y in 2024..2027) {
    $addinDir = Join-Path $AutodeskRoaming "Revit\Addins\$y"
    $oldManifest = Join-Path $addinDir 'EKLastSimilar.addin'
    $oldFolder = Join-Path $addinDir 'EKLastSimilar'

    if (Test-Path -LiteralPath $oldManifest) {
        try { Remove-Item -LiteralPath $oldManifest -Force -ErrorAction Stop; Say "Removed old direct install: $oldManifest" }
        catch { Say "WARNING: could not remove $oldManifest - delete it manually." 'Yellow' }
    }
    if (Test-Path -LiteralPath $oldFolder) {
        try { Remove-Item -LiteralPath $oldFolder -Recurse -Force -ErrorAction Stop; Say "Removed old direct install folder: $oldFolder" }
        catch { Say "WARNING: could not remove $oldFolder - delete it manually." 'Yellow' }
    }

    # Machine-wide copies need admin rights: report, never touch.
    $machineManifest = Join-Path $env:ProgramData "Autodesk\Revit\Addins\$y\EKLastSimilar.addin"
    if (Test-Path -LiteralPath $machineManifest) {
        Say "WARNING: a machine-wide copy exists and would load twice: $machineManifest (remove it as administrator)." 'Yellow'
    }
}

$machineBundle = Join-Path $env:ProgramData 'Autodesk\ApplicationPlugins\EKLastSimilar.bundle'
if (Test-Path -LiteralPath $machineBundle) {
    Say "WARNING: a machine-wide bundle exists and would load twice: $machineBundle (remove it as administrator)." 'Yellow'
}

Say ''
Say '=================================================='
Say '  INSTALL COMPLETE' 'Green'
Say '=================================================='
Say ("Installed for Revit: " + (($targets | ForEach-Object { $_.Year }) -join ', '))
Say "Location: $Dest"
Say 'Your recent types and heights in %APPDATA%\EK\LastSimilar were kept.'
Say 'Start Revit and look for EK > Placement.'
exit 0

using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EK.LastSimilar.Services;
using EK.LastSimilar.UI;

namespace EK.LastSimilar
{
    [Transaction(TransactionMode.Manual)]
    public class SettingsCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            RunLog.SetEnabled(StateStore.GetDiagnosticsEnabled());
            RunLog.Begin("Settings");
            DiagnosticsProbe.CommandEntry(commandData.Application, "Settings");

            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                if (uidoc == null)
                    return Result.Cancelled;

                Document doc = uidoc.Document;
                StateSession session = StateStore.Open(doc);

                // Settings is based on actually placed history. Merely selecting an
                // element does not add it to Recent 5 and does not change Last.
                // Its list shows family types and Room Tags only (lines have no settings),
                // so a history with only lines would otherwise open an empty window.
                if (StateStore.GetSettingsOrder(session.Doc, doc).Count == 0)
                {
                    CommandRunner.SafeDialog(
                        "No placed family types are remembered for this project yet.\n\n" +
                        "Place a family instance in Revit; it will appear here automatically.");
                    return Result.Cancelled;
                }

                var window = new SettingsWindow(uiapp.MainWindowHandle, doc);
                bool? result = window.ShowDialog();

                if (result == true && window.SymbolToPlace != null && window.EntryToPlace != null)
                {
                    // Do not change Last until an instance is actually placed.
                    return CommandRunner.Place(uiapp, window.SymbolToPlace, window.EntryToPlace, window.Session ?? session);
                }

                // Settings only touched the state file, never the model.
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                RunLog.Add("Error: " + ex);
                CommandRunner.SafeDialog(ex.Message);
                return Result.Cancelled;
            }
            finally
            {
                DiagnosticsProbe.CommandExit(commandData.Application, "Settings");
                PlacementService.DetachListener();
                RunLog.Flush();
            }
        }
    }
}

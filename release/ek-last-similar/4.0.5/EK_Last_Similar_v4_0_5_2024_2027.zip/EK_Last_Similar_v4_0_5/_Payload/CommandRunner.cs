using System;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EK.LastSimilar.Services;

namespace EK.LastSimilar
{
    internal static class CommandRunner
    {
        /// <summary>
        /// Runs placement and maps the outcome to a Result.
        /// IMPORTANT: Revit rolls back everything a command did when it returns Failed or
        /// Cancelled. So whenever ANYTHING was committed during the native placement
        /// (instances of the requested type, or of another type picked in the Properties
        /// palette, or any other edit) we return Succeeded, even if some height corrections
        /// were skipped or rolled back. Cancelled is returned only when nothing happened.
        /// </summary>
        public static Result Place(
            UIApplication uiapp,
            FamilySymbol symbol,
            RecentTypeState entry,
            StateSession session)
        {
            // RoomTagType derives from FamilySymbol, but RoomTag is an annotation.
            // Dispatch before entering the model-family capture/height workflow.
            if (symbol is Autodesk.Revit.DB.Architecture.RoomTagType roomTagType)
                return RoomTagSimilarService.Start(uiapp, roomTagType, entry);

            PlacementOutcome outcome = PlacementService.PlaceAndFinalize(uiapp, symbol, entry, session);

            RunLog.Add(
                $"Summary: placed={outcome.Placed}, wallCorrected={outcome.WallCorrected}, " +
                $"wallAlreadyOk={outcome.WallAlreadyOk}, wallSkipped={outcome.WallSkipped}, " +
                $"wallFailed={outcome.WallFailed}, ceilingUntouched={outcome.CeilingUntouched}, " +
                $"equipmentCorrected={outcome.EquipmentCorrected}, otherUntouched={outcome.OtherUntouched}, " +
                $"otherFailed={outcome.OtherFailed}, otherTypePlaced={outcome.OtherTypeAdded}, " +
                $"reportedProblems={outcome.Problems.Count}, " +
                $"anyDocumentChange={outcome.AnyDocumentChange}, listenerAttached={PlacementService.IsListenerAttached}");

            if (outcome.Placed > 0 || outcome.AnyDocumentChange)
            {
                ReportProblemsIfAny(outcome);
                return Result.Succeeded;
            }

            if (!string.IsNullOrWhiteSpace(outcome.PromptError))
            {
                SafeDialog(
                    "Could not place this type here.\n\n" + outcome.PromptError +
                    "\n\nTip: switch to a view where this family can be placed (e.g. a floor plan for wall/ceiling devices).");
            }

            // Nothing at all was committed during placement: let Revit discard the optional
            // "Activate Type" transaction. No placed element can be lost here.
            return Result.Cancelled;
        }

        private static void ReportProblemsIfAny(PlacementOutcome outcome)
        {
            // These are forensic/skipped-correction warnings, not fatal placement errors.
            // Keep normal use quiet; show them only when Troubleshooting is enabled.
            if (!RunLog.Enabled || outcome.Problems.Count == 0)
                return;

            var sb = new StringBuilder();
            string what = string.IsNullOrWhiteSpace(outcome.RequestedTypeName)
                ? ""
                : " of " + outcome.RequestedTypeName;
            string others = outcome.OtherTypeAdded > 0
                ? $" and {outcome.OtherTypeAdded} of other type(s)"
                : "";
            sb.AppendLine($"Placed {outcome.Placed} instance(s){what}{others}.");
            sb.AppendLine("These were NOT height-corrected and were left exactly as placed:");
            sb.AppendLine();

            int shown = 0;
            foreach (string p in outcome.Problems)
            {
                if (shown++ >= 6)
                {
                    sb.AppendLine($"... and {outcome.Problems.Count - 6} more.");
                    break;
                }
                sb.AppendLine("• " + p);
            }

            sb.AppendLine();
            sb.Append("Full details (newest run at the bottom): " + RunLog.FilePath);
            SafeDialog(sb.ToString());
        }

        public static void SafeDialog(string text)
        {
            try
            {
                var td = new TaskDialog("EK Last Similar")
                {
                    MainInstruction = "EK Last Similar",
                    MainContent = text,
                    CommonButtons = TaskDialogCommonButtons.Close
                };
                td.Show();
            }
            catch { }
        }
    }
}

using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EK.LastSimilar.Services;
using EK.LastSimilar.UI;

namespace EK.LastSimilar
{
    /// <summary>
    /// Dedicated Recent 5 command. This exists so Revit can assign it its own
    /// keyboard shortcut reliably, instead of trying to infer Ctrl/Shift/Alt
    /// after Revit has already consumed another shortcut sequence.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    public class RecentFiveCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            RunLog.SetEnabled(StateStore.GetDiagnosticsEnabled());
            RunLog.Begin("Recent 5");
            DiagnosticsProbe.CommandEntry(commandData.Application, "Recent 5");

            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                if (uidoc == null)
                    return Result.Cancelled;

                Document doc = uidoc.Document;
                StateSession session = StateStore.Open(doc);
                var recent = StateStore.GetRecentValid(session.Doc, doc, 5);

                if (recent.Count == 0)
                {
                    CommandRunner.SafeDialog(
                        "No recent families or lines are remembered for this project yet.\n\n" +
                        "Place a family instance or draw a Detail/Model Line normally in Revit, then run Recent 5 again.");
                    return Result.Cancelled;
                }

                var popup = new RecentFivePopup(uiapp.MainWindowHandle, recent, RevitTheme.IsDark());
                bool? picked = popup.ShowDialog();
                if (picked != true || popup.Selected == null)
                {
                    RunLog.Add("Recent 5 closed without a choice.");
                    return Result.Cancelled;
                }

                RecentResolvedItem chosen = popup.Selected;
                RecentTypeState entry = chosen.State;
                RunLog.Add("Recent 5 choice: " + chosen.PrimaryText);

                if (entry == null)
                    return Result.Cancelled;

                if (chosen.IsLine)
                    return LineSimilarService.Start(uiapp, chosen);

                FamilySymbol symbol = chosen.Symbol;
                if (symbol == null || !symbol.IsValidObject)
                    return Result.Cancelled;

                // Do not redefine Last just because this command was opened.
                // Last changes only when an eligible family/line is actually placed.
                return CommandRunner.Place(uiapp, symbol, entry, session);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                RunLog.Add("Error: " + ex);
                CommandRunner.SafeDialog(ex.Message);
                return Result.Cancelled;
            }
            finally
            {
                DiagnosticsProbe.CommandExit(commandData.Application, "Recent 5");
                PlacementService.DetachListener();
                RunLog.Add("Recent 5 command end. Listener attached: " + PlacementService.IsListenerAttached);
                RunLog.Flush();
            }
        }
    }
}

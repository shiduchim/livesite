using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;

namespace EK.LastSimilar.Services
{
    // Separate annotation path. RoomTag is a SpatialElementTag, not a model
    // FamilyInstance. Native Revit owns the room selection, link handling, preview,
    // leader/orientation controls, placement transactions and Undo.
    internal static class RoomTagSimilarService
    {
        internal static bool IsTrackable(RoomTag tag)
        {
            try
            {
                return tag != null && tag.IsValidObject &&
                    tag.GroupId == ElementId.InvalidElementId &&
                    tag.OwnerViewId != ElementId.InvalidElementId &&
                    StateStore.IsUsableSymbol(tag.RoomTagType);
            }
            catch { return false; }
        }

        internal static PlacementRecord BuildRecord(RoomTag tag)
        {
            if (!IsTrackable(tag)) return null;
            PlacementRecord record = StateStore.BuildRecord(tag.RoomTagType);
            if (record == null) return null;
            record.ItemKind = RecentItemKinds.RoomTag;
            record.SourceElementUniqueId = tag.UniqueId;
            record.LearnedWallHeightFeet = null;
            return record;
        }

        internal static Result Start(UIApplication uiapp, RoomTagType type, RecentTypeState entry)
        {
            UIDocument uidoc = uiapp?.ActiveUIDocument;
            if (uidoc == null || !StateStore.IsUsableSymbol(type)) return Result.Cancelled;
            try
            {
                RevitCommandId roomCommand = RevitCommandId.LookupPostableCommandId(PostableCommand.RoomTag);
                if (roomCommand == null || !uiapp.CanPostCommand(roomCommand))
                {
                    CommandRunner.SafeDialog("Room tagging is not available in the current view. Open a view where Revit allows Room Tags.");
                    return Result.Cancelled;
                }

                if (uidoc.CanPlaceElementType(type))
                {
                    // Queue the precise RoomTagType; no FamilyInstance placement
                    // prompt, default-type mutation or post-placement adjustment.
                    uidoc.PostRequestForElementTypePlacement(type);
                    RunLog.Add("Room Tag native placement queued: " + type.FamilyName + " : " + type.Name +
                        " | type=" + type.Id.Value + " | height correction disabled");
                    return Result.Succeeded;
                }

                // Some types cannot be queued through the ElementType API. Use
                // native Create Similar only with an actual room tag of that exact
                // type in the current view; never silently use the default tag type.
                RoomTag source = null;
                if (!string.IsNullOrEmpty(entry?.SourceElementUniqueId))
                    source = uidoc.Document.GetElement(entry.SourceElementUniqueId) as RoomTag;
                if (!Matches(source, type, uidoc.ActiveView))
                    source = new FilteredElementCollector(uidoc.Document, uidoc.ActiveView.Id)
                        .OfClass(typeof(RoomTag)).Cast<RoomTag>()
                        .FirstOrDefault(x => Matches(x, type, uidoc.ActiveView));
                if (source == null)
                {
                    CommandRunner.SafeDialog("Revit cannot start this Room Tag type directly here. Place one tag of this type in the current view, then use Last Similar.");
                    return Result.Cancelled;
                }

                ICollection<ElementId> oldSelection = uidoc.Selection.GetElementIds();
                bool posted = false;
                try
                {
                    uidoc.Selection.SetElementIds(new List<ElementId> { source.Id });
                    RevitCommandId similar = RevitCommandId.LookupPostableCommandId(PostableCommand.CreateSimilar);
                    if (similar == null || !uiapp.CanPostCommand(similar))
                    {
                        CommandRunner.SafeDialog("Revit Create Similar is not available for this Room Tag in the current view.");
                        return Result.Cancelled;
                    }
                    uiapp.PostCommand(similar);
                    posted = true;
                    RunLog.Add("Room Tag Create Similar queued from tag " + source.Id.Value +
                        " | type=" + type.Id.Value + " | height correction disabled");
                    return Result.Succeeded;
                }
                finally
                {
                    if (!posted)
                        try { uidoc.Selection.SetElementIds(oldSelection); } catch { }
                }
            }
            catch (Exception ex)
            {
                RunLog.Add("Room Tag placement unavailable: " + ex.Message);
                CommandRunner.SafeDialog("Could not start native Room Tag placement.\n\n" + ex.Message);
                return Result.Cancelled;
            }
        }

        private static bool Matches(RoomTag tag, RoomTagType type, View view) =>
            IsTrackable(tag) && tag.GetTypeId() == type.Id && tag.OwnerViewId == view.Id;
    }
}

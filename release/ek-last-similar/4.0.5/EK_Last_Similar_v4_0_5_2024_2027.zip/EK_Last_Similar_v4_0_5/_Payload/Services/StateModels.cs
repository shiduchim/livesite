using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EK.LastSimilar.Services
{
    public static class HeightModes
    {
        public const string Last = "last";
        public const string Standard = "standard";

        public static bool IsStandard(string mode) =>
            string.Equals(mode, Standard, StringComparison.OrdinalIgnoreCase);
    }

    public static class RecentItemKinds
    {
        public const string Family = "family";
        public const string DetailLine = "detail-line";
        public const string ModelLine = "model-line";
        public const string RoomTag = "room-tag";

        public static bool IsRoomTag(string kind) =>
            string.Equals(kind, RoomTag, StringComparison.OrdinalIgnoreCase);

        public static bool IsLine(string kind) =>
            string.Equals(kind, DetailLine, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(kind, ModelLine, StringComparison.OrdinalIgnoreCase);

        public static bool IsDetailLine(string kind) =>
            string.Equals(kind, DetailLine, StringComparison.OrdinalIgnoreCase);

        public static bool IsModelLine(string kind) =>
            string.Equals(kind, ModelLine, StringComparison.OrdinalIgnoreCase);
    }

    // NOTE: DataContractJsonSerializer does NOT run constructors or property
    // initializers when reading JSON. Every consumer must tolerate nulls.
    [DataContract]
    public class AppState
    {
        [DataMember] public int Version { get; set; } = 8;

        // Recent 5 visual preferences. Nullable so older state files can use
        // the intended defaults when these fields do not exist yet.
        [DataMember] public bool? UseFamilyThumbnails { get; set; } = true;
        [DataMember] public int? FamilyThumbnailSize { get; set; } = 24;

        // Troubleshooting is intentionally OFF by default. When enabled,
        // the detailed rolling log and skipped-placement warning dialogs are active.
        [DataMember] public bool? DiagnosticsEnabled { get; set; } = false;

        // Global preference for ALL projects; absent in earlier JSON means enabled.
        [DataMember] public bool? HeightCorrectionsEnabled { get; set; } = true;

        [DataMember] public Dictionary<string, DocumentState> Documents { get; set; }
            = new Dictionary<string, DocumentState>();
    }

    [DataContract]
    public class DocumentState
    {
        [DataMember] public string LastSymbolUniqueId { get; set; }
        [DataMember] public List<RecentTypeState> History { get; set; }
            = new List<RecentTypeState>();

        // v3.2: used only to prune projects that have not been touched for a long time.
        [DataMember] public long LastTouchedUtcTicks { get; set; }
    }

    [DataContract]
    public class RecentTypeState
    {
        // Historical name kept for backward compatibility. For families this is the
        // FamilySymbol.UniqueId. For lines it is a synthetic stable key based on
        // line kind + GraphicsStyle.UniqueId.
        [DataMember] public string SymbolUniqueId { get; set; }

        // Missing/null in old state files means Family.
        [DataMember] public string ItemKind { get; set; } = RecentItemKinds.Family;

        // Line style is line-only; source element is also used by native Room Tag placement.
        [DataMember] public string LineStyleUniqueId { get; set; }
        [DataMember] public string SourceElementUniqueId { get; set; }

        [DataMember] public string FamilyName { get; set; }
        [DataMember] public string TypeName { get; set; }
        [DataMember] public string CategoryName { get; set; }

        // BuiltInCategory as a 64-bit value (language independent). Null in v1 state files.
        [DataMember] public long? CategoryIdValue { get; set; }

        // "last" or "standard"
        [DataMember] public string HeightMode { get; set; } = HeightModes.Last;

        [DataMember] public double? LastWallHeightFeet { get; set; }
        [DataMember] public double? StandardHeightMm { get; set; }

        // Per-family-type preference; absent in earlier JSON means enabled.
        [DataMember] public bool? HeightCorrectionEnabled { get; set; } = true;
        [DataMember] public bool Favorite { get; set; }

        // Settings-window-only ordering preference. This does NOT change true placement
        // chronology or Recent 5. A real new placement clears it automatically.
        [DataMember] public bool SettingsBottom { get; set; }
        // Ordering only inside Settings. Larger/newer values are farther down.
        [DataMember] public long SettingsBottomOrderTicks { get; set; }

        // Updated ONLY when an instance of this type is actually placed.
        [DataMember] public long LastUsedUtcTicks { get; set; }
    }

    /// <summary>
    /// Plain data describing one real placement. Built from Revit objects OUTSIDE the
    /// state-file lock, then written by StateStore.RecordPlacement.
    /// </summary>
    public sealed class PlacementRecord
    {
        public string SymbolUniqueId { get; set; }
        public string ItemKind { get; set; } = RecentItemKinds.Family;
        public string LineStyleUniqueId { get; set; }
        public string SourceElementUniqueId { get; set; }

        public string FamilyName { get; set; }
        public string TypeName { get; set; }
        public string CategoryName { get; set; }
        public long? CategoryIdValue { get; set; }
        public double? LearnedWallHeightFeet { get; set; }
    }

    public class RecentResolvedItem
    {
        public RecentTypeState State { get; set; }
        public Autodesk.Revit.DB.FamilySymbol Symbol { get; set; }
        public Autodesk.Revit.DB.GraphicsStyle LineStyle { get; set; }
        public Autodesk.Revit.DB.CurveElement SourceCurve { get; set; }
        public System.Windows.Media.ImageSource Icon { get; set; }
        public double VisualSize { get; set; } = 18;

        public bool IsLine => RecentItemKinds.IsLine(State?.ItemKind);
        public bool IsRoomTag => RecentItemKinds.IsRoomTag(State?.ItemKind) ||
            Symbol is Autodesk.Revit.DB.Architecture.RoomTagType;

        public string PrimaryText
        {
            get
            {
                string type = State?.TypeName ?? "";
                return string.IsNullOrWhiteSpace(type)
                    ? (State?.FamilyName ?? "")
                    : type;
            }
        }

        public string FamilyText => State?.FamilyName ?? "";

        public string CategoryText => State?.CategoryName ?? "";

        public string SecondaryText
        {
            get
            {
                string family = FamilyText;
                string category = CategoryText;
                if (string.IsNullOrWhiteSpace(category))
                    return family;
                if (string.IsNullOrWhiteSpace(family))
                    return category;
                return family + "  /  " + category;
            }
        }

        public string ToolTipText
        {
            get
            {
                string text = FamilyText + " : " + PrimaryText;
                return string.IsNullOrWhiteSpace(CategoryText) ? text : text + "\n" + CategoryText;
            }
        }

        public string HeightText
        {
            get
            {
                if (State == null || IsLine || IsRoomTag) return "";
                if (State.HeightCorrectionEnabled == false) return "Height off";
                if (HeightModes.IsStandard(State.HeightMode))
                {
                    return State.StandardHeightMm.HasValue
                        ? $"Fixed {State.StandardHeightMm.Value / 10.0:0.#} cm"
                        : "Fixed (not set)";
                }

                return State.LastWallHeightFeet.HasValue
                    ? $"Last {State.LastWallHeightFeet.Value * 30.48:0.#} cm"
                    : "Not learned yet";
            }
        }

        public string FavoriteText => State != null && State.Favorite ? "★" : "";

    }
}

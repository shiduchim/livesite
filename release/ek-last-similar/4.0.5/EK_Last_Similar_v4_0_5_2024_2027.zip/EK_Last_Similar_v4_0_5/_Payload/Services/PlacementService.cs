using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using RevitApplication = Autodesk.Revit.ApplicationServices.Application;

namespace EK.LastSimilar.Services
{
    public sealed class PlacementOutcome
    {
        public int Placed { get; set; }
        public int WallCorrected { get; set; }
        public int WallAlreadyOk { get; set; }
        public int WallSkipped { get; set; }
        public int WallFailed { get; set; }
        public int CeilingUntouched { get; set; }
        public int EquipmentCorrected { get; set; }
        public int OtherUntouched { get; set; }
        public int OtherFailed { get; set; }
        public int OtherTypeAdded { get; set; }
        public string PromptError { get; set; }

        /// <summary>"Family : Type" the run was started with (for the summary dialog).</summary>
        public string RequestedTypeName { get; set; } = "";

        /// <summary>
        /// True if ANY change was committed to the document while the native placement ran
        /// (including instances of another type picked in the Properties palette). The command
        /// must then return Succeeded, or Revit would roll those changes back.
        /// </summary>
        public bool AnyDocumentChange { get; set; }

        public List<string> Problems { get; } = new List<string>();
    }

    /// <summary>
    /// Placement correction session with its own TEMPORARY, READ-ONLY DocumentChanged listener:
    ///   attach -> PromptForFamilyInstancePlacement -> finally detach -> correct -> exit.
    /// This temporary listener never survives PlaceAndFinalize. The separate LastPlacedTracker
    /// stays subscribed for the Revit session, but it is read-only (history file only).
    ///
    /// v3.9.4: every DocumentChanged event of the session and every candidate instance is
    /// written to last-run.log, and nothing that a user would read as "the height correction
    /// did not run" is skipped silently any more.
    /// </summary>
    public static class PlacementService
    {
        // The one listener that may exist, and the exact Application object it was
        // attached to. Kept static only so it can ALWAYS be detached (finally block,
        // command-level finally, and App.OnShutdown as a last line of defence).
        private static RevitApplication _listenerApp;
        private static EventHandler<DocumentChangedEventArgs> _listener;

        // Type id of the symbol an active session is placing (long.MinValue = no session).
        // Read by LastPlacedTracker so it does not learn a pre-correction height.
        private static long _activeSessionTypeIdValue = long.MinValue;

        public static bool IsListenerAttached => _listener != null;

        /// <summary>True while a Last Similar placement prompt is running.</summary>
        internal static string DiagnosticSessionState =>
            "active=" + IsSessionActive + " requestedType=" + _activeSessionTypeIdValue +
            " listener=" + IsListenerAttached;

        internal static bool IsSessionActive => _activeSessionTypeIdValue != long.MinValue;

        internal static bool IsActiveSessionType(FamilyInstance fi)
        {
            if (_activeSessionTypeIdValue == long.MinValue || fi == null)
                return false;

            try { return fi.GetTypeId().Value == _activeSessionTypeIdValue; }
            catch { return false; }
        }

        /// <summary>
        /// Places the symbol and corrects ONLY the instances created in this session.
        /// NEVER throws: once the user has placed something, an exception escaping the
        /// command would make Revit roll back every placed instance.
        /// </summary>
        public static PlacementOutcome PlaceAndFinalize(
            UIApplication uiapp,
            FamilySymbol symbol,
            RecentTypeState entry,
            StateSession session)
        {
            var outcome = new PlacementOutcome();

            UIDocument uidoc;
            Document doc;
            try
            {
                uidoc = uiapp.ActiveUIDocument;
                doc = uidoc.Document;

                if (symbol == null || !symbol.IsValidObject)
                {
                    outcome.PromptError = "The remembered family type no longer exists in this project.";
                    return outcome;
                }
            }
            catch (Exception ex)
            {
                outcome.PromptError = ex.Message;
                return outcome;
            }

            ElementId requestedTypeId = symbol.Id;
            outcome.RequestedTypeName = SafeName(symbol);

            // Snapshot the master switch for this placement run. Do not change the
            // decision in the middle if Settings is saved in another Revit process.
            bool globalHeightCorrectionsEnabled = StateStore.GetHeightCorrectionsEnabled();

            // Everything needed to explain this run later, from one log file.
            ElementId viewLevelId = LogSessionHeader(doc, uidoc, symbol, entry, session);

            TryActivate(doc, symbol);

            // Ordered + de-duplicated ids of NEW top-level instances of the EXACT type.
            var addedIds = new List<ElementId>();
            var seen = new HashSet<long>();

            // New top-level instances of OTHER types (Type Selector changed during the run).
            // Never edited; only reported.
            var otherTypeIds = new List<ElementId>();
            var otherSeen = new HashSet<long>();

            bool anyChange = false;
            int eventNo = 0;

            EventHandler<DocumentChangedEventArgs> handler = (sender, args) =>
            {
                // READ ONLY. Records ids and diagnostics, never touches the model.
                try
                {
                    Document changed = args.GetDocument();
                    if (!IsSameDocument(changed, doc))
                    {
                        DiagnosticsProbe.IgnoredDocument(changed, doc);
                        return;
                    }

                    // Something was committed/undone in this document during placement:
                    // the command result must keep it.
                    anyChange = true;
                    eventNo++;

                    UndoOperation op = args.Operation;
                    ICollection<ElementId> added = args.GetAddedElementIds();

                    // Diagnostics are isolated: they can never cost a capture.
                    ICollection<ElementId> modified = null;
                    ICollection<ElementId> deleted = null;
                    try { modified = args.GetModifiedElementIds(); }
                    catch { }
                    try { deleted = args.GetDeletedElementIds(); }
                    catch { }

                    RunLog.Add("  [event " + eventNo + "] " + op +
                               " | transaction " + TransactionNames(args) +
                               " | added " + Count(added) +
                               ", modified " + Count(modified) +
                               ", deleted " + Count(deleted));

                    // Life of instances captured earlier in this run. A rotation or edit after
                    // placement shows up as "modified" (same id). A replaced element would
                    // show up as "DELETED" here, plus its new id as an added element below.
                    try
                    {
                        if (modified != null)
                        {
                            foreach (ElementId id in modified)
                            {
                                if (seen.Contains(id.Value))
                                    RunLog.Add("      ~ " + id.Value + " (captured) modified");
                            }
                        }

                        if (deleted != null)
                        {
                            foreach (ElementId id in deleted)
                            {
                                if (seen.Contains(id.Value))
                                    RunLog.Add("      - " + id.Value + " (captured) DELETED");
                            }
                        }
                    }
                    catch { }

                    // Undo/redo can "re-add" OLD deleted elements. Only fresh commits count.
                    if (op != UndoOperation.TransactionCommitted)
                    {
                        if (Count(added) > 0)
                            RunLog.Add("      (not a fresh commit: its added ids are not captured)");
                        return;
                    }

                    if (added == null)
                        return;

                    int nonInstances = 0;
                    int ignoredNested = 0;

                    foreach (ElementId id in added)
                    {
                        if (seen.Contains(id.Value) || otherSeen.Contains(id.Value))
                            continue;

                        FamilyInstance fi = changed.GetElement(id) as FamilyInstance;
                        if (fi == null)
                        {
                            nonInstances++;
                            continue;
                        }

                        if (!IsEligibleFamilyInstance(fi))
                        {
                            ignoredNested++;
                            continue;
                        }

                        if (!SameId(fi.GetTypeId(), requestedTypeId))
                        {
                            otherSeen.Add(id.Value);
                            otherTypeIds.Add(id);
                            RunLog.Add("      + " + id.Value + " " + DescribeInstance(fi) +
                                       " -> NOT captured: a different type than the one this run started with" +
                                       " (left as placed by design)");
                            continue;
                        }

                        seen.Add(id.Value);
                        addedIds.Add(id);
                        RunLog.Add("      + " + id.Value + " " + DescribeInstance(fi) + " -> CAPTURED");
                    }

                    if (nonInstances > 0 || ignoredNested > 0)
                    {
                        RunLog.Add("      (also added: " + nonInstances + " non-instance element(s), " +
                                   ignoredNested + " nested/in-place instance(s); ignored)");
                    }
                }
                catch (Exception ex)
                {
                    // Never let the listener disturb Revit's own placement.
                    try { RunLog.Add("      listener read error: " + ex.Message); }
                    catch { }
                }
            };

            // Defensive: if anything ever leaked, remove it before adding a new one.
            DetachListener();

            try
            {
                _activeSessionTypeIdValue = requestedTypeId.Value;
                DiagnosticsProbe.SessionEvent(doc, "SESSION SET before listener attach");
                AttachListener(uiapp.Application, handler);

                try
                {
                    // Native Revit placement. The user may place several instances.
                    DiagnosticsProbe.SessionEvent(doc, "PROMPT ENTER");
                    uidoc.PromptForFamilyInstancePlacement(symbol);
                    RunLog.Add("Placement prompt returned.");
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException)
                {
                    // Normal Esc path.
                    RunLog.Add("Placement prompt ended (Esc / cancel).");
                }
                catch (Exception ex)
                {
                    // e.g. type cannot be placed in the active view.
                    outcome.PromptError = ex.Message;
                    RunLog.Add("Placement ended with: " + ex.GetType().Name + ": " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                outcome.PromptError = ex.Message;
            }
            finally
            {
                // CRITICAL: listener is gone BEFORE any correction transaction exists.
                DiagnosticsProbe.SessionEvent(doc, "PROMPT EXIT before listener detach");
                DetachListener();
                _activeSessionTypeIdValue = long.MinValue;
                DiagnosticsProbe.SessionEvent(doc, "SESSION CLEARED after listener detach");
            }

            outcome.AnyDocumentChange = anyChange;
            outcome.OtherTypeAdded = otherTypeIds.Count;

            if (IsListenerAttached)
            {
                // Should be impossible. Refuse to edit anything if it ever happens.
                outcome.Problems.Add("Safety stop: temporary listener could not be detached; no corrections made.");
                RunLog.Add("SAFETY STOP: listener still attached; skipping all corrections.");
                outcome.Placed = addedIds.Count;
                return outcome;
            }

            outcome.Placed = addedIds.Count;
            RunLog.Add("Capture result: " + addedIds.Count + " new instance(s) of the requested type, " +
                       otherTypeIds.Count + " of other types, " + eventNo + " document event(s).");

            if (addedIds.Count > 0)
            {
                double? learnedHeight = null;

                try
                {
                    learnedHeight = FinalizeInstances(doc, addedIds, requestedTypeId, entry, viewLevelId, outcome, globalHeightCorrectionsEnabled);
                }
                catch (Exception ex)
                {
                    outcome.Problems.Add("Finalize error: " + ex.Message);
                    RunLog.Add("Finalize error: " + ex);
                }

                // The passive tracker already recorded Last / Recent order for every real
                // placement. Here only a NEWLY learned (first-use) wall height is saved.
                if (learnedHeight.HasValue)
                {
                    bool saved = StateStore.SaveLearnedWallHeight(doc, symbol, learnedHeight.Value);
                    RunLog.Add("First-use height saved as learned: " +
                               LevelHeightService.MmText(learnedHeight.Value) + " mm (" + (saved ? "ok" : "FAILED") + ")");
                }

                // Safety net: if the tracker is not running, still remember what was placed.
                if (!LastPlacedTracker.IsRunning)
                    StateStore.RecordPlacement(doc, StateStore.BuildRecord(symbol));
            }

            // Read-only. Instances of other types are never edited, but a wall-hosted one looks
            // exactly like "the height correction did not run", so it is reported.
            if (otherTypeIds.Count > 0)
                ReportOtherTypes(doc, otherTypeIds, outcome);

            return outcome;
        }

        /// <returns>The wall height learned in "adopt" mode (first use of a type), else null.</returns>
        private static double? FinalizeInstances(
            Document doc,
            List<ElementId> addedIds,
            ElementId requestedTypeId,
            RecentTypeState entry,
            ElementId viewLevelId,
            PlacementOutcome outcome,
            bool globalHeightCorrectionsEnabled)
        {
            double? learned = null;

            List<LevelZ> levels = LevelHeightService.GetLevelsSorted(doc);

            // Decide the target ONCE per session: if no height is learned yet, every
            // instance of this session keeps its placed height ("adopt"), and the first
            // successfully adopted height becomes the learned one.
            double? sessionTarget = LevelHeightService.GetConfiguredTargetFeet(entry);
            bool adoptMode = !sessionTarget.HasValue;
            string modeText = LevelHeightService.DescribeTarget(entry);
            bool adjustHeights = globalHeightCorrectionsEnabled && entry?.HeightCorrectionEnabled != false;
            RunLog.Add("Auto height adjustment: " + (adjustHeights ? "ON" : "OFF") +
                " (global=" + (globalHeightCorrectionsEnabled ? "on" : "off") +
                ", this type=" + (entry?.HeightCorrectionEnabled == false ? "off" : "on") + ")");

            int committed = 0;
            int index = 0;

            using (var group = new TransactionGroup(doc, "EK Last Similar - Finalize Placement"))
            {
                group.Start();

                foreach (ElementId id in addedIds)
                {
                    index++;
                    try
                    {
                        ProcessCandidate(
                            doc, id, index, addedIds.Count, requestedTypeId, entry,
                            sessionTarget, adoptMode, modeText, levels, viewLevelId,
                            adjustHeights, outcome, ref committed, ref learned);
                    }
                    catch (Exception ex)
                    {
                        // v3.9.4: one unexpected error never stops later instances and never
                        // undoes corrections already committed in this run.
                        outcome.Problems.Add("Item " + id.Value + ": unexpected error, left as placed: " + ex.Message);
                        RunLog.Add("    UNEXPECTED ERROR for " + id.Value + ": " + ex);
                    }
                }

                // One undo entry for all corrections. Nothing committed => nothing to keep.
                try
                {
                    if (committed > 0)
                    {
                        group.Assimilate();
                        RunLog.Add("Corrections kept as ONE undo step (" + committed + " committed).");
                    }
                    else
                    {
                        group.RollBack();
                        RunLog.Add("No correction was committed (nothing changed in the model).");
                    }
                }
                catch (Exception ex)
                {
                    RunLog.Add("Correction group close error: " + ex.Message);
                }
            }

            return learned;
        }

        private static void ProcessCandidate(
            Document doc,
            ElementId id,
            int index,
            int total,
            ElementId requestedTypeId,
            RecentTypeState entry,
            double? sessionTarget,
            bool adoptMode,
            string modeText,
            IList<LevelZ> levels,
            ElementId viewLevelId,
            bool adjustHeights,
            PlacementOutcome outcome,
            ref int committed,
            ref double? learned)
        {
            RunLog.Add("  ---- candidate " + index + "/" + total + ": element id " + id.Value);

            FamilyInstance fi = null;
            try { fi = doc.GetElement(id) as FamilyInstance; }
            catch { }

            // Re-validate everything: element may have been undone/deleted.
            if (fi == null || !fi.IsValidObject)
            {
                RunLog.Add("    Attempted     : NO - element no longer exists (undone or deleted during the run)");
                return;
            }

            string item = DescribeItem(fi, id);

            RunLog.Add("    UniqueId      : " + SafeUniqueId(fi));
            RunLog.Add("    Family / Type : " + DescribeInstance(fi) + "  (family placement type " + SafePlacementType(fi) + ")");
            RunLog.Add("    Initial       : " + LevelHeightService.DescribeState(doc, fi));
            RunLog.Add("    Rotation      : " + OrientationInfo.Capture(fi).Describe());
            RunLog.Add("    Height mode   : " + modeText);

            if (!SameId(fi.GetTypeId(), requestedTypeId) || !IsEligibleFamilyInstance(fi))
            {
                outcome.OtherUntouched++;
                RunLog.Add("    Attempted     : NO - no longer the requested type");
                return;
            }

            if (IsViewSpecificOrDetail(fi))
            {
                outcome.OtherUntouched++;
                RunLog.Add("    Attempted     : NO - detail/view-specific element (never adjusted)");
                return;
            }

            if (IsGroupMember(fi))
            {
                outcome.OtherUntouched++;
                RunLog.Add("    Attempted     : NO - inside a group (never adjusted)");
                return;
            }

            if (!adjustHeights)
            {
                outcome.OtherUntouched++;
                RunLog.Add("    Attempted     : NO - automatic height correction is disabled in Settings (global or type)");
                return;
            }

            HostInfo host = HostClassifier.Classify(fi);
            RunLog.Add("    Host          : " + host);
            DiagnosticsProbe.PlacedInstance(fi, "FINALIZE CANDIDATE", false);

            switch (host.Kind)
            {
                case HostKind.Wall:
                case HostKind.VerticalFace:
                {
                    CorrectionResult r = LevelHeightService.CorrectWallInstance(
                        doc, fi, sessionTarget, levels, viewLevelId, out double applied,
                        host);

                    // Count first: the group decision must never depend on logging below.
                    switch (r.Status)
                    {
                        case CorrectionStatus.Corrected:
                            committed++;
                            outcome.WallCorrected++;
                            break;
                        case CorrectionStatus.NoChangeNeeded:
                            outcome.WallAlreadyOk++;
                            break;
                        case CorrectionStatus.Skipped:
                            outcome.WallSkipped++;
                            outcome.Problems.Add(item + " left as placed: " + r.Message);
                            break;
                        default:
                            outcome.WallFailed++;
                            outcome.Problems.Add(item + " left as placed (rolled back): " + r.Message);
                            break;
                    }

                    LogCorrection(r, adoptMode);

                    if (adoptMode &&
                        !learned.HasValue &&
                        (r.Status == CorrectionStatus.Corrected || r.Status == CorrectionStatus.NoChangeNeeded) &&
                        !double.IsNaN(applied))
                    {
                        learned = applied;
                        if (entry != null)
                            entry.LastWallHeightFeet = applied;
                        RunLog.Add("    Learned       : first use -> " + LevelHeightService.MmText(applied) +
                                   " mm becomes this type's learned wall height");
                    }

                    break;
                }

                case HostKind.Ceiling:
                    // Ceiling lights, smoke detectors: NEVER change level or elevation.
                    outcome.CeilingUntouched++;
                    RunLog.Add("    Attempted     : NO - ceiling host: never changed (ceiling rule)");
                    break;

                case HostKind.Level:
                case HostKind.None:
                {
                    if (!HostClassifier.CategoryIs(fi, BuiltInCategory.OST_ElectricalEquipment))
                    {
                        outcome.OtherUntouched++;
                        RunLog.Add("    Attempted     : NO - not hosted on a wall face (" + host.ShortText +
                                   "); no rule for this category");

                        // A configured wall height means this type is expected on walls.
                        if (sessionTarget.HasValue)
                        {
                            outcome.Problems.Add(item + " is not on a wall face (" + host.ShortText +
                                                 "), so its height was left as placed." +
                                                 (IsFaceBased(fi)
                                                     ? " For wall devices use Placement: Vertical Face."
                                                     : ""));
                        }

                        break;
                    }

                    CorrectionResult r = LevelHeightService.CorrectFreeElectricalEquipment(doc, fi, levels, viewLevelId);

                    if (r.Status == CorrectionStatus.Corrected)
                    {
                        committed++;
                        outcome.EquipmentCorrected++;
                    }
                    else if (r.Status == CorrectionStatus.Failed)
                    {
                        outcome.OtherFailed++;
                        outcome.Problems.Add(item + " (equipment) left as placed (rolled back): " + r.Message);
                    }
                    else
                    {
                        outcome.OtherUntouched++;
                    }

                    LogCorrection(r, false);
                    break;
                }

                default:
                {
                    // Only hosts with a VERIFIED vertical planar face are edited.
                    // Horizontal/ceiling/floor/roof and unresolved linked hosts stay intact.
                    outcome.OtherUntouched++;
                    RunLog.Add("    Attempted     : NO - no verified vertical host face: " + host.ShortText);

                    // Reported only for a type that has a wall height configured (Fixed or
                    // learned): that is exactly the case a user reads as "it did not work".
                    // Ceiling-type devices in nested links are logged, not reported.
                    if (sessionTarget.HasValue)
                    {
                        outcome.Problems.Add(host.LinkProblem
                            ? item + ": its linked host could not be verified (" + host.ShortText +
                              "), so its height was left as placed."
                            : item + " is hosted on " + host.ShortText +
                              ", so its height was left as placed.");
                    }

                    break;
                }
            }
        }

        private static void LogCorrection(CorrectionResult r, bool adoptMode)
        {
            if (r == null)
                return;

            if (r.Pick != null)
                RunLog.Add("    Target level  : " + r.Pick.Describe());

            if (r.TargetFeet.HasValue)
            {
                RunLog.Add("    Target height : " + LevelHeightService.MmText(r.TargetFeet.Value) +
                           " mm above the target level" +
                           (adoptMode ? " (ADOPT: the placed height is kept)" : ""));
            }

            foreach (string note in r.Notes)
                RunLog.Add("    Note          : " + note);

            RunLog.Add("    Attempted     : " + (r.Attempted ? "YES (correction transaction started)" : "NO"));
            RunLog.Add("    Result        : " + StatusWord(r.Status) + " - " + r.Message);
            RunLog.Add("    Transaction   : " + r.Transaction);
            RunLog.Add("    Final         : " + (string.IsNullOrEmpty(r.After) ? "unchanged (nothing was edited)" : r.After));

            if (!string.IsNullOrEmpty(r.Orientation))
                RunLog.Add("    Orientation   : " + r.Orientation);
        }

        private static string StatusWord(CorrectionStatus s)
        {
            switch (s)
            {
                case CorrectionStatus.Corrected: return "CORRECTED";
                case CorrectionStatus.NoChangeNeeded: return "ALREADY CORRECT (no edit)";
                case CorrectionStatus.Skipped: return "SKIPPED (not attempted)";
                default: return "FAILED (rolled back, element left as placed)";
            }
        }

        /// <summary>Read-only. Logs every other-type instance; reports wall-hosted ones.</summary>
        private static void ReportOtherTypes(Document doc, List<ElementId> ids, PlacementOutcome outcome)
        {
            var wallByType = new Dictionary<string, List<long>>(StringComparer.Ordinal);

            foreach (ElementId id in ids)
            {
                try
                {
                    FamilyInstance fi = doc.GetElement(id) as FamilyInstance;
                    if (fi == null || !fi.IsValidObject)
                    {
                        RunLog.Add("  other type " + id.Value + ": no longer exists");
                        continue;
                    }

                    HostInfo host = HostClassifier.Classify(fi);
                    RunLog.Add("  other type " + id.Value + " " + DescribeInstance(fi) + " | host " + host +
                               " | " + LevelHeightService.DescribeState(doc, fi) +
                               " -> left as placed (EK only adjusts the type the run started with)");

                    if (host.Kind == HostKind.Wall || host.Kind == HostKind.VerticalFace)
                    {
                        string key = SafeTypeName(fi);
                        if (!wallByType.TryGetValue(key, out List<long> list))
                        {
                            list = new List<long>();
                            wallByType[key] = list;
                        }

                        list.Add(id.Value);
                    }
                }
                catch (Exception ex)
                {
                    RunLog.Add("  other type " + id.Value + ": read error " + ex.Message);
                }
            }

            foreach (KeyValuePair<string, List<long>> kv in wallByType)
            {
                string idText = string.Join(", ", kv.Value.Take(5)) + (kv.Value.Count > 5 ? ", ..." : "");
                outcome.Problems.Add(kv.Value.Count + " x " + kv.Key + " (id " + idText + "): placed after " +
                                     "switching type in the Type Selector. EK only adjusts the type the run " +
                                     "started with, so these keep the height Revit gave them. Start this type " +
                                     "from Last Similar or Recent 5 instead.");
            }
        }

        /// <summary>Session header. Returns the active view's level id (or null).</summary>
        private static ElementId LogSessionHeader(
            Document doc,
            UIDocument uidoc,
            FamilySymbol symbol,
            RecentTypeState entry,
            StateSession session)
        {
            ElementId viewLevelId = null;

            try
            {
                bool workshared = false;
                try { workshared = doc.IsWorkshared; }
                catch { }

                RunLog.Add("Document      : '" + SafeTitle(doc) + "' | workshared " + workshared +
                           " | history key " + (session?.Key ?? "?") +
                           " | history file readable " + (session?.FileReadable.ToString() ?? "?"));
            }
            catch { }

            try
            {
                View v = uidoc.ActiveView;
                if (v != null)
                {
                    string levelText = "none (not a plan view)";
                    Level gl = null;
                    try { gl = v.GenLevel; }
                    catch { }

                    if (gl != null)
                    {
                        viewLevelId = gl.Id;
                        levelText = LevelHeightService.LevelText(new LevelZ { Level = gl, Z = gl.ProjectElevation });
                    }

                    RunLog.Add("Active view   : '" + v.Name + "' (" + v.ViewType + ", id " + v.Id + ") | view level " + levelText);
                }
            }
            catch (Exception ex)
            {
                RunLog.Add("Active view   : unavailable (" + ex.Message + ")");
            }

            try
            {
                string category = "?";
                try { category = symbol.Category?.Name ?? "?"; }
                catch { }

                RunLog.Add("Requested     : " + SafeName(symbol) + " [" + category + "] | type id " +
                           symbol.Id + " | UniqueId " + symbol.UniqueId);
            }
            catch { }

            RunLog.Add("History entry : " + DescribeEntry(entry));
            RunLog.Add("Height mode   : " + LevelHeightService.DescribeTarget(entry));

            try
            {
                RunLog.Add("Host levels   : " + LevelHeightService.DescribeLevels(LevelHeightService.GetLevelsSorted(doc)));
            }
            catch (Exception ex)
            {
                RunLog.Add("Host levels   : unavailable (" + ex.Message + ")");
            }

            return viewLevelId;
        }

        private static string DescribeEntry(RecentTypeState e)
        {
            if (e == null)
                return "<none>";

            string used = "never";
            try
            {
                if (e.LastUsedUtcTicks > 0)
                {
                    used = new DateTime(e.LastUsedUtcTicks, DateTimeKind.Utc).ToLocalTime()
                        .ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                }
            }
            catch { }

            return "symbol " + (e.SymbolUniqueId ?? "?") +
                   " | mode '" + (e.HeightMode ?? "null") + "'" +
                   " | fixed " + (e.StandardHeightMm.HasValue
                       ? e.StandardHeightMm.Value.ToString("0.#", CultureInfo.InvariantCulture) + " mm"
                       : "-") +
                   " | learned " + (e.LastWallHeightFeet.HasValue
                       ? LevelHeightService.MmText(e.LastWallHeightFeet.Value) + " mm"
                       : "-") +
                   " | last placed " + used;
        }

        // ------------------------------------------------------------------
        // Listener lifetime
        // ------------------------------------------------------------------

        private static void AttachListener(
            RevitApplication app,
            EventHandler<DocumentChangedEventArgs> handler)
        {
            app.DocumentChanged += handler;
            _listenerApp = app;
            _listener = handler;
            RunLog.Add("Temporary DocumentChanged listener ATTACHED (read-only)");
        }

        /// <summary>Idempotent. Safe to call from anywhere, any number of times.</summary>
        public static void DetachListener()
        {
            RevitApplication app = _listenerApp;
            EventHandler<DocumentChangedEventArgs> handler = _listener;

            if (app == null || handler == null)
                return;

            try
            {
                app.DocumentChanged -= handler;
                _listenerApp = null;
                _listener = null;
                RunLog.Add("Temporary DocumentChanged listener DETACHED");
            }
            catch (Exception ex)
            {
                RunLog.Add("Listener detach error: " + ex.Message);
            }
        }

        // ------------------------------------------------------------------
        // Helpers
        // ------------------------------------------------------------------

        private static void TryActivate(Document doc, FamilySymbol symbol)
        {
            try
            {
                if (symbol.IsActive)
                    return;
            }
            catch
            {
                return;
            }

            using (var t = new Transaction(doc, "EK Last Similar - Activate Type"))
            {
                try
                {
                    if (t.Start() != TransactionStatus.Started)
                        return;

                    symbol.Activate();
                    doc.Regenerate();
                    t.Commit();
                }
                catch (Exception ex)
                {
                    // Let Revit's own placement try; it reports a clear error if it can't.
                    try
                    {
                        if (t.GetStatus() == TransactionStatus.Started)
                            t.RollBack();
                    }
                    catch { }

                    RunLog.Add("Type activation failed: " + ex.Message);
                }
            }
        }

        public static bool IsEligibleFamilyInstance(FamilyInstance fi)
        {
            if (fi == null)
                return false;

            try
            {
                if (!fi.IsValidObject)
                    return false;

                // Nested (shared) sub-components are never ours to edit.
                if (fi.SuperComponent != null)
                    return false;

                FamilySymbol symbol = fi.Symbol;
                if (symbol == null || symbol.Family == null)
                    return false;

                if (symbol.Family.IsInPlace)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private static bool IsViewSpecificOrDetail(FamilyInstance fi)
        {
            try
            {
                if (fi.ViewSpecific)
                    return true;
            }
            catch { }

            return HostClassifier.CategoryIs(fi, BuiltInCategory.OST_DetailComponents);
        }

        private static bool IsGroupMember(FamilyInstance fi)
        {
            try
            {
                ElementId gid = fi.GroupId;
                return gid != null && gid != ElementId.InvalidElementId;
            }
            catch
            {
                return true; // unknown => treat as unsafe
            }
        }

        private static bool IsFaceBased(FamilyInstance fi)
        {
            try { return fi.Symbol.Family.FamilyPlacementType == FamilyPlacementType.WorkPlaneBased; }
            catch { return false; }
        }

        private static bool IsSameDocument(Document a, Document b)
        {
            if (a == null || b == null)
                return false;

            if (ReferenceEquals(a, b))
                return true;

            try
            {
                if (a.Equals(b))
                    return true;
            }
            catch { }

            try
            {
                return !a.IsLinked &&
                       a.IsFamilyDocument == b.IsFamilyDocument &&
                       string.Equals(a.Title, b.Title, StringComparison.Ordinal) &&
                       string.Equals(a.PathName, b.PathName, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        private static bool SameId(ElementId a, ElementId b) =>
            a != null && b != null && a.Value == b.Value;

        private static int Count(ICollection<ElementId> ids) => ids == null ? 0 : ids.Count;

        private static string TransactionNames(DocumentChangedEventArgs args)
        {
            try
            {
                IList<string> names = args.GetTransactionNames();
                if (names == null || names.Count == 0)
                    return "(none)";

                return "'" + string.Join("', '", names) + "'";
            }
            catch
            {
                return "(unavailable)";
            }
        }

        private static string SafeName(FamilySymbol s)
        {
            try { return (s.Family?.Name ?? "?") + " : " + s.Name; }
            catch { return "?"; }
        }

        private static string SafeTypeName(FamilyInstance fi)
        {
            try { return SafeName(fi.Symbol); }
            catch { return "?"; }
        }

        /// <summary>"Family : Type [Category]".</summary>
        private static string DescribeInstance(FamilyInstance fi)
        {
            try
            {
                string category = fi.Category?.Name ?? "?";
                return SafeName(fi.Symbol) + " [" + category + "]";
            }
            catch
            {
                return "?";
            }
        }

        /// <summary>"Family : Type (id 123)" for the summary dialog.</summary>
        private static string DescribeItem(FamilyInstance fi, ElementId id)
        {
            return SafeTypeName(fi) + " (id " + id.Value + ")";
        }

        private static string SafeUniqueId(FamilyInstance fi)
        {
            try { return fi.UniqueId ?? "?"; }
            catch { return "?"; }
        }

        private static string SafePlacementType(FamilyInstance fi)
        {
            try { return fi.Symbol.Family.FamilyPlacementType.ToString(); }
            catch { return "?"; }
        }

        private static string SafeTitle(Document d)
        {
            try { return d.Title; }
            catch { return "?"; }
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Threading;
using Autodesk.Revit.DB;
using EK.LastSimilar.UI;

namespace EK.LastSimilar.Services
{
    /// <summary>
    /// A READ snapshot of one project's history (for commands and the Settings list).
    /// All writes go through StateStore's atomic read-modify-write methods, so a stale
    /// snapshot can never overwrite newer data written by the tracker or another Revit.
    /// </summary>
    public sealed class StateSession
    {
        internal StateSession(string key, string legacyKey, DocumentState doc, bool fileReadable)
        {
            Key = key;
            LegacyKey = legacyKey;
            Doc = doc;
            FileReadable = fileReadable;
        }

        public string Key { get; }
        internal string LegacyKey { get; }
        public DocumentState Doc { get; }
        public bool FileReadable { get; }
    }

    internal enum ReadStatus
    {
        Missing,
        Ok,
        RecoveredFromBackup,
        CorruptStartedFresh,
        Unreadable
    }

    public static class StateStore
    {
        public const int MaxHistory = 30;
        private const int MaxDocuments = 60;

        private const string MutexName = @"Local\EK_LastSimilar_StateFile";

        public static readonly string FolderPath =
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "EK",
                "LastSimilar");

        private static readonly string FilePath = Path.Combine(FolderPath, "state-csharp.json");
        private static readonly string BackupPath = FilePath + ".bak";

        // Optional Revit API member, read by reflection so no Revit year can fail to compile.
        private static readonly PropertyInfo CreationGuidProperty =
            typeof(Document).GetProperty("CreationGUID", BindingFlags.Public | BindingFlags.Instance);

        // ==================================================================
        // Document keys
        // ==================================================================

        /// <summary>
        /// Per-project key. v3.1 used only ProjectInformation.UniqueId, which is shared by
        /// every project created from the same template, so their histories mixed.
        /// v3.2 appends a project identity: central model path for workshared models
        /// (identical for every local copy), otherwise the document creation GUID or path.
        /// </summary>
        public static string GetDocumentKey(Document doc)
        {
            string legacy = GetLegacyDocumentKey(doc);
            string identity = GetProjectIdentity(doc);
            return string.IsNullOrEmpty(identity) ? legacy : legacy + "|" + identity;
        }

        /// <summary>The v3.1 key, used only to migrate existing history once.</summary>
        internal static string GetLegacyDocumentKey(Document doc)
        {
            try
            {
                if (doc.ProjectInformation != null &&
                    !string.IsNullOrWhiteSpace(doc.ProjectInformation.UniqueId))
                    return doc.ProjectInformation.UniqueId;
            }
            catch { }

            try
            {
                if (!string.IsNullOrWhiteSpace(doc.PathName))
                    return doc.PathName;
            }
            catch { }

            try { return doc.Title ?? "UNKNOWN"; }
            catch { return "UNKNOWN"; }
        }

        private static string GetProjectIdentity(Document doc)
        {
            try
            {
                if (doc.IsWorkshared)
                {
                    ModelPath central = doc.GetWorksharingCentralModelPath();
                    if (central != null)
                    {
                        string p = ModelPathUtils.ConvertModelPathToUserVisiblePath(central);
                        if (!string.IsNullOrWhiteSpace(p))
                            return "central:" + p.Trim().ToLowerInvariant();
                    }
                }
            }
            catch { }

            try
            {
                object value = CreationGuidProperty?.GetValue(doc, null);
                if (value is Guid g && g != Guid.Empty)
                    return "doc:" + g.ToString("N");
            }
            catch { }

            try
            {
                if (!string.IsNullOrWhiteSpace(doc.PathName))
                    return "path:" + doc.PathName.Trim().ToLowerInvariant();
            }
            catch { }

            return null;
        }

        // ==================================================================
        // Read
        // ==================================================================

        public static StateSession Open(Document doc)
        {
            string key = GetDocumentKey(doc);
            string legacyKey = GetLegacyDocumentKey(doc);

            AppState state = null;
            ReadStatus status = ReadStatus.Missing;

            try
            {
                WithFileLock(() => state = ReadFile(out status));
            }
            catch (Exception ex)
            {
                status = ReadStatus.Unreadable;
                RunLog.Add("State read failed: " + ex.Message);
            }

            DocumentState docState = null;
            if (state != null)
                docState = FindDocState(state, key, legacyKey);

            if (docState == null)
                docState = new DocumentState();

            Normalize(docState);
            return new StateSession(key, legacyKey, docState, status != ReadStatus.Unreadable);
        }

        // ==================================================================
        // Global UI preferences
        // ==================================================================

        public static int NormalizeFamilyThumbnailSize(int? value)
        {
            int v = value ?? 24;
            switch (v)
            {
                case 20:
                case 24:
                case 28:
                case 32:
                case 40:
                    return v;
                default:
                    return 24;
            }
        }

        /// <summary>
        /// Reads the Recent 5 visual options in one locked file read.
        /// Older files default to thumbnails ON at 24 px.
        /// </summary>
        public static void GetRecentFiveVisualOptions(out bool useThumbnails, out int thumbnailSize)
        {
            bool localUseThumbnails = true;
            int localThumbnailSize = 24;

            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status == ReadStatus.Unreadable || state == null)
                        return;

                    localUseThumbnails = state.UseFamilyThumbnails ?? true;
                    localThumbnailSize = NormalizeFamilyThumbnailSize(state.FamilyThumbnailSize);
                });
            }
            catch (Exception ex)
            {
                RunLog.Add("Read Recent 5 thumbnail options failed; using defaults: " + ex.Message);
            }

            useThumbnails = localUseThumbnails;
            thumbnailSize = localThumbnailSize;
        }

        /// <summary>
        /// Global troubleshooting switch. Older state files default to OFF.
        /// This read deliberately does not write to RunLog, because it is used to decide
        /// whether RunLog itself should be active.
        /// </summary>
        public static bool GetDiagnosticsEnabled()
        {
            bool enabled = false;
            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status == ReadStatus.Unreadable || state == null)
                        return;

                    enabled = state.DiagnosticsEnabled ?? false;
                });
            }
            catch
            {
                enabled = false;
            }

            return enabled;
        }

        /// <summary>
        /// Writes only the global troubleshooting switch. Never touches document history.
        /// </summary>
        public static bool SaveDiagnosticsEnabled(bool enabled)
        {
            bool ok = false;
            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status == ReadStatus.Unreadable)
                        return;

                    if (state.Documents == null)
                        state.Documents = new Dictionary<string, DocumentState>();

                    state.DiagnosticsEnabled = enabled;
                    state.Version = 8;
                    WriteFile(state, backupCurrent: status == ReadStatus.Ok);
                    ok = true;
                });
            }
            catch
            {
                ok = false;
            }

            return ok;
        }

        /// <summary>
        /// Master height-correction preference shared by all Revit sessions and projects.
        /// Missing fields in old settings files mean ON (backward compatible).
        /// </summary>
        public static bool GetHeightCorrectionsEnabled()
        {
            bool enabled = true;
            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status != ReadStatus.Unreadable && state != null)
                        enabled = state.HeightCorrectionsEnabled ?? true;
                });
            }
            catch { enabled = true; }
            return enabled;
        }

        public static bool SaveHeightCorrectionsEnabled(bool enabled)
        {
            bool ok = false;
            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status == ReadStatus.Unreadable || state == null) return;
                    if (state.Documents == null)
                        state.Documents = new Dictionary<string, DocumentState>();
                    state.HeightCorrectionsEnabled = enabled;
                    state.Version = 8;
                    WriteFile(state, backupCurrent: status == ReadStatus.Ok);
                    ok = true;
                });
            }
            catch { ok = false; }
            return ok;
        }

        /// <summary>Writes only Recent 5 thumbnail preferences. Never touches document history.</summary>
        public static bool SaveRecentFiveVisualOptions(bool useThumbnails, int thumbnailSize)
        {
            int normalizedSize = NormalizeFamilyThumbnailSize(thumbnailSize);
            bool ok = false;
            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);
                    if (status == ReadStatus.Unreadable)
                    {
                        RunLog.Add("Save Recent 5 thumbnail options: state file unreadable, nothing written.");
                        return;
                    }

                    if (state.Documents == null)
                        state.Documents = new Dictionary<string, DocumentState>();

                    state.UseFamilyThumbnails = useThumbnails;
                    state.FamilyThumbnailSize = normalizedSize;
                    state.Version = 8;
                    WriteFile(state, backupCurrent: status == ReadStatus.Ok);
                    ok = true;
                });
            }
            catch (Exception ex)
            {
                RunLog.Add("Save Recent 5 thumbnail options failed: " + ex.Message);
            }
            return ok;
        }

        // ==================================================================
        // Writes (each one = lock, read fresh file, change, write). Never throw.
        // ==================================================================

        /// <summary>Called by the passive tracker for ONE real placement.</summary>
        public static bool RecordPlacement(Document doc, PlacementRecord rec)
        {
            if (doc == null || rec == null || string.IsNullOrWhiteSpace(rec.SymbolUniqueId))
                return false;

            return Mutate(GetDocumentKey(doc), GetLegacyDocumentKey(doc), "Record placement", ds =>
            {
                RecentTypeState e = FindEntry(ds, rec.SymbolUniqueId);
                if (e == null)
                {
                    e = new RecentTypeState
                    {
                        SymbolUniqueId = rec.SymbolUniqueId,
                        ItemKind = string.IsNullOrWhiteSpace(rec.ItemKind) ? RecentItemKinds.Family : rec.ItemKind,
                        HeightMode = HeightModes.Last
                    };
                    ds.History.Add(e);
                }

                ApplyNames(e, rec.FamilyName, rec.TypeName, rec.CategoryName, rec.CategoryIdValue);
                ApplyItemInfo(e, rec);

                // Strictly increasing, so two placements in the same clock tick keep their order.
                long maxTicks = ds.History.Count == 0 ? 0 : ds.History.Max(x => x.LastUsedUtcTicks);
                e.LastUsedUtcTicks = Math.Max(DateTime.UtcNow.Ticks, maxTicks + 1);
                // A real placement makes this type active/recent again in Settings.
                e.SettingsBottom = false;
                e.SettingsBottomOrderTicks = 0;

                if (!RecentItemKinds.IsRoomTag(e.ItemKind) && !RecentItemKinds.IsLine(e.ItemKind) &&
                    rec.LearnedWallHeightFeet.HasValue)
                    e.LastWallHeightFeet = rec.LearnedWallHeightFeet.Value;

                ds.LastSymbolUniqueId = rec.SymbolUniqueId;
                return true;
            });
        }

        /// <summary>First-use "adopt" result of a Last Similar session. Touches nothing else.</summary>
        public static bool SaveLearnedWallHeight(Document doc, FamilySymbol symbol, double heightFeet)
        {
            if (doc == null || symbol == null || symbol is Autodesk.Revit.DB.Architecture.RoomTagType ||
                double.IsNaN(heightFeet) || double.IsInfinity(heightFeet))
                return false;

            PlacementRecord names = BuildRecord(symbol);
            if (names == null)
                return false;

            return Mutate(GetDocumentKey(doc), GetLegacyDocumentKey(doc), "Save learned height", ds =>
            {
                RecentTypeState e = FindEntry(ds, names.SymbolUniqueId);
                if (e == null)
                {
                    e = new RecentTypeState
                    {
                        SymbolUniqueId = names.SymbolUniqueId,
                        ItemKind = RecentItemKinds.Family,
                        HeightMode = HeightModes.Last,
                        LastUsedUtcTicks = DateTime.UtcNow.Ticks
                    };
                    ds.History.Add(e);
                }

                ApplyNames(e, names.FamilyName, names.TypeName, names.CategoryName, names.CategoryIdValue);
                e.LastWallHeightFeet = heightFeet;
                return true;
            });
        }

        /// <summary>Settings window: height mode / fixed height / favorite. Never changes order or Last.</summary>
        public static bool SaveTypeSettings(
            StateSession session,
            RecentTypeState snapshot,
            string heightMode,
            double? standardHeightMm,
            bool favorite,
            bool heightCorrectionEnabled)
        {
            if (session == null || snapshot == null || string.IsNullOrWhiteSpace(snapshot.SymbolUniqueId))
                return false;

            return Mutate(session.Key, session.LegacyKey, "Save type settings", ds =>
            {
                RecentTypeState e = FindEntry(ds, snapshot.SymbolUniqueId);
                if (e == null)
                {
                    e = new RecentTypeState
                    {
                        SymbolUniqueId = snapshot.SymbolUniqueId,
                        LastUsedUtcTicks = snapshot.LastUsedUtcTicks,
                        LastWallHeightFeet = snapshot.LastWallHeightFeet
                    };
                    ApplyNames(e, snapshot.FamilyName, snapshot.TypeName, snapshot.CategoryName, snapshot.CategoryIdValue);
                    ds.History.Add(e);
                }

                e.HeightMode = HeightModes.IsStandard(heightMode) ? HeightModes.Standard : HeightModes.Last;
                e.StandardHeightMm = standardHeightMm;
                if (RecentItemKinds.IsRoomTag(snapshot.ItemKind))
                {
                    e.ItemKind = RecentItemKinds.RoomTag;
                    e.SourceElementUniqueId = snapshot.SourceElementUniqueId;
                    e.HeightMode = HeightModes.Last;
                    e.StandardHeightMm = null;
                    e.LastWallHeightFeet = null;
                }
                e.HeightCorrectionEnabled = !RecentItemKinds.IsRoomTag(snapshot.ItemKind) &&
                    !RecentItemKinds.IsLine(snapshot.ItemKind) ? heightCorrectionEnabled : true;
                e.Favorite = favorite;
                e.SettingsBottom = snapshot.SettingsBottom;
                e.SettingsBottomOrderTicks = snapshot.SettingsBottomOrderTicks;
                return true;
            });
        }


        /// <summary>Settings window "Remove". If it was Last, the next most recent placed type becomes Last.</summary>
        public static bool RemoveEntry(StateSession session, string symbolUniqueId)
        {
            if (session == null || string.IsNullOrWhiteSpace(symbolUniqueId))
                return false;

            return Mutate(session.Key, session.LegacyKey, "Remove type", ds =>
            {
                ds.History.RemoveAll(x => string.Equals(x.SymbolUniqueId, symbolUniqueId, StringComparison.Ordinal));

                if (string.Equals(ds.LastSymbolUniqueId, symbolUniqueId, StringComparison.Ordinal))
                {
                    ds.LastSymbolUniqueId = ds.History
                        .OrderByDescending(x => x.LastUsedUtcTicks)
                        .Select(x => x.SymbolUniqueId)
                        .FirstOrDefault();
                }

                return true;
            });
        }

        private static bool Mutate(string key, string legacyKey, string what, Func<DocumentState, bool> change)
        {
            bool ok = false;

            try
            {
                WithFileLock(() =>
                {
                    AppState state = ReadFile(out ReadStatus status);

                    // A file we cannot READ (locked/denied) must never be overwritten:
                    // that would wipe the history of every other project.
                    if (status == ReadStatus.Unreadable)
                    {
                        RunLog.Add(what + ": state file is locked/unreadable, nothing written.");
                        return;
                    }

                    if (state.Documents == null)
                        state.Documents = new Dictionary<string, DocumentState>();

                    DocumentState ds = FindDocState(state, key, legacyKey) ?? new DocumentState();
                    Normalize(ds);

                    if (!change(ds))
                    {
                        ok = true;
                        return;
                    }

                    Normalize(ds);
                    Trim(ds);
                    ds.LastTouchedUtcTicks = DateTime.UtcNow.Ticks;

                    state.Version = 8;
                    state.Documents[key] = ds;
                    PruneDocuments(state, key);

                    WriteFile(state, backupCurrent: status == ReadStatus.Ok);
                    ok = true;
                });
            }
            catch (Exception ex)
            {
                RunLog.Add(what + " failed (Revit model is NOT affected): " + ex.Message);
            }

            return ok;
        }

        // ==================================================================
        // File I/O
        // ==================================================================

        private static void WithFileLock(Action action)
        {
            Mutex mutex = null;
            bool owned = false;
            try
            {
                try
                {
                    mutex = new Mutex(false, MutexName);
                    try { owned = mutex.WaitOne(3000); }
                    catch (AbandonedMutexException) { owned = true; }
                }
                catch
                {
                    // Lock is best-effort. Continue without it.
                }

                action();
            }
            finally
            {
                if (mutex != null)
                {
                    if (owned)
                    {
                        try { mutex.ReleaseMutex(); } catch { }
                    }
                    mutex.Dispose();
                }
            }
        }

        private static AppState ReadFile(out ReadStatus status)
        {
            if (!File.Exists(FilePath))
            {
                // Interrupted write (main gone, backup present): recover the backup.
                if (File.Exists(BackupPath) &&
                    TryReadBytes(BackupPath, out byte[] orphanBackup) &&
                    TryDeserialize(orphanBackup, out AppState fromOrphan))
                {
                    status = ReadStatus.RecoveredFromBackup;
                    RunLog.Add("State file missing; recovered from backup.");
                    return fromOrphan;
                }

                status = ReadStatus.Missing;
                return new AppState();
            }

            if (!TryReadBytes(FilePath, out byte[] bytes))
            {
                status = ReadStatus.Unreadable;
                return new AppState();
            }

            if (TryDeserialize(bytes, out AppState state))
            {
                status = ReadStatus.Ok;
                return state;
            }

            // Corrupt: keep a copy for inspection, then fall back to the last good backup.
            try
            {
                File.Copy(FilePath, FilePath + ".corrupt-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true);
            }
            catch { }

            if (File.Exists(BackupPath) &&
                TryReadBytes(BackupPath, out byte[] backupBytes) &&
                TryDeserialize(backupBytes, out AppState fromBackup))
            {
                status = ReadStatus.RecoveredFromBackup;
                RunLog.Add("State file was corrupt; recovered from backup (corrupt copy kept).");
                return fromBackup;
            }

            status = ReadStatus.CorruptStartedFresh;
            RunLog.Add("State file was corrupt and no usable backup exists; starting fresh (corrupt copy kept).");
            return new AppState();
        }

        private static bool TryReadBytes(string path, out byte[] bytes)
        {
            for (int attempt = 0; attempt < 4; attempt++)
            {
                try
                {
                    bytes = File.ReadAllBytes(path);
                    return true;
                }
                catch (FileNotFoundException)
                {
                    break;
                }
                catch (DirectoryNotFoundException)
                {
                    break;
                }
                catch (IOException)
                {
                    Thread.Sleep(40); // sharing violation (antivirus, backup, other Revit)
                }
                catch (UnauthorizedAccessException)
                {
                    Thread.Sleep(40);
                }
            }

            bytes = null;
            return false;
        }

        private static bool TryDeserialize(byte[] bytes, out AppState state)
        {
            state = null;
            if (bytes == null || bytes.Length == 0)
                return false;

            try
            {
                var serializer = new DataContractJsonSerializer(typeof(AppState));
                using (var ms = new MemoryStream(bytes))
                    state = serializer.ReadObject(ms) as AppState;

                if (state == null)
                    return false;

                if (state.Documents == null)
                    state.Documents = new Dictionary<string, DocumentState>();

                return true;
            }
            catch
            {
                state = null;
                return false;
            }
        }

        private static void WriteFile(AppState state, bool backupCurrent)
        {
            Directory.CreateDirectory(FolderPath);

            byte[] bytes;
            var serializer = new DataContractJsonSerializer(typeof(AppState));
            using (var ms = new MemoryStream())
            {
                serializer.WriteObject(ms, state);
                bytes = ms.ToArray();
            }

            string temp = FilePath + ".tmp";
            File.WriteAllBytes(temp, bytes);

            if (!File.Exists(FilePath))
            {
                File.Move(temp, FilePath);
                return;
            }

            // Keep one generation of a KNOWN-GOOD file. Never back up a corrupt file over a good backup.
            if (backupCurrent)
            {
                try { File.Copy(FilePath, BackupPath, true); }
                catch { }
            }

            Exception last = null;
            for (int attempt = 0; attempt < 4; attempt++)
            {
                try
                {
                    File.Replace(temp, FilePath, null);
                    return;
                }
                catch (Exception ex)
                {
                    last = ex;
                    Thread.Sleep(40);
                }
            }

            try
            {
                File.Copy(temp, FilePath, true);
                try { File.Delete(temp); } catch { }
            }
            catch
            {
                throw last ?? new IOException("Could not replace the state file.");
            }
        }

        // ==================================================================
        // Document state helpers
        // ==================================================================

        private static DocumentState FindDocState(AppState state, string key, string legacyKey)
        {
            if (state?.Documents == null)
                return null;

            if (state.Documents.TryGetValue(key, out DocumentState ds) && ds != null)
                return ds;

            // One-time migration of v3.1 history. Copied, never shared, so other projects
            // that used the same legacy key are not affected by later changes.
            if (!string.IsNullOrEmpty(legacyKey) &&
                !string.Equals(legacyKey, key, StringComparison.Ordinal) &&
                state.Documents.TryGetValue(legacyKey, out DocumentState legacy) &&
                legacy != null)
            {
                return Clone(legacy);
            }

            return null;
        }

        private static DocumentState Clone(DocumentState source)
        {
            var copy = new DocumentState
            {
                LastSymbolUniqueId = source.LastSymbolUniqueId,
                History = new List<RecentTypeState>()
            };

            if (source.History != null)
            {
                foreach (RecentTypeState e in source.History)
                {
                    if (e == null)
                        continue;

                    copy.History.Add(new RecentTypeState
                    {
                        SymbolUniqueId = e.SymbolUniqueId,
                        ItemKind = e.ItemKind,
                        LineStyleUniqueId = e.LineStyleUniqueId,
                        SourceElementUniqueId = e.SourceElementUniqueId,
                        FamilyName = e.FamilyName,
                        TypeName = e.TypeName,
                        CategoryName = e.CategoryName,
                        CategoryIdValue = e.CategoryIdValue,
                        HeightMode = e.HeightMode,
                        LastWallHeightFeet = e.LastWallHeightFeet,
                        StandardHeightMm = e.StandardHeightMm,
                        HeightCorrectionEnabled = e.HeightCorrectionEnabled,
                        Favorite = e.Favorite,
                        SettingsBottom = e.SettingsBottom,
                        SettingsBottomOrderTicks = e.SettingsBottomOrderTicks,
                        LastUsedUtcTicks = e.LastUsedUtcTicks
                    });
                }
            }

            return copy;
        }

        private static void Normalize(DocumentState docState)
        {
            if (docState.History == null)
                docState.History = new List<RecentTypeState>();

            docState.History.RemoveAll(x => x == null || string.IsNullOrWhiteSpace(x.SymbolUniqueId));

            foreach (RecentTypeState e in docState.History)
            {
                if (string.IsNullOrWhiteSpace(e.ItemKind))
                    e.ItemKind = RecentItemKinds.Family;
            }

            // Distinct by item key: family type or line style + line kind.
            docState.History = docState.History
                .GroupBy(x => x.SymbolUniqueId, StringComparer.Ordinal)
                .Select(g => g.OrderByDescending(x => x.LastUsedUtcTicks).First())
                .ToList();
        }

        private static void Trim(DocumentState state)
        {
            if (state.History.Count <= MaxHistory)
                return;

            state.History = state.History
                .OrderByDescending(x => x.Favorite)
                .ThenByDescending(x => x.LastUsedUtcTicks)
                .Take(MaxHistory)
                .ToList();
        }

        private static void PruneDocuments(AppState state, string keepKey)
        {
            if (state.Documents.Count <= MaxDocuments)
                return;

            List<string> oldest = state.Documents
                .Where(kv => !string.Equals(kv.Key, keepKey, StringComparison.Ordinal))
                .OrderBy(kv => kv.Value == null ? 0 : kv.Value.LastTouchedUtcTicks)
                .Select(kv => kv.Key)
                .Take(state.Documents.Count - MaxDocuments)
                .ToList();

            foreach (string k in oldest)
                state.Documents.Remove(k);
        }

        // ==================================================================
        // History queries (read-only)
        // ==================================================================

        public static RecentTypeState FindEntry(DocumentState state, string symbolUniqueId)
        {
            return state.History.FirstOrDefault(
                x => string.Equals(x.SymbolUniqueId, symbolUniqueId, StringComparison.Ordinal));
        }

        /// <summary>In-memory only (not saved). Used to hand the Last type to placement.</summary>
        public static RecentTypeState GetOrCreateEntry(DocumentState state, FamilySymbol symbol)
        {
            RecentTypeState entry = FindEntry(state, symbol.UniqueId);
            if (entry == null)
            {
                entry = new RecentTypeState
                {
                    SymbolUniqueId = symbol.UniqueId,
                    ItemKind = RecentItemKinds.Family,
                    HeightMode = HeightModes.Last
                };
                state.History.Add(entry);
            }

            RefreshNames(entry, symbol);
            return entry;
        }

        public static FamilySymbol ResolveLastSymbol(DocumentState state, Document doc)
        {
            RecentResolvedItem item = ResolveLastItem(state, doc);
            return item != null && !item.IsLine ? item.Symbol : null;
        }

        /// <summary>Resolves the true most recently placed family type OR straight line style.</summary>
        public static RecentResolvedItem ResolveLastItem(DocumentState state, Document doc)
        {
            if (state == null || doc == null || string.IsNullOrWhiteSpace(state.LastSymbolUniqueId))
                return null;

            RecentTypeState entry = FindEntry(state, state.LastSymbolUniqueId);
            return ResolveEntry(entry, doc);
        }

        private static RecentResolvedItem ResolveEntry(RecentTypeState entry, Document doc)
        {
            if (entry == null || doc == null)
                return null;

            if (RecentItemKinds.IsLine(entry.ItemKind))
            {
                GraphicsStyle style = TryGetLineStyle(doc, entry);
                if (style == null || !style.IsValidObject)
                    return null;

                // Keep the visible name fresh if the office renamed a line style.
                try { entry.TypeName = style.Name ?? entry.TypeName; } catch { }

                return new RecentResolvedItem
                {
                    State = entry,
                    LineStyle = style,
                    SourceCurve = TryGetSourceCurve(doc, entry),
                    Icon = CategoryIconFactory.Create(entry, false)
                };
            }

            FamilySymbol symbol = TryGetSymbol(doc, entry.SymbolUniqueId);
            if (!IsUsableSymbol(symbol))
                return null;

            RefreshNames(entry, symbol);

            return new RecentResolvedItem
            {
                State = entry,
                Symbol = symbol,
                Icon = CategoryIconFactory.Create(entry, false)
            };
        }

        /// <summary>
        /// Chronological by real placement (most recent first), distinct by family type or
        /// line-style+line-kind, only items that can still be resolved in this document.
        /// Favorites do NOT influence this order.
        /// </summary>
        public static List<RecentResolvedItem> GetRecentValid(
            DocumentState state,
            Document doc,
            int count)
        {
            var items = new List<RecentResolvedItem>();

            foreach (RecentTypeState entry in state.History
                         .OrderByDescending(x => x.LastUsedUtcTicks))
            {
                RecentResolvedItem resolved = ResolveEntry(entry, doc);
                if (resolved == null)
                    continue;

                items.Add(resolved);

                if (items.Count >= count)
                    break;
            }

            return items;
        }

        /// <summary>Settings window order: favorites first, then placement recency.</summary>
        public static List<RecentResolvedItem> GetSettingsOrder(
            DocumentState state,
            Document doc)
        {
            // Room Tags keep favorites/order controls; their height controls are disabled.
            // Lines retain their existing Last Similar / Recent 5 behavior.
            List<RecentResolvedItem> all = GetRecentValid(state, doc, MaxHistory)
                .Where(x => !x.IsLine)
                .ToList();

            // Normal Settings rows: favorites first, then true placement recency.
            IEnumerable<RecentResolvedItem> normal = all
                .Where(x => !x.State.SettingsBottom)
                .OrderByDescending(x => x.State.Favorite)
                .ThenByDescending(x => x.State.LastUsedUtcTicks);

            // Manually moved rows always come after normal rows.
            // Old state files may have SettingsBottom=true but no order stamp (0);
            // those stay at the start of the bottom group. Each new button press
            // receives a newer stamp and therefore becomes the absolute last row.
            IEnumerable<RecentResolvedItem> bottom = all
                .Where(x => x.State.SettingsBottom)
                .OrderBy(x => x.State.SettingsBottomOrderTicks)
                .ThenBy(x => x.State.LastUsedUtcTicks);

            return normal.Concat(bottom).ToList();
        }

        /// <summary>Names/category of a symbol as plain data (read-only Revit access).</summary>
        public static PlacementRecord BuildRecord(FamilySymbol symbol)
        {
            if (!IsUsableSymbol(symbol))
                return null;

            try
            {
                var rec = new PlacementRecord
                {
                    SymbolUniqueId = symbol.UniqueId,
                    ItemKind = symbol is Autodesk.Revit.DB.Architecture.RoomTagType
                        ? RecentItemKinds.RoomTag : RecentItemKinds.Family,
                    FamilyName = symbol.Family?.Name ?? "",
                    TypeName = symbol.Name ?? ""
                };

                Category category = symbol.Category;
                if (category != null)
                {
                    rec.CategoryName = category.Name ?? "";
                    rec.CategoryIdValue = category.Id.Value;
                }

                return rec;
            }
            catch
            {
                return null;
            }
        }


        /// <summary>Builds a history record for one straight Detail Line or Model Line.</summary>
        public static PlacementRecord BuildLineRecord(CurveElement curve)
        {
            if (!IsUsableStraightLine(curve))
                return null;

            try
            {
                GraphicsStyle style = curve.LineStyle as GraphicsStyle;
                if (style == null || !style.IsValidObject || string.IsNullOrWhiteSpace(style.UniqueId))
                    return null;

                string kind = curve is DetailCurve
                    ? RecentItemKinds.DetailLine
                    : RecentItemKinds.ModelLine;

                string key = "LINE|" + kind + "|" + style.UniqueId;

                return new PlacementRecord
                {
                    SymbolUniqueId = key,
                    ItemKind = kind,
                    LineStyleUniqueId = style.UniqueId,
                    SourceElementUniqueId = curve.UniqueId,
                    FamilyName = curve is DetailCurve ? "Detail Line" : "Model Line",
                    TypeName = style.Name ?? "Line",
                    CategoryName = "Lines",
                    CategoryIdValue = (long)BuiltInCategory.OST_Lines
                };
            }
            catch
            {
                return null;
            }
        }

        private static GraphicsStyle TryGetLineStyle(Document doc, RecentTypeState entry)
        {
            if (doc == null || entry == null)
                return null;

            if (!string.IsNullOrWhiteSpace(entry.LineStyleUniqueId))
            {
                try
                {
                    GraphicsStyle byUid = doc.GetElement(entry.LineStyleUniqueId) as GraphicsStyle;
                    if (byUid != null && byUid.IsValidObject)
                        return byUid;
                }
                catch { }
            }

            // Fallback for a migrated/renamed project where UniqueId could not resolve.
            if (!string.IsNullOrWhiteSpace(entry.TypeName))
            {
                try
                {
                    return new FilteredElementCollector(doc)
                        .OfClass(typeof(GraphicsStyle))
                        .Cast<GraphicsStyle>()
                        .FirstOrDefault(x =>
                        {
                            try { return string.Equals(x.Name, entry.TypeName, StringComparison.Ordinal); }
                            catch { return false; }
                        });
                }
                catch { }
            }

            return null;
        }

        private static CurveElement TryGetSourceCurve(Document doc, RecentTypeState entry)
        {
            if (doc == null || entry == null || string.IsNullOrWhiteSpace(entry.SourceElementUniqueId))
                return null;

            try
            {
                CurveElement c = doc.GetElement(entry.SourceElementUniqueId) as CurveElement;
                return IsUsableStraightLine(c) ? c : null;
            }
            catch
            {
                return null;
            }
        }

        internal static bool IsUsableStraightLine(CurveElement curve)
        {
            try
            {
                if (curve == null || !curve.IsValidObject)
                    return false;

                if (!(curve is DetailCurve) && !(curve is ModelCurve))
                    return false;

                if (!(curve.GeometryCurve is Line))
                    return false;

                Element style = curve.LineStyle;
                return style is GraphicsStyle && style.IsValidObject;
            }
            catch
            {
                return false;
            }
        }

        private static FamilySymbol TryGetSymbol(Document doc, string uniqueId)
        {
            if (string.IsNullOrWhiteSpace(uniqueId))
                return null;

            try { return doc.GetElement(uniqueId) as FamilySymbol; }
            catch { return null; }
        }

        internal static bool IsUsableSymbol(FamilySymbol symbol)
        {
            try
            {
                return symbol != null &&
                       symbol.IsValidObject &&
                       symbol.Family != null &&
                       !symbol.Family.IsInPlace;
            }
            catch
            {
                return false;
            }
        }

        private static void RefreshNames(RecentTypeState entry, FamilySymbol symbol)
        {
            PlacementRecord rec = BuildRecord(symbol);
            if (rec != null)
                ApplyNames(entry, rec.FamilyName, rec.TypeName, rec.CategoryName, rec.CategoryIdValue);
            if (symbol is Autodesk.Revit.DB.Architecture.RoomTagType)
            {
                entry.ItemKind = RecentItemKinds.RoomTag;
                entry.HeightMode = HeightModes.Last;
                entry.LastWallHeightFeet = null;
                entry.StandardHeightMm = null;
            }
        }

        private static void ApplyItemInfo(RecentTypeState entry, PlacementRecord rec)
        {
            if (entry == null || rec == null)
                return;

            entry.ItemKind = string.IsNullOrWhiteSpace(rec.ItemKind)
                ? RecentItemKinds.Family
                : rec.ItemKind;

            if (RecentItemKinds.IsLine(entry.ItemKind) || RecentItemKinds.IsRoomTag(entry.ItemKind))
            {
                entry.LineStyleUniqueId = RecentItemKinds.IsLine(entry.ItemKind) ? rec.LineStyleUniqueId : null;
                entry.SourceElementUniqueId = rec.SourceElementUniqueId;

                // Height controls never apply to lines or Room Tags.
                entry.HeightMode = HeightModes.Last;
                entry.LastWallHeightFeet = null;
                entry.StandardHeightMm = null;
            }
            else
            {
                entry.ItemKind = RecentItemKinds.Family;
                entry.LineStyleUniqueId = null;
                entry.SourceElementUniqueId = null;
            }
        }

        private static void ApplyNames(
            RecentTypeState entry,
            string family,
            string type,
            string category,
            long? categoryId)
        {
            if (!string.IsNullOrEmpty(family)) entry.FamilyName = family;
            if (!string.IsNullOrEmpty(type)) entry.TypeName = type;
            if (!string.IsNullOrEmpty(category)) entry.CategoryName = category;
            if (categoryId.HasValue) entry.CategoryIdValue = categoryId;
        }
    }
}

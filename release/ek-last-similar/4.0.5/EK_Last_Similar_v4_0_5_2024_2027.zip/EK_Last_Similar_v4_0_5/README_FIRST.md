# EK Last Similar 4.0.5 — Revit 2024–2027

A cleanup release for testing. **Placement, height correction, history, Recent 5 and Room Tag behaviour are unchanged from 4.0.4.1.** Your saved history, favorites and heights are kept.

## What changed in 4.0.5

**Settings window reorganized.** Related options are now grouped together instead of being split across the header, the side and the bottom of the window:

- **Recent types** tab: the list of types on the left. Everything about the selected type is in one panel on the right: name and family, **Favorite**, then **Placement height** (*Auto-adjust height for this type*, *Last placed height* or *Fixed height … cm*). Below the list: **Remove from list**, **Move to bottom** and **Place**.
- **General** tab: options that apply to every type and project, in three groups: **Placement heights** (*Auto-adjust heights (all types)*), **Recent 5 palette** (thumbnails and size) and **Troubleshooting** (diagnostic log).
- If *Auto-adjust heights (all types)* is off, the Recent types panel shows a short note saying so.
- Same controls and same rules as before: **Save** keeps changes, **Close** (or Esc) discards them, **Place** saves and then places. Double-click or Enter still places.

**New ribbon icons** (see `ICON_PREVIEW.png`):

- **Last Similar**: a "repeat" arrow around a family block, meaning *place the last type again*.
- **Recent 5**: a short list with a blue **5** badge, meaning *pick one of the last 5*.
- **Settings**: now has a gear icon (before, it had none).

**Bug fixes**

- Settings: changing a type to *Fixed height* (or back to *Last placed height*) and turning off *Auto-adjust height for this type* at the same time lost the height change. The height choice is now kept; it applies again when auto-adjust is turned back on, as the window already promised. A fixed height is still only required to be valid while auto-adjust is on.
- Settings: if a project's history held only Detail/Model Lines (which have no settings), Settings opened an empty window. It now shows the usual "nothing remembered yet" message.
- Last Similar for lines: if Revit's Create Similar could not be started, your selection was left replaced by the seed line. It is now restored (Room Tags already did this).
- Recent 5: **Shift+Tab** now moves the highlight up (it moved down, like Tab).
- Minor code cleanup (one dead statement, two duplicate handlers merged, settings file version stamped consistently).
- Verification fixtures: the Room Tag and diagnostics test programs had not been updated for 4.0.4 and no longer compiled/passed; they are updated so the existing checks run again.

## Install

1. Close every Revit session.
2. Extract the entire ZIP to a normal folder.
3. Run **INSTALL_EK_LAST_SIMILAR.cmd**.
4. Wait for the installer to report success for every detected Revit version, then reopen Revit.

This is a **source-and-build installer**, like the previous package. It builds the production DLL for each installed Revit version using that installation's API. It does not contain precompiled production DLLs. The .NET 10 SDK supports the package's build targets; the installer checks installed SDKs. CMD shows short progress lines (one per Revit version); compiler details go into `_Payload\INSTALL_EK_LAST_SIMILAR.log`. If a build fails, relevant errors are shown.

The installer preserves existing EK settings/history. No shortcut reassignment is required. A failed or unfinished build does not prove the new version was installed; the October 19 diagnostic log still showed 4.0.1 running.

## Carried forward from 4.0.4.1: optional height correction and clean installation screen

In **EK Last Similar > Settings** (4.0.5: *Auto-adjust heights (all types)* is on the **General** tab; the per-type switch is in the selected-type panel of the **Recent types** tab):

- **Auto-adjust heights (all types)** is the master switch. ON (default): the previous correction behavior is used for every Revit project; OFF: LL and Recent 5 still place elements, but no height or automatic level adjustment is attempted by EK on any newly placed family.
- Select a family and uncheck **Auto-adjust height for this type** to disable correction for just that saved family type in this project. Other types keep their normal behavior. This preference is retained for that type when it is placed again.
- Re-enable either option at any time. Saved fixed height, learned-height preference, favorites, and Recent 5 history are not reset or deleted. Existing placed elements are never changed retroactively.
- Room Tags and lines do not have height controls. Ceilings, floors and horizontal hosts still stay untouched even when correction is enabled.
- Normal CMD output shows progress and build success only; full compiler warnings remain in the installer logfile. On a build error, a short error excerpt appears on screen. All previous safe-install/rollback mechanisms remain.

The new controls are staged like other settings: **Save** persists, **Close** discards, and **Place** saves before placing.

## Carried forward unchanged from 4.0.3

- **Vertical hosts:** resolve the actual host face through its geometry-instance transforms and the link transform. Check the target lies within that same face before attempting a correction. Preserve mounting offset, XY position, host/face identity, physical orientation and flip states; reject or roll back an unsafe correction. Floors, ceilings, roofs and horizontal faces remain excluded.
- **Room Tags:** actual room-tag placements update Last and Recent 5. LL requests native placement of the remembered `RoomTagType`. If that type cannot be queued directly, it uses native Create Similar from an exact-type tag in the current view. Revit retains its room selection, orientation, leader controls and Undo. Local and linked rooms use Revit's native capabilities and visibility rules. Tags have no height correction; favorites remain available.
- **Diagnostics:** optional per-process/version/run traces are retained to investigate the older unexplained outside-EK events. Troubleshooting remains off by default and follows your existing setting.

**Height reference is unchanged:** 110 cm means 110 cm above the level selected by the existing rule: the highest host-document level at or below the placement point. In the supplied October 19 examples, that is the level at 590 mm, so the target absolute Z is 1690 mm. This release does not redefine 110 cm as a ground-floor absolute elevation.

## Validation and limits

**4.0.5 checks (this package):** full builds including the real XAML for Revit 2024, 2025, 2026 and 2027 with 0 errors and 0 warnings (against the public Revit API reference packages), all 72 bundled fixture checks passing (32 face/host, 22 Room Tag/history, 18 diagnostics) and the structural settings check passing. See `Verification/results/v4.0.5-*.log`. These are still not a live Revit test; the installer does the real build on your PC against your Revit.


The **original 4.0.3 package** reported 72 focused checks: 32 face/host safety checks, 22 Room Tag/history integration checks and 18 diagnostic checks. Its C# compilation checks were against all four Revit API versions and its PowerShell scripts parsed without errors. **Those are v4.0.3 results, not new v4.0.4.1 build results.** v4.0.4.1 source and XAML have been checked structurally in this environment, which does not contain the Windows Revit APIs or .NET SDK needed for a production build.

These are code/fixture checks, **not a live Revit model test or a complete Windows WPF build**. Native placement, the actual glass panel geometry and Undo still need validation in Revit. The installer performs the complete Windows production build. See **DIAGNOSIS_AND_CHANGES.md** and **Verification/README.md** for evidence and limits.

The log proves the newer glass placements were captured and then rolled back at face verification. The missing geometry transform is a confirmed code defect; its exact role in your panel has not been measured in a live model. The cause of the original outside-EK events remains unproven.

## First Revit check

Place a switch on a regular linked wall and on the same linked glass panel, finish placement, and check the resulting height relative to the selected level, host and orientation. Test Undo/Redo. A target outside the panel must remain unchanged. Check a ceiling/floor placement remains unchanged.

Place a Room Tag normally, then use LL and Recent 5 to place that type again. Check a visible linked room too. If host and linked rooms overlap at the click, native Revit favors the host-model room. Room tagging must be available in the current view.

If a glass correction still skips or rolls back, enable the existing Troubleshooting setting, repeat once, and run **COLLECT_DIAGNOSTICS.cmd**. This release contains the diagnostics already; no separate diagnostic installer is needed.

# Offline 3D PDF 0.5.3

- Viewer: [CHANGES-0.5.3-VIEWER.md](CHANGES-0.5.3-VIEWER.md)
- Exporter: [CHANGES-0.5.3-EXPORTER.md](CHANGES-0.5.3-EXPORTER.md)
- Revit acceptance steps: [ACCEPTANCE-TEST-0.5.3.md](ACCEPTANCE-TEST-0.5.3.md)

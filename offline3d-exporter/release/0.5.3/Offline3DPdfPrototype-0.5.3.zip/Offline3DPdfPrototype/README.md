# Offline 3D PDF v0.5.2 experimental

**Extract ZIP → close Revit/viewer → double-click INSTALL.cmd.** Actual prebuilt Windows x64 viewer and six Revit exporter variants are included. Released FastPDF, ClickTo3D and PDF associations remain separate.

**v0.5.2 is for cropped engineering review exports.** The default is the actual view crop horizontally, with the nearest levels below/above for plans and RCPs. Medium is the default export and viewer quality; the export dropdown includes Quick, Low, Medium, High and Ultra. Quick export selects Coarse geometry/LOD 1 and skips precomputed feature edges while retaining real geometry, colors and element identity. Native speed is not measured here.

All up and All down extend only the vertical range. Include geometry outside the view crop starts unchecked and requires a separate Yes/No warning, default No. Outside-crop permission does not automatically select all height. Host element bounds, a native section box and transformed mesh/triangle tests exclude off-crop data, including linked batches that lack individual element callbacks. Original intersecting boundary triangles are retained without splitting. Completed instance batches flush immediately to the shared spool; material reads are cached.

Generate preview closes the options modal before calling Revit image export, then returns to the same options with the image or visible error. Its image column explicitly fills the available space. Actual native preview rendering and input remain Windows/Revit checks.

**v0.5.2 fixes the 64 MiB scene cutoff throughout the pipeline:** up to 512 MiB for geometry, with metadata separately bounded at 64 MiB each, total resources 640 MiB and the PDF 1 GiB. Larger scenes are delivered to WebView2 as a local binary stream rather than a huge base64 message. Both engines expand feature edges only when a section needs the mesh. No automatic detail reduction or element removal is introduced. This is a larger finite capacity, not general model streaming or an unlimited guarantee.

Preview generation now isolates each request's PNG files, accepts native names/extensions, reports native failures on screen, forces an image repaint and retains diagnostics. Native image rendering still needs Revit acceptance.

Repeated items now share indexed local geometry by content, with placements for rotations and correctly wound mirror prototypes. Changed dimensions/cuts/materials remain distinct. Unique geometry is spooled to disk, and bounds accumulate incrementally. The old 1.5-million placed-triangle cutoff is removed; the existing file-size and bounded metadata limits remain.

Export options open before the full element scan or image render. Generate preview is optional/cached. Temporary previews hide level/datum graphics and fit model-only bounds, including transformed links. Actual preview rendering time and DPI/image/control sizes are logged separately. Native Windows/Revit centering and visibility remain untested here.

Both viewers retain shared indexed geometry, apply GPU clip planes and lazily build solid cuts only from placements crossing the box planes. Babylon can hardware-instance repeated nodes; Three shares buffers with ordinary mesh placements. The model still uses orthographic views, white backgrounds, small blue paired grips, selected-object orbit, ViewCube/Home, properties and measurement.

The canvas is larger with collapsed Settings/Tools overlays and floating properties. Pan tracks screen pixels at every zoom; wheel zoom is faster. Settings show editable saved defaults: **10 ft square, 10 ft above, 0.5 ft below**, with Feet/Meters conversion. Reset box restores the saved sizes at the clicked point without changing orientation.

Crop-only is the default; outside-crop data requires explicit confirmation. Existing native PDF rendering, tiles/cache and printing remain the current supplied `fastpdf/src/` implementation. See START-WINDOWS.md and TEST-REPORT.md for real Revit acceptance, actual automated results and limits. No Windows/Revit runtime or physical-card performance pass is claimed.

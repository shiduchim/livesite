# Offline3D package schema 1

Standard PDF `/Names /EmbeddedFiles` entries (not a trailing ZIP or PDF 3D annotation):

| Name | Payload |
| --- | --- |
| `offline3d.manifest.json` | version, package UUID, internal feet frame, required capabilities, synthetic flag, bounded export coverage, exact exporter/update evidence, exclusions and resource table |
| `registration.json` | page geometry and identity, level ProjectElevation, model→sheet/PDF/graphics matrices, crop polygon, registration status/residual and independent control evidence |
| `identities.json` | document identity, element UniqueId, optional link-instance identity, GLB mesh name |
| `scene.glb` | one bounded static, self-contained neutral shaded scene |

All JSON is UTF-8/camelCase. Matrices are row-major, double precision, multiplying column vectors; A*B applies B first. Host XYZ and level plane are Revit internal feet. Graphics `(x,y,z)=.3048*(X-originX,Z-originZ,-(Y-originY))`, invertible, right-handed Y-up metres. Only graphics vertices are float. PDF coordinates are raw default page user units, before page rotation; page boxes, Rotate and UserUnit are explicit. Renderer device/display coordinate inversion is adapter-owned.

Resource descriptors use stable ids (`scene.root` leaves room for future spatial chunks), kind, safe attachment name, size, SHA-256. Unknown required capabilities/schema, duplicate names/ids, paths/URIs, invalid/nonfinite values, missing entries, mismatched hashes, unregistered clicks and oversized files are rejected. Current limits: PDF 128 MiB; one resource 32 MiB; declared package total 64 MiB; manifest 64 KiB; at most 128 attachments. Only uncompressed or single FlateDecode streams are supported. Flate output is bounded. Unrelated attachments remain PDF data and are preserved by the writer.

GLB requires version 2 and exactly local JSON/BIN chunks. No URI, image/texture resource, extension, animation, skin or decoder download is allowed. Installed scripts/engines own executable content. WebView2 restricts navigation/messages/resources to an exact local virtual origin and installed allowlisted assets. PDF.js does not execute PDF JavaScript; FastPDF's original worker PDFium path is unchanged. All hashes are integrity checks, not authentication.

Writer closes the temporary PDF before reopening/validating all resources and page geometry, then atomically replaces/moves the destination on the same filesystem. Colliding package attachments are rejected. Saved model/mapping data lives inside the PDF; viewer cache contains no authoritative state. This milestone is read-only and does not persist camera/box preferences into the PDF.

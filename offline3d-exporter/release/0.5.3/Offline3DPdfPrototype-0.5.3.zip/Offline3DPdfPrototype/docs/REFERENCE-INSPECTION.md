# Inputs inspected

- Implementation specification: `Codex_3DPDF_Prototype_Prompt.md`.
- `ClickTo3D_1.0.0_FINAL_10.22.26 submitted.zip`: actual source inspected under `ClickTo3D_1.0.0_Final/src/ClickTo3D/`.
  - `Core/ClickTo3DSettings.cs` lines 16–20: internal feet; defaults SquareSize=10, HeightBelow=0.5, HeightAbove=10. Validation allows below=0; finite positive width/above. Unit conversion factor 0.3048.
  - `Commands/ClickTo3DCommand.cs` lines 170–189: plan uses `GenLevel.ProjectElevation`, half-width about the click, min/max level-minus-below/level-plus-above. These facts informed independently implemented shared geometry. No settings persistence, selection, licensing, production view creation or UI was copied.
- `livesite-fastpdf-v1.2.0.zip`: current integration input is explicitly `fastpdf/src/`. Inspected PdfViewport, DocumentSession, PDFium interop, render workers/pool, IPC, app settings and single-instance paths. Legacy source was not used for implementation. Original renderer retained.
- `Codex_3DPDF_Prototype_Handoff.zip` and `EK_FastPDF_Setup_v1.2.exe`: exceed the transfer tool's 32 MiB limit. Not downloaded or executed. Research/00_START_HERE were not otherwise separately accessible. Installer filenames were not used to infer architecture.
- Existing `/workspace/codex` is an unrelated EK Quick View repository. It was not changed or used as FastPDF/ClickTo3D source.

Licensed Revit SDK/runtime and a test RVT/PDF pair were not present. For v0.2, the explicitly requested build-dependency investigation found pinned Nice3point NuGet reference-only packages; their embedded licenses were inspected and the six exporter variants cross-compiled successfully. Reference DLLs are not redistributed. Revit execution remains a local acceptance step; see BUILD-DEPENDENCIES.md.

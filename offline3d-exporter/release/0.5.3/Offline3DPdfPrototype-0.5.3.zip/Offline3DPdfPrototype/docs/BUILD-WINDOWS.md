# Windows build and installation

Use the launchers at the ZIP root. See `START-WINDOWS.md`.

- `INSTALL.cmd` installs the included prebuilt application, without any SDK or compilation.
- `BUILD_AND_INSTALL.cmd` is the temporary automatic local-build fallback. It asks permission for required Microsoft SDK/build downloads, detects installed Revit/API paths and builds/installs automatically.
- `UNINSTALL.cmd` removes only this prototype.

Do not use the older developer registration/build instructions from the original v0.1 prototype. The exporter now uses an Application manifest and creates a ribbon button. The standalone source-only diagnostic viewer remains available for engineering work; the installed application is the current FastPDF integration.

The Windows setup path, download/signature checks and real Revit execution remain untested here. Six exporter variants and the self-contained Windows application were cross-built, and setup helper functions were tested under PowerShell 7/Linux. This distinction is intentional.

# Automatic registration, v0.2

The installed exporter no longer requires manual controls or a command-line finalization step. It creates two native exports with identical PDF settings: a clean drawing, and the same sheet with 25 temporary colored L markers at known sheet coordinates. Markers/categories are inside a transaction group that is rolled back; meshes come from a separate temporary 3D view whose group is also rolled back.

A separate process walks actual PDFium paths and nested forms, composes full transforms, identifies each known marker's L corner and performs affine sheet→PDF calibration. Twelve points are fit and thirteen are independent checks. Maximum model-plane residual must be <=1 mm. Missing/ambiguous markers, crop/page mismatches, palette collisions and outliers cause a failure.

The known markers are removed only from an in-memory comparison copy. That copy must render pixel-identically to the clean export, at a recorded bounded resolution up to 2 pixels per PDF display point and 12 million pixels. The delivered drawing is the untouched clean native PDF. The appearance check is raster-bounded, not a proof of vector identity at every possible zoom; a real-model independent acceptance test is still required.

The PDF registration resource contains the raw fit/check coordinates, residual, mapping and appearance-comparison evidence. Rendering/page geometry comes from the actual PDF, not inferred title-block/viewport bounds. Numeric registration remains separate from human click accuracy; the viewer has no vector snapping.

The temporary sheet-detail-curve creation/native export path has not been run in Revit here. It may reject unsupported API/view/export behavior; it must not silently enable incorrect mapping. On failure, existing destination bytes are preserved and diagnostics remain in the temporary export folder.

See `START-WINDOWS.md` for the real-model acceptance checklist. The older `Tool calibrate` API remains in source solely for developer investigations; it is not part of the installed workflow.

# Rendering engines — v0.5.2 experimental

The current package offers **Babylon.js WebGL2 (default)** and **Three.js** only. Both use orthographic cameras and white backgrounds. PlayCanvas, Filament, progressive Photo Mode and WebGPU selection are removed from the runtime payload/UI at the user's request. DWF and walk mode are cancelled.

| Engine | Current implementation |
| --- | --- |
| Babylon.js 7.54.3 | Local WebGL2, balanced Shaded fill, PBR Realistic, optional shadows/SSAO, precomputed dark edges, antialiasing/supersampling and static world matrices/shared instances |
| Three.js 0.186.1 | Local WebGL2, neutral image-based lighting, Shaded/PBR modes, optional shadows/SSAO, precomputed edges and supersampling; conservative default shadows off to avoid the reported artifacts |

Low/Medium/High/Extra High control rendering resolution and supported effects. High is the new export geometry default; viewing defaults to Extra High. Extra High is this viewer's highest preset, not the highest rendering engine available globally. Exact Revit/Navisworks appearance parity and physical GPU performance are unproven. A strong GPU can improve resolution/effects; the driver/Windows select the adapter.

Both engines share indexed GLB, metadata, clipped/capped section geometry and camera controls: blue face grips, smaller cube/Home, regular-speed cursor zoom/pan, double-click focus and selection tools. Caps use representative materials and closed contours, with holes preserved where valid. Native concrete and compound cut hatches are metadata only. Textures/procedural assets are absent. Precomputed feature edges are toggleable; older unindexed files use the legacy fallback where available.

Navisworks has Autodesk interactive graphics and separate photorealistic workflows. Its SDK controls do not establish redistribution rights for a standalone offline viewer, and no Navisworks engine is embedded here. See Autodesk's [Navisworks API overview](https://aps.autodesk.com/developer/overview/navisworks-api).

Local browser checks exercise actual engines under Linux Chromium/SwiftShader. They are neither physical-card benchmarks nor evidence of Autodesk shader equivalence. See TEST-REPORT.md and START-WINDOWS.md for completed tests and native acceptance.

v0.5.2 keeps unique geometry/index buffers and node transforms. Babylon can hardware-instance the shared nodes; Three shares buffers with ordinary mesh placements and GPU planes. Caps are lazy crossing-instance work. The former whole-scene expansion/re-encoding path is retired from the installed runtime. See TEST-REPORT.md for storage/work guards and unmeasured physical GPU performance.

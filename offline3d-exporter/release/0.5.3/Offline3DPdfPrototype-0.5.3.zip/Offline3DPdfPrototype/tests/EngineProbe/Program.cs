using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using EKFastPDF.Core.Native;
using EKFastPDF.Core.Rendering;
if(WorkerHost.IsWorkerInvocation(args))return WorkerHost.Run(args);
using var pool=new RenderPool(new RenderPoolOptions{WorkerExecutable=Environment.ProcessPath!,WorkerCount=1});
int id=pool.RegisterDocument(args[0]);var sw=Stopwatch.StartNew();var info=await pool.OpenDocumentAsync(id);double open=sw.Elapsed.TotalMilliseconds;
var times=new List<double>();var queues=new List<double>();string? hash=null;
for(int i=0;i<51;i++){
 var completion=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
 pool.Submit(new RenderJob(id,0,1024,1325,0,0,1024,1325,1,0,(_,r)=>{
  if(r.Outcome!=JobOutcome.Completed){completion.SetException(new Exception(r.Error));return;}
  var bytes=new byte[1024*1325*4];for(int row=0;row<1325;row++)Marshal.Copy(r.Pixels+row*r.Stride,bytes,row*1024*4,1024*4);
  var h=Convert.ToHexString(SHA256.HashData(bytes));if(hash!=null&&hash!=h){completion.SetException(new Exception("Unstable raster"));return;}hash=h;
  if(i>0){times.Add(r.RenderMs);queues.Add(r.QueueMs);}completion.SetResult(true);
 }));await completion.Task;
}
times.Sort();queues.Sort();Console.WriteLine(JsonSerializer.Serialize(new{pdfium="157.0.8100",openMs=open,residentRenderMedianMs=times[25],residentRenderP95Ms=times[47],queueMedianMs=queues[25],rasterSha256=hash,viewerHarnessWorkingSetBytes=Process.GetCurrentProcess().WorkingSet64,runs=50}));return 0;

"""Exercise the exact 3D-only entry point bundled into FastPDF; no PDF.js used."""
import asyncio,base64,json,pathlib,sys
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIXTURE=pathlib.Path('/workspace/work/browser-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await browser.new_context(offline=True,viewport={'width':500,'height':760});page=await context.new_page();events=[];errors=[];requested=[]
  page.on('pageerror',lambda e:errors.append(str(e.stack)))
  page.on('console',lambda m:print('BROWSER',m.type,m.text,flush=True) if m.type=='error' else None)
  async def route(r):
   from urllib.parse import urlparse
   u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve();requested.append(u.path)
   if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
   await r.fulfill(body=f.read_bytes(),content_type={'mjs':'text/javascript','js':'text/javascript','html':'text/html','css':'text/css','env':'application/octet-stream','wasm':'application/wasm'}[f.suffix[1:]])
  await context.route('**/*',route)
  await page.expose_binding('bridgeSend',lambda _,m:events.append(m))
  await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
  print('Opening panel',flush=True);await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback')
  print('Loading scene',flush=True);await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIXTURE/'scene.glb').read_bytes()).decode()})
  print('Positioning box',flush=True);await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.572,'y':0,'z':-3.048,'width':3.048,'above':3.048,'below':.1524})
  await page.wait_for_function("document.getElementById('metrics').textContent.includes('meshes')")
  print('Rendering ready',flush=True);canvas=page.locator('#scene');rect=await canvas.bounding_box();await page.mouse.move(rect['x']+200,rect['y']+250);await page.mouse.down();await page.mouse.move(rect['x']+270,rect['y']+280,steps=12);await page.mouse.up();await page.mouse.wheel(0,120)
  await page.evaluate("async()=>{window.r=(await import('/three.mjs')).testing.renderer;}")
  await page.wait_for_function('r.sections.caps.length > 0')
  actual=await page.evaluate("()=>({caps:r.sections.caps.length,open:r.sections.openContours,handles:r.handles.length,color:r.models.find(m=>m.name==='partition').metadata.original.albedoColor.asArray(),quality:r.options.quality,scale:r.engine.getHardwareScalingLevel(),renderer:r.engine.getGlInfo().renderer})")
  assert actual['caps']>0 and actual['handles']==6 and actual['open']==0,actual
  assert actual['color'][2]>actual['color'][0]*10,actual
  assert actual['quality']=='ultra' and actual['scale']<=.5,actual
  print('Worker caps and colored material verified',actual,flush=True)
  for quality in ['low','medium','high','ultra']:
   await page.locator('#quality').select_option(quality)
   assert await page.evaluate('r.options.quality')==quality
  for style in ['shaded','colors','wireframe','realistic']:
   await page.locator('#style').select_option(style)
   assert await page.evaluate('r.options.style')==style
  await page.locator('#quality').select_option('low')
  before=await page.evaluate('r.bounds.max[0]')
  point=await page.evaluate("()=>{const B=BABYLON,h=r.handles.find(h=>h.axis===0&&h.side==='max'),vp=r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight()),p=B.Vector3.Project(h.mesh.position,B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),q=B.Vector3.Project(h.mesh.position.add(new B.Vector3(1,0,0)),B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/vp.width*rect.width,y:rect.y+p.y/vp.height*rect.height,dx:q.x-p.x,dy:q.y-p.y};}")
  import math
  length=math.hypot(point['dx'],point['dy'])
  await page.mouse.move(point['x'],point['y']);await page.mouse.down();await page.mouse.move(point['x']+point['dx']/length*45,point['y']+point['dy']/length*45,steps=8);await page.mouse.up()
  after=await page.evaluate('r.bounds.max[0]')
  assert abs(after-before)>.01,(before,after,point,events)
  assert any(m['type']=='bounds' and m.get('final') for m in events),events
  await page.evaluate("async()=>{window.savedBackend=r.backend;window.savedBox=JSON.stringify(r.bounds);const saved=navigator.gpu;Object.defineProperty(navigator,'gpu',{value:undefined,configurable:true});try{await r.setBackend('webgpu');throw new Error('Expected unsupported WebGPU rejection');}catch(e){if(r.backend!=='webgl')throw e;}finally{Object.defineProperty(navigator,'gpu',{value:saved,configurable:true});}}")
  await page.wait_for_function('r.loaded && r.sections.caps.length > 0')
  assert await page.evaluate('r.backend')=='webgl'
  await page.locator('#undock').click();assert any(m['type']=='undock' for m in events)
  await page.locator('#quality').select_option('ultra')
  await page.locator('#reset').click();await page.locator('#below').fill('0');await page.locator('#below').dispatch_event('change');await page.wait_for_timeout(150)
  assert any(m['type']=='size' and m['below']==0 for m in events),events
  print('Capturing panel',flush=True);await page.wait_for_timeout(1000);await page.screenshot(path=str(ROOT/'samples/fastpdf-3d-panel-preview.png'))
  await page.locator('#hide').click();await page.wait_for_timeout(100);assert any(m['type']=='hide' for m in events)
  assert not errors and not any(m['type']=='error' for m in events),(errors,events)
  assert not any('pdf.' in f or 'pdfjs' in f for f in requested),requested
  print(json.dumps({'passed':['exact FastPDF 3D-only entry loads offline','real GLB rendering and clipping','orbit/wheel input and Reset complete without script errors','Below level zero accepted by UI message','Hide requested','no PDF renderer loaded in 3D panel','source material colors survive GLB loading','six face handles present','real pointer drag stretches one face and sends final synchronized bounds','background section worker emits closed solid caps','four quality presets and four display styles work','Undock request emitted','unavailable WebGPU restores working WebGL backend and box','Extra High supersampling and graphics renderer reported'],'requestedInstalledAssets':requested,'platform':'Linux Chromium/SwiftShader; simulated native host'},indent=2))
  await browser.close()
asyncio.run(main())

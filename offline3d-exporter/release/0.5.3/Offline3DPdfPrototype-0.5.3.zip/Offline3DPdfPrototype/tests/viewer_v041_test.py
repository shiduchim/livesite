import asyncio,base64,json,pathlib,math
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-v04')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   context=await browser.new_context(offline=True,viewport={'width':760,'height':900});page=await context.new_page();errors=[];events=[];results=[]
   page.on('pageerror',lambda e:errors.append(str(e.stack)[:2000]));page.on('console',lambda m:print('BROWSER',m.type,m.text[:500],flush=True) if m.type=='error' else None)
   async def route(r):
    u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve()
    if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
    await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
   await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:events.append(m));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
   await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.evaluate("async()=>{window.module=await import('/three.mjs');}");await page.locator('#quality').select_option('low')
   assert await page.locator('#engine option').count()==2;assert await page.locator('.dimensions').count()==0;assert await page.locator('#view-preset').count()==0
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode(),'identities':json.loads((FIX/'identities.json').read_text())})
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.57,'y':0,'z':-.15,'width':10,'depth':3,'above':4,'below':.5})
   for name in ['babylon','three']:
    print('ENGINE',name,flush=True)
    if await page.locator('#engine').input_value()!=name:await page.locator('#engine').select_option(name)
    await page.wait_for_function("()=>module.testing.renderer.loaded&&!document.querySelector('#engine').disabled",timeout=90000);await page.evaluate('()=>{window.r=module.testing.renderer;}');await page.wait_for_timeout(700)
    if name=='three':await page.wait_for_function('r.ready',timeout=30000)
    print('MODELS',await page.evaluate("()=>r.models?r.models.map(m=>({name:m.name,type:m.getClassName(),material:m.material?.getClassName()})):r.model.children.map(m=>m.name)"),flush=True)
    rect=await page.locator('#scene').bounding_box();cube=await page.locator('.view-cube').bounding_box();assert cube['width']<=48
    # Faster zoom and no old close-distance clamp.
    old=await page.evaluate('r.getCameraState()');await page.mouse.move(rect['x']+rect['width']*.28,rect['y']+rect['height']*.5);await page.mouse.wheel(0,-120);await page.wait_for_timeout(150);new=await page.evaluate('r.getCameraState()');assert new['radius']/old['radius']<.8,(name,old,new);assert math.dist(old['target'],new['target'])>.01
    await page.evaluate('()=>{const s=r.getCameraState();s.radius=.01;r.setCameraState(s);}');await page.mouse.wheel(0,-120);await page.wait_for_timeout(100);assert await page.evaluate('r.getCameraState().radius')<.009
    await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Geometry properties from real model picking.
    point=await page.evaluate("()=>{if(r.camera.mode!==undefined){const B=BABYLON,m=r.models.find(m=>m.name==='wall/0'),v=m.getBoundingInfo().boundingBox.centerWorld,p=B.Vector3.Project(v,B.Matrix.Identity(),r.scene.getTransformMatrix(),r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight())),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/r.engine.getRenderWidth()*rect.width,y:rect.y+p.y/r.engine.getRenderHeight()*rect.height};}return r.project([1.524,1.524,-.1524]);}")
    print('PICK POINT',point,flush=True);await page.mouse.click(point['x'],point['y']);await page.wait_for_timeout(300);assert await page.locator('#properties').is_visible(),(name,point,await page.locator('#hint').inner_text());assert '123' in await page.locator('#property-values').inner_text()
    await page.evaluate("()=>{window.visibleNames=()=>r.models?r.models.filter(m=>m.isEnabled()).map(m=>m.name):r.model.children.filter(m=>(m.isMesh||m.isLine)&&m.visible&&!m.name.startsWith('__o3d')).map(m=>m.name);}")
    await page.locator('#isolate-selection').click();await page.wait_for_timeout(100);assert all(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#show-all').click();await page.locator('#xray-selection').click();await page.wait_for_timeout(100)
    assert await page.evaluate("()=>r.models?r.models.find(m=>m.name==='wall2/0').visibility<.2:r.model.children.find(m=>m.name==='wall2/0').material.opacity<.2")
    await page.locator('#show-all').click();await page.locator('#hide-selection').click();await page.wait_for_timeout(100)
    assert not any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#show-all').click();assert any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#focus-selection').click();await page.wait_for_timeout(600);await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Compact grip sizes stay fixed as the model/box size changes.
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:500,depth:500,above:100,below:100},true)');await page.wait_for_timeout(300);assert await page.evaluate('r.bounds.max[0]-r.bounds.min[0]')>400
    await page.locator('#box-reset').click();assert any(m.get('type')=='resetBounds' for m in events)
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:10,depth:3,above:4,below:.5},true)');await page.wait_for_timeout(500)
    assert await page.locator('.section-grip').count()==6
    assert await page.evaluate("()=>document.querySelector('.section-outline path').getAttribute('d').match(/M/g).length===12&&getComputedStyle(document.querySelector('.section-outline path')).strokeWidth==='1px'")
    assert await page.evaluate("Array.from(document.querySelectorAll('.section-grip svg')).every(s=>getComputedStyle(s).width==='24px')")
    assert await page.evaluate("()=>r.models?!r.scene.meshes.some(m=>m.name.startsWith('Stretch ')):!r.model.children.some(m=>m.name.startsWith('__o3dHandle'))")
    # Click well outside the small glyph, inside its transparent grab target.
    grip=page.locator('.section-grip[data-axis="0"][data-side="max"]');await grip.wait_for(state='visible');box=await grip.bounding_box()
    axis=await page.evaluate("()=>{const r=module.testing.renderer,b=r.bounds,p=b.min.map((v,k)=>(v+b.max[k])/2);p[0]=b.max[0];const q=[...p];q[0]+=1;const a=r.project(p),z=r.project(q);return{x:z.x-a.x,y:z.y-a.y};}")
    length=math.hypot(axis['x'],axis['y']);dx=axis['x']/length;dy=axis['y']/length
    before=await page.evaluate('structuredClone(r.bounds)');camera_before=await page.evaluate('r.getCameraState()')
    x=box['x']+box['width']/2-dy*16;y=box['y']+box['height']/2+dx*16
    await page.mouse.move(x,y);assert await page.evaluate("p=>document.elementFromPoint(p.x,p.y)?.closest('.section-grip')?.dataset.axis",{'x':x,'y':y})=='0'
    await page.mouse.down();await page.wait_for_timeout(80);assert await page.evaluate('r.bounds.max[0]')==before['max'][0]
    await page.mouse.move(x+dx*40,y+dy*40,steps=8);await page.mouse.up();await page.wait_for_timeout(250)
    after=await page.evaluate('structuredClone(r.bounds)');assert after['max'][0]>before['max'][0]+.01
    assert abs(after['max'][0]-before['max'][0]-40/length)<.025
    assert after['min']==before['min'] and after['max'][1:]==before['max'][1:]
    assert math.dist(camera_before['target'],(await page.evaluate('r.getCameraState()'))['target'])<1e-6
    # Native host echoes committed bounds: do not recenter the camera at release.
    echo=await page.evaluate("()=>({...r.toMessage(),type:'box'})");await page.evaluate('m=>window.hostCallback({data:m})',echo);await page.wait_for_timeout(150)
    assert math.dist(camera_before['target'],(await page.evaluate('r.getCameraState()'))['target'])<1e-6
    # A selected object's centre is the orbit pivot even when dragging empty space.
    await page.evaluate("()=>{r.select('wall/0');window.selectedCentre=r.modelBounds('wall/0');selectedCentre=selectedCentre.min.map((v,k)=>(v+selectedCentre.max[k])/2);}")
    p0=await page.evaluate('r.project(selectedCentre)');a0=await page.evaluate('r.getCameraState().alpha')
    rect=await page.locator('#scene').bounding_box();x=rect['x']+25;y=rect['y']+25
    await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+50,y+20,steps=8);await page.mouse.up();await page.wait_for_timeout(300)
    p1=await page.evaluate('r.project(selectedCentre)');assert math.hypot(p1['x']-p0['x'],p1['y']-p0['y'])<2,(name,p0,p1)
    assert abs(await page.evaluate('r.getCameraState().alpha')-a0)>.1
    await page.locator('#clear-selection').click();assert await page.evaluate('r.orbitSelection') is None
    # Middle drag pans without changing orientation; top view hides head-on grips.
    before_pan=await page.evaluate('r.getCameraState()');await page.mouse.move(rect['x']+30,rect['y']+50);await page.mouse.down(button='middle');await page.mouse.move(rect['x']+70,rect['y']+70,steps=6);await page.mouse.up(button='middle');await page.wait_for_timeout(400);after_pan=await page.evaluate('r.getCameraState()')
    assert math.dist(before_pan['target'],after_pan['target'])>.01 and abs(before_pan['alpha']-after_pan['alpha'])<1e-6
    await page.locator('.view-cube').focus();await page.locator('.view-cube').press('PageUp');await page.wait_for_timeout(300);assert await page.locator('.section-grip:visible').count()==4
    await page.locator('.view-cube').press('Home');await page.wait_for_timeout(300)
    for style in ['realistic','colors','wireframe','shaded']:
     await page.locator('#style').select_option(style);await page.wait_for_timeout(250)
    await page.screenshot(path=str(ROOT/f'samples/v041-{name}.png'));assert not errors,errors
    results.append({'engine':name,'passed':['only Babylon and Three retained','numeric box fields and view dropdown removed','half-size cube','faster cursor-centred wheel zoom','close zoom has no 8 cm clamp','shared indexed geometry loads','actual picking exposes element ID 123','hide/isolate/X-ray/show-all controls run','300 ms focus and Home controls run','500 m section box accepted','reset region message sent','all display styles load','six compact paired-triangle grips with no cones','grip size stays fixed on screen','off-glyph grab area starts drag without jumping','drag moves only its face by projected distance','camera stays fixed on commit and host echo','selected-object centre stays fixed during orbit','clear selection restores pointer orbit','middle drag pans without orbiting','top view hides head-on grips','twelve box edges drawn at a fixed one-pixel width']})
   assert not any(m.get('type')=='error' for m in events),events
   (ROOT/'tests/viewer-v041-results.json').write_text(json.dumps({'results':results,'platform':'Linux Chromium/SwiftShader with simulated native host; Windows input and physical GPU performance untested'},indent=2)+'\n');print('PASS',json.dumps(results),flush=True)
  finally:await browser.close()
asyncio.run(main())

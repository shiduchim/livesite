$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
. (Join-Path $root 'scripts/Setup.Library.ps1')
$count=0
function Check([string]$Name,[scriptblock]$Action){& $Action;$script:count++;Write-Output ('PASS '+$Name)}
function Equal($A,$B){if($A -ne $B){throw "$A != $B"}}
function Reject([scriptblock]$Action){$caught=$false;try{& $Action}catch{$caught=$true};if(-not $caught){throw 'Expected rejection'}}
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('Offline3D-setup-test-'+[Guid]::NewGuid().ToString('N'));$null=New-Item $testRoot -ItemType Directory
try{
    foreach($tuple in @(@(2024,0,'net48'),@(2025,0,'net8.0-windows'),@(2025,5,'net10.0-windows'),@(2026,4,'net8.0-windows'),@(2026,5,'net10.0-windows'),@(2027,0,'net10.0-windows'))){
        Check ('Revit runtime selection '+$tuple[0]+'.'+$tuple[1]) {Equal (Get-RevitFramework $tuple[0] $tuple[1] $testRoot) $tuple[2]}
    }
    Check 'runtimeconfig overrides update fallback' { @{runtimeOptions=@{framework=@{name='Microsoft.NETCore.App';version='10.0.0'}}}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $testRoot 'Revit.runtimeconfig.json');Equal (Get-RevitFramework 2025 1 $testRoot) 'net10.0-windows';Remove-Item (Join-Path $testRoot 'Revit.runtimeconfig.json') }
    Check 'explicit runtimeconfig takes precedence over version fallback' { @{runtimeOptions=@{framework=@{name='Microsoft.NETCore.App';version='8.0.0'}}}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $testRoot 'Revit.runtimeconfig.json');Equal (Get-RevitFramework 2025 5 $testRoot) 'net8.0-windows';Remove-Item (Join-Path $testRoot 'Revit.runtimeconfig.json') }
    Check 'unknown host runtime rejected' { @{runtimeOptions=@{framework=@{name='Microsoft.NETCore.App';version='9.0.0'}}}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $testRoot 'Revit.runtimeconfig.json');Reject {Get-RevitFramework 2025 1 $testRoot};Remove-Item (Join-Path $testRoot 'Revit.runtimeconfig.json') }
    Check 'path traversal rejected' {Reject {Get-SafeChild $testRoot '../escape.dll'}}
    Check 'absolute path rejected' {Reject {Get-SafeChild $testRoot ([IO.Path]::GetFullPath('/tmp/file.dll'))}}
    Check 'alternate stream rejected' {Reject {Get-SafeChild $testRoot 'a.dll:stream'}}
    $manifest=Join-Path $testRoot 'own.addin'
    Check 'XML assembly path escaping and application ribbon registration' {Write-AddinManifest $manifest 'C:\Folder & Name\Exporter.dll';[xml]$xml=Get-Content $manifest -Raw;Equal $xml.RevitAddIns.AddIn.Type 'Application';Equal $xml.RevitAddIns.AddIn.FullClassName 'Offline3D.RevitExporter.RibbonApplication';Equal $xml.RevitAddIns.AddIn.Assembly 'C:\Folder & Name\Exporter.dll';Equal (Test-OwnedManifest $manifest) $true}
    Check 'unrelated add-in is not owned' {[xml]$xml=Get-Content $manifest -Raw;$xml.RevitAddIns.AddIn.AddInId='00000000-0000-0000-0000-000000000000';$xml.Save($manifest);Equal (Test-OwnedManifest $manifest) $false}
    Check 'XML external entities rejected' {Set-Content $manifest '<!DOCTYPE a [<!ENTITY x SYSTEM "file:///etc/passwd">]><RevitAddIns>&x;</RevitAddIns>';Reject {Test-OwnedManifest $manifest}}
    Check 'atomic state replacement' {$p=Join-Path $testRoot 'state.json';Write-AtomicJson $p @{state='old'};Write-AtomicJson $p @{state='new'};Equal (Get-Content $p -Raw|ConvertFrom-Json).state 'new'}
    $payload=Join-Path $testRoot 'payload';$viewer=Join-Path $payload 'Viewer';$null=New-Item $viewer -ItemType Directory -Force
    $file=Join-Path $viewer 'Offline3D.FastPDF.Dev.exe';[IO.File]::WriteAllBytes($file,[byte[]](1,2,3))
    $entry=@{path='Viewer/Offline3D.FastPDF.Dev.exe';size=3;sha256=(Get-FileHash $file).Hash}
    $metadata=@{schema=1;product='Offline3DPdfPrototype';releaseId=([Guid]::NewGuid().ToString('N'));files=@($entry);exporters=@()}
    $package=Join-Path $payload 'package.json';Write-AtomicJson $package $metadata
    Check 'valid payload hashes checked' {Equal (Test-Payload $payload).product 'Offline3DPdfPrototype'}
    Check 'tampered payload rejected' {[IO.File]::WriteAllBytes($file,[byte[]](3,2,1));Reject {Test-Payload $payload};[IO.File]::WriteAllBytes($file,[byte[]](1,2,3))}
    Check 'unlisted DLL rejected' {$extra=Join-Path $viewer 'unexpected.dll';Set-Content $extra 'data';Reject {Test-Payload $payload};Remove-Item $extra}
    Check 'duplicate payload descriptor rejected' {$copy=$metadata.Clone();$copy.files=@($entry,$entry);Write-AtomicJson $package $copy;Reject {Test-Payload $payload};Write-AtomicJson $package $metadata}
    Check 'all setup scripts parse' {foreach($script in Get-ChildItem (Join-Path $root 'scripts') -Filter *.ps1){$tokens=$null;$errorsFound=$null;[System.Management.Automation.Language.Parser]::ParseFile($script.FullName,[ref]$tokens,[ref]$errorsFound)|Out-Null;if($errorsFound){throw ($errorsFound|Out-String)}}}
    Check 'prebuilt and build-install launchers are distinct' {if((Get-Content (Join-Path $root 'INSTALL.cmd') -Raw) -notmatch '-Mode Install'){throw 'Wrong prebuilt launcher'};if((Get-Content (Join-Path $root 'BUILD_AND_INSTALL.cmd') -Raw) -notmatch '-Mode BuildInstall'){throw 'Wrong build launcher'}}
    $shell=(Get-Process -Id $PID).Path
    $fixture=Join-Path $PSScriptRoot 'NativeToolFixture.ps1'
    $prefix=@('-NoProfile','-File',$fixture)
    Check 'native stderr is diagnostic data when exit code is zero' {$result=Invoke-NativeTool $shell ($prefix+@('StderrSuccess'));Equal $result.ExitCode 0;if($result.StdErr -notmatch 'informational diagnostic'){throw 'Lost stderr'};if($result.StdOut -notmatch 'Build succeeded'){throw 'Lost stdout'}}
    Check 'build wrapper accepts diagnostic stderr with Stop preference' {Run-Tool $shell ($prefix+@('StderrSuccess'))}
    Check 'native arguments preserve spaces quotes trailing backslashes and shell characters' {
        # powershell.exe -File itself splits -p:value before binding script args;
        # exercise that MSBuild spelling separately, and round-trip the value here.
        Equal (ConvertTo-NativeArgument '-p:RevitApiDir=C:\Program Files\Autodesk\Revit 2024\') '"-p:RevitApiDir=C:\Program Files\Autodesk\Revit 2024\\"'
        $values=@('C:\Program Files\Autodesk\Revit 2024\','RevitApiDir=C:\Program Files\Autodesk\Revit 2024\','folder with spaces','quote"inside','a\\"b','$(must stay literal) & | %PATH% !','',(([string][char]0x05D0)+' folder'))
        $result=Invoke-NativeTool $shell ($prefix+@('Arguments')+$values)
        Equal $result.ExitCode 0;$actual=@($result.StdOut|ConvertFrom-Json);if($actual.Count -ne $values.Count){throw ('Argument round trip failed: '+$result.StdOut)}
        for($i=0;$i -lt $values.Count;$i++){Equal $actual[$i] $values[$i]}
    }
    Check 'native stdout and stderr drain concurrently without pipe deadlock' {$result=Invoke-NativeTool $shell ($prefix+@('LargeOutput'));Equal $result.ExitCode 0;Equal $result.StdOut.Length 524288;Equal $result.StdErr.Length 524288}
    Check 'failed build exposes exit code and real diagnostic with complete saved output' {
        $nativeLog=Join-Path $testRoot 'native-failure.txt';$message=''
        try{Run-Tool $shell ($prefix+@('Failure')) $nativeLog}catch{$message=$_.Exception.Message}
        if($message -notmatch 'exit code 42' -or $message -notmatch 'error TEST42'){throw 'Actual build error not shown'}
        $output=Get-Content $nativeLog -Raw
        if($output -notmatch 'Determining projects' -or $output -notmatch 'TEST42' -or $output -notmatch 'Exit code: 42'){throw 'Incomplete native log'}
    }
    Check 'silent failure still gives a useful message' {$message='';try{Run-Tool $shell ($prefix+@('SilentFailure'))}catch{$message=$_.Exception.Message};if($message -notmatch 'exit code 7' -or $message -notmatch 'no diagnostic output'){throw 'Silent failure was hidden'}}
    Check 'empty exception message falls back to error record text' {$record=[pscustomobject]@{ErrorDetails=$null;Exception=(New-Object System.Exception(''))};$message=Get-SetupErrorMessage $record;if([string]::IsNullOrWhiteSpace($message)){throw 'Blank error message'}}
    Check 'setup error details take precedence over blank exception' {$record=[pscustomobject]@{ErrorDetails=[pscustomobject]@{Message='Actual diagnostic'};Exception=(New-Object System.Exception(''))};Equal (Get-SetupErrorMessage $record) 'Actual diagnostic'}
    Write-Output "$count setup function checks passed (PowerShell 7 on Linux; Windows/COM/registry execution not verified)."
}finally{Remove-Item -LiteralPath $testRoot -Recurse -Force}

# Reproducible bounded before/after worker benchmark. Arguments: baseline apphost,
# integrated apphost, synthetic PDF, output JSON. Set DOTNET_ROOT when using a local SDK.
import json,subprocess,sys,statistics
baseline,integrated,pdf,output=sys.argv[1:]
rows=[]
for cycle in range(3):
 for name,exe in [('baseline',baseline),('integrated',integrated)]:
  row=json.loads(subprocess.check_output([exe,pdf],text=True));rows.append({'build':name,'cycle':cycle+1,**row})
assert len({r['rasterSha256'] for r in rows})==1,'Raster changed'
summary={name:{k:statistics.median(r[k] for r in rows if r['build']==name) for k in ['openMs','residentRenderMedianMs','residentRenderP95Ms','queueMedianMs','viewerHarnessWorkingSetBytes']} for name in ['baseline','integrated']}
json.dump({'platform':'Linux x64, no WPF or 3D process; 1024x1325 raster; 3 interleaved pairs; 50 resident renders per process','summary':summary,'sameRaster':True,'rows':rows},open(output,'w'),indent=2)
print(json.dumps(summary,indent=2))

import asyncio,base64,json,pathlib,math
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-v04')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   context=await browser.new_context(offline=True,viewport={'width':760,'height':900});page=await context.new_page();errors=[];events=[];results=[]
   page.on('pageerror',lambda e:errors.append(str(e.stack)[:2000]));page.on('console',lambda m:print('BROWSER',m.type,m.text[:500],flush=True) if m.type=='error' else None)
   async def route(r):
    u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve()
    if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
    await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
   await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:events.append(m));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
   await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.evaluate("async()=>{window.module=await import('/three.mjs');}");await page.locator('#quality').select_option('low')
   assert await page.locator('#engine option').count()==2;assert await page.locator('.dimensions').count()==0;assert await page.locator('#view-preset').count()==0
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode(),'identities':json.loads((FIX/'identities.json').read_text())})
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.57,'y':0,'z':-.15,'width':10,'depth':3,'above':4,'below':.5})
   for name in ['babylon','three']:
    print('ENGINE',name,flush=True)
    if await page.locator('#engine').input_value()!=name:await page.locator('#engine').select_option(name)
    await page.wait_for_function("()=>module.testing.renderer.loaded&&!document.querySelector('#engine').disabled",timeout=90000);await page.evaluate('()=>{window.r=module.testing.renderer;}');await page.wait_for_timeout(700)
    if name=='three':await page.wait_for_function('r.ready',timeout=30000)
    print('MODELS',await page.evaluate("()=>r.models?r.models.map(m=>({name:m.name,type:m.getClassName(),material:m.material?.getClassName()})):r.model.children.map(m=>m.name)"),flush=True)
    rect=await page.locator('#scene').bounding_box();cube=await page.locator('.view-cube').bounding_box();assert cube['width']<=48
    # Faster zoom and no old close-distance clamp.
    old=await page.evaluate('r.getCameraState()');await page.mouse.move(rect['x']+rect['width']*.28,rect['y']+rect['height']*.5);await page.mouse.wheel(0,-120);await page.wait_for_timeout(150);new=await page.evaluate('r.getCameraState()');assert new['radius']/old['radius']<.8,(name,old,new);assert math.dist(old['target'],new['target'])>.01
    await page.evaluate('()=>{const s=r.getCameraState();s.radius=.01;r.setCameraState(s);}');await page.mouse.wheel(0,-120);await page.wait_for_timeout(100);assert await page.evaluate('r.getCameraState().radius')<.009
    await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Geometry properties from real model picking.
    point=await page.evaluate("()=>{if(r.camera.mode!==undefined){const B=BABYLON,m=r.models.find(m=>m.name==='wall/0'),v=m.getBoundingInfo().boundingBox.centerWorld,p=B.Vector3.Project(v,B.Matrix.Identity(),r.scene.getTransformMatrix(),r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight())),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/r.engine.getRenderWidth()*rect.width,y:rect.y+p.y/r.engine.getRenderHeight()*rect.height};}return r.project([1.524,1.524,-.1524]);}")
    print('PICK POINT',point,flush=True);await page.mouse.click(point['x'],point['y']);await page.wait_for_timeout(300);assert await page.locator('#properties').is_visible(),(name,point,await page.locator('#hint').inner_text());assert '123' in await page.locator('#property-values').inner_text()
    await page.evaluate("()=>{window.visibleNames=()=>r.models?r.models.filter(m=>m.isEnabled()).map(m=>m.name):r.model.children.filter(m=>(m.isMesh||m.isLine)&&m.visible&&!m.name.startsWith('__o3d')).map(m=>m.name);}")
    await page.locator('#isolate-selection').click();await page.wait_for_timeout(100);assert all(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#show-all').click();await page.locator('#xray-selection').click();await page.wait_for_timeout(100)
    assert await page.evaluate("()=>r.models?r.models.find(m=>m.name==='wall2/0').visibility<.2:r.model.children.find(m=>m.name==='wall2/0').material.opacity<.2")
    await page.locator('#show-all').click();await page.locator('#hide-selection').click();await page.wait_for_timeout(100)
    assert not any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#show-all').click();assert any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await page.locator('#focus-selection').click();await page.wait_for_timeout(600);await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Large box and easy all-blue handles; keep old level plane constraints.
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:500,depth:500,above:100,below:100},true)');await page.wait_for_timeout(300);assert await page.evaluate('r.bounds.max[0]-r.bounds.min[0]')>400
    await page.locator('#box-reset').click();assert any(m.get('type')=='resetBounds' for m in events)
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:10,depth:3,above:4,below:.5},true)');await page.wait_for_timeout(500)
    if name=='babylon':
     assert await page.evaluate('r.handles.every(h=>h.mesh.material.emissiveColor.b>h.mesh.material.emissiveColor.r*5)')
     assert await page.evaluate('r.featureLines.length')==2
    # Real enlarged handle drag, preserving box and geometry picking.
    handle=await page.evaluate("()=>{if(r.handles instanceof Array){const B=BABYLON,h=r.handles.find(h=>h.axis===0&&h.side==='max'),vp=r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight()),p=B.Vector3.Project(h.mesh.position,B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),q=B.Vector3.Project(h.mesh.position.add(new B.Vector3(1,0,0)),B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/vp.width*rect.width,y:rect.y+p.y/vp.height*rect.height,dx:q.x-p.x,dy:q.y-p.y};}const h=r.handles().find(h=>h.axis===0&&h.side==='max'),p=r.project(h.point),a=[...h.point];a[0]+=1;const q=r.project(a);return{x:p.x,y:p.y,dx:q.x-p.x,dy:q.y-p.y};}")
    before=await page.evaluate('r.bounds.max[0]');dist=math.hypot(handle['dx'],handle['dy']);await page.mouse.move(handle['x'],handle['y']);await page.mouse.down();await page.mouse.move(handle['x']+handle['dx']/dist*30,handle['y']+handle['dy']/dist*30,steps=5);await page.mouse.up();await page.wait_for_timeout(200);assert abs(await page.evaluate('r.bounds.max[0]')-before)>.01,(name,'handle drag failed',handle)
    for style in ['realistic','colors','wireframe','shaded']:
     await page.locator('#style').select_option(style);await page.wait_for_timeout(250)
    await page.screenshot(path=str(ROOT/f'samples/v04-{name}.png'));assert not errors,errors
    results.append({'engine':name,'passed':['only Babylon and Three retained','numeric box fields and view dropdown removed','half-size cube','faster cursor-centred wheel zoom','close zoom has no 8 cm clamp','shared indexed geometry loads','actual picking exposes element ID 123','hide/isolate/X-ray/show-all controls run','300 ms focus and Home controls run','500 m section box accepted','reset region message sent','all display styles load']})
   assert not any(m.get('type')=='error' for m in events),events
   (ROOT/'tests/viewer-v04-results.json').write_text(json.dumps({'results':results,'platform':'Linux Chromium/SwiftShader with simulated native host; Windows input and physical GPU performance untested'},indent=2)+'\n');print('PASS',json.dumps(results),flush=True)
  finally:await browser.close()
asyncio.run(main())

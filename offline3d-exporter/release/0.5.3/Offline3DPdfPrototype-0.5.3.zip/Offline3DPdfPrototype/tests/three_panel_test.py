"""Exercise the exact 3D-only entry point bundled into FastPDF; no PDF.js used."""
import asyncio,base64,json,pathlib,sys
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIXTURE=pathlib.Path('/workspace/work/browser-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await browser.new_context(offline=True,viewport={'width':500,'height':760});page=await context.new_page();events=[];errors=[];requested=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  async def route(r):
   from urllib.parse import urlparse
   u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve();requested.append(u.path)
   if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
   await r.fulfill(body=f.read_bytes(),content_type={'mjs':'text/javascript','js':'text/javascript','html':'text/html','css':'text/css','env':'application/octet-stream'}[f.suffix[1:]])
  await context.route('**/*',route)
  await page.expose_binding('bridgeSend',lambda _,m:events.append(m))
  await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
  await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback')
  await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIXTURE/'scene.glb').read_bytes()).decode()})
  await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.572,'y':0,'z':-3.048,'width':3.048,'above':3.048,'below':.1524})
  await page.wait_for_function("document.getElementById('metrics').textContent.includes('meshes')")
  canvas=page.locator('#scene');rect=await canvas.bounding_box();await page.mouse.move(rect['x']+200,rect['y']+250);await page.mouse.down();await page.mouse.move(rect['x']+270,rect['y']+280,steps=12);await page.mouse.up();await page.mouse.wheel(0,120)
  await page.locator('#reset').click();await page.locator('#below').fill('0');await page.locator('#below').dispatch_event('change');await page.wait_for_timeout(150)
  assert any(m['type']=='size' and m['below']==0 for m in events),events
  await page.screenshot(path=str(ROOT/'samples/fastpdf-3d-panel-preview.png'))
  await page.locator('#hide').click();await page.wait_for_timeout(100);assert any(m['type']=='hide' for m in events)
  assert not errors and not any(m['type']=='error' for m in events),(errors,events)
  assert not any('pdf.' in f or 'pdfjs' in f for f in requested),requested
  print(json.dumps({'passed':['exact FastPDF 3D-only entry loads offline','real GLB rendering and clipping','orbit/wheel input and Reset complete without script errors','Below level zero accepted by UI message','Hide requested','no PDF renderer loaded in 3D panel'],'requestedInstalledAssets':requested,'platform':'Linux Chromium/SwiftShader; simulated native host'},indent=2))
  await browser.close()
asyncio.run(main())

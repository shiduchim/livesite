"""Offline tests of actual bundled Three.js, PlayCanvas and Filament adapters."""
import asyncio,base64,json,pathlib,math
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader']);context=await browser.new_context(offline=True,viewport={'width':740,'height':820});page=await context.new_page();errors=[];events=[];requested=[];results=[]
  page.on('pageerror',lambda e:errors.append(str(e.stack)))
  page.on('console',lambda m:print('BROWSER',m.type,m.text[:350],flush=True) if m.type in ['error','warning'] or 'FILAMENT' in m.text or 'ENGINE' in m.text else None)
  async def route(r):
   u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve();requested.append(u.path)
   if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():print('BLOCKED',r.request.url,flush=True);await r.abort();return
   await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
  await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:(events.append(m),print('HOST ERROR',m,flush=True) if m.get('type')=='error' else None));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
  await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback')
  await page.evaluate("async()=>{window.module=await import('/three.mjs')}")
  # Choose before model load so all adapter startup paths are exercised.
  await page.locator('#engine').select_option('three');await page.wait_for_function("document.getElementById('engine').disabled===false")
  await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode()})
  await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.572,'y':0,'z':-3.048,'width':3.048,'depth':3.048,'above':2.5,'below':.1524})
  for name in ['photo']:
   print('TEST ENGINE',name,flush=True)
   if name!=await page.locator('#engine').input_value():await page.locator('#engine').select_option(name)
   await page.wait_for_function("name=>{const r=window.module.testing.renderer;return r.loaded&&r.ready&&document.getElementById('engine').value===name&&document.getElementById('engine').disabled===false;}",arg=name,timeout=120000)
   await page.evaluate("async()=>{window.r=(await import('/three.mjs')).testing.renderer;}")
   info=await page.evaluate("()=>({name:r.name,caps:r.caps,open:r.openContours,bounds:r.bounds,frames:r.frames,hint:document.querySelector('#hint').textContent})")
   print('ENGINE READY',info,flush=True);assert info['caps']>0 and info['open']==0,info
   await page.evaluate('r.photoSampleTargetOverride=1');await page.wait_for_function('r.tracer.samples >= 1',timeout=120000);print('PHOTO SAMPLES',await page.evaluate('r.tracer.samples'),flush=True);await page.wait_for_timeout(500);await page.screenshot(path=str(ROOT/f'samples/{name}-comparison-preview.png'))
   point=await page.evaluate("()=>{const h=r.handles().find(h=>h.axis===0&&h.side==='max'),p=r.project(h.point),v=[...h.point];v[0]+=1;const q=r.project(v);return{x:p.x,y:p.y,dx:q.x-p.x,dy:q.y-p.y};}")
   before=await page.evaluate('r.bounds.max[0]');length=math.hypot(point['dx'],point['dy']);await page.mouse.move(point['x'],point['y']);await page.mouse.down();await page.mouse.move(point['x']+point['dx']/length*30,point['y']+point['dy']/length*30,steps=5);await page.mouse.up();after=await page.evaluate('r.bounds.max[0]');assert abs(after-before)>.005,(name,before,after,point)
   await page.wait_for_timeout(700);assert not errors,errors
   results.append({'renderer':name,'passed':['actual engine loads locally offline','source model and PBR materials loaded','shared clipping and solid caps','closed contours preserve holes','arrow handle drag changes and emits box bounds','frame renders without script errors'],'info':info})
  assert not any(m.get('type')=='error' for m in events),events
  (ROOT/'tests/photo-results.json').write_text(json.dumps({'results':results,'requestedAssets':requested,'platform':'Linux Chromium / SwiftShader; simulated WebView2 host, not Windows hardware'},indent=2)+'\n')
  print('PASS actual engine comparison',json.dumps(results),flush=True);await page.evaluate('r.dispose()');await browser.close()
asyncio.run(main())

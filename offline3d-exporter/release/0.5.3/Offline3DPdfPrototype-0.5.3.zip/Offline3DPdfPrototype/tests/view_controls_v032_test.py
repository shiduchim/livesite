"""Actual local renderer/UI regression checks; native host is simulated."""
import asyncio,base64,json,pathlib,math,sys
from urllib.parse import urlparse
from playwright.async_api import async_playwright
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   context=await browser.new_context(offline=True,viewport={'width':620,'height':760});page=await context.new_page();errors=[];events=[];results=[]
   page.on('pageerror',lambda e:errors.append(str(e.stack)))
   async def route(r):
    u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve()
    if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
    await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
   await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:events.append(m));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
   await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.locator('#quality').select_option('low');await page.locator('#style').select_option('shaded');await page.locator('summary').click();await page.locator('#edges').uncheck();await page.locator('#shadows').uncheck();await page.locator('#occlusion').uncheck()
   await page.evaluate("async()=>{window.module=await import('/three.mjs');}")
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode()})
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.572,'y':0,'z':-3.048,'width':3.048,'depth':3.048,'above':2.5,'below':.1524})
   for name in (sys.argv[1:] or ['babylon','three','playcanvas','filament']):
    print('CHECK',name,flush=True)
    if await page.locator('#engine').input_value()!=name:await page.locator('#engine').select_option(name)
    await page.wait_for_function("()=>{const r=module.testing.renderer;return r.loaded&&document.querySelector('#engine').disabled===false&&(r.ready||r.camera?.mode===1)}",timeout=90000)
    await page.evaluate('()=>{window.r=module.testing.renderer;}')
    await page.wait_for_timeout(500)
    canvas=await page.locator('#scene').bounding_box();home=await page.locator('#reset').bounding_box();assert canvas['x']<=home['x']<canvas['x']+canvas['width'] and canvas['y']<=home['y']<canvas['y']+canvas['height'];assert 'Home view' in await page.locator('#reset').inner_text()
    await page.locator('#reset').click();await page.wait_for_timeout(150)
    await page.locator('.cube-top').click();await page.wait_for_timeout(150);assert (await page.evaluate('r.getCameraState()'))['beta']<.0003
    await page.locator('#reset').click();await page.wait_for_timeout(150);cb=await page.locator('.view-cube').bounding_box();prior=await page.evaluate('r.getCameraState()');await page.mouse.move(cb['x']+cb['width']/2,cb['y']+cb['height']/2);await page.mouse.down();await page.mouse.move(cb['x']+cb['width']/2+30,cb['y']+cb['height']/2+12,steps=5);await page.mouse.up();await page.wait_for_timeout(150);assert abs((await page.evaluate('r.getCameraState()'))['alpha']-prior['alpha'])>.01
    await page.locator('#reset').click()
    for face,angles in {'top':[-math.pi/2,.000001],'front':[math.pi/2,math.pi/2],'back':[-math.pi/2,math.pi/2],'left':[math.pi,math.pi/2],'right':[0,math.pi/2],'bottom':[-math.pi/2,math.pi-.000001]}.items():
     await page.locator('#view-preset').select_option(face);await page.wait_for_timeout(80);state=await page.evaluate('r.getCameraState()');assert abs(state['beta']-angles[1])<.0003,(name,face,state)
     delta=(state['alpha']-angles[0]+math.pi)%(2*math.pi)-math.pi;assert abs(delta)<.0003,(name,face,state)
    await page.locator('#reset').click();await page.wait_for_timeout(300)
    before=await page.evaluate('r.getCameraState()');x=canvas['x']+35;y=canvas['y']+canvas['height']*.6;await page.mouse.move(x,y);await page.mouse.down(button='middle');await page.mouse.move(x+50,y+15,steps=6);await page.mouse.up(button='middle');await page.wait_for_timeout(300);after=await page.evaluate('r.getCameraState()');assert math.dist(before['target'],after['target'])>.005,(name,before,after);assert abs(before['alpha']-after['alpha'])<.001,(name,'middle drag rotated')
    await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+50,y+20,steps=6);await page.mouse.up();await page.wait_for_timeout(300);rotated=await page.evaluate('r.getCameraState()');assert abs(rotated['alpha']-after['alpha'])>.005,(name,'rotation failed')
    await page.locator('#reset').click();await page.wait_for_timeout(200)
    if name=='babylon':
     assert await page.evaluate('r.camera.inertia')<=.3
     # Neutral material under actual illumination, sampled on front and back.
     await page.evaluate("()=>{const m=r.models.find(m=>m.name==='partition');m.metadata.original.albedoColor.set(.45,.45,.45);r.configure({style:'shaded',quality:'low',edges:false});const bb=m.getBoundingInfo().boundingBox;window.wallCenter=BABYLON.Vector3.FromArray(bb.minimumWorld.asArray().map((v,k)=>(Math.max(v,r.bounds.min[k])+Math.min(bb.maximumWorld.asArray()[k],r.bounds.max[k]))/2));r.outline.isVisible=false;}")
     luminances=[]
     for a in [-math.pi/2,math.pi/2,0,math.pi]:
      await page.evaluate('(a)=>{r.setCameraState({alpha:a,beta:Math.PI/3,radius:3,target:wallCenter.asArray()});r.orthoScale=1.6;r.wake();}',a);await page.wait_for_function('!r.active',timeout=60000);png=ROOT/f'samples/shaded-v032-{len(luminances)}.png';await page.locator('#scene').screenshot(path=str(png));im=Image.open(png).convert('RGB');rgb=im.getpixel((im.width//2,im.height//2));luminances.append(sum(rgb)/3)
     assert min(luminances)>100,(name,'dark face',luminances);print('SHADED FACE LUMINANCES',luminances,flush=True)
     await page.evaluate('r.outline.isVisible=true');await page.locator('#reset').click()
    await page.screenshot(path=str(ROOT/f'samples/controls-v032-{name}.png'))
    results.append({'renderer':name,'passed':['Home view adjacent to model','six standard orthographic orientations','middle-button drag pans without rotating','left drag rotates','Home view resets orbit'],'shaded':True})
    assert not errors,errors
   assert not any(e.get('type')=='error' for e in events),events
   (ROOT/('tests/view-controls-v032-'+sys.argv[1]+'-extra.json' if len(sys.argv)>1 else 'tests/view-controls-v032-results.json')).write_text(json.dumps({'results':results,'platform':'Linux Chromium/SwiftShader, simulated WebView2 host; native Windows input and physical GPU untested'},indent=2)+'\n');print('PASS',json.dumps(results),flush=True)
  finally:await browser.close()
asyncio.run(main())

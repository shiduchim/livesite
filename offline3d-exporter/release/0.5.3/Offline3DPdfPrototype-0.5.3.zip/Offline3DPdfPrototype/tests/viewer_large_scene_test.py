import asyncio,base64,json,pathlib
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/large-scene-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   results=[]
   for name in ['babylon','three']:
    print('START',name,flush=True)
    context=await browser.new_context(offline=True,viewport={'width':900,'height':900});page=await context.new_page();errors=[];requests=[]
    page.on('pageerror',lambda e:(errors.append(str(e)),print('PAGE ERROR',str(e),flush=True)));page.on('console',lambda m:print('CONSOLE',m.type,m.text[:700],flush=True) if m.type=='error' else None)
    async def route(r):
     u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve();requests.append(u.path)
     if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
     await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
    await context.route('**/*',route);await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>{window.messages=window.messages||[];window.messages.push(m)},addEventListener:(t,f)=>window.hostCallback=f};")
    async def setting(control,value):
     if not await page.locator('#settings-panel').is_visible():await page.locator('#settings-toggle').click()
     await page.locator('#'+control).select_option(value)
     if await page.locator('#settings-panel').is_visible():await page.locator('#settings-toggle').click()
    await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.evaluate("async()=>window.module=await import('/three.mjs')");await setting('quality','low')
    if name=='three':await setting('engine','three');await page.wait_for_function("()=>!document.querySelector('#engine').disabled")
    await page.evaluate('m=>hostCallback({data:m})',{'type':'box','x':0,'y':0,'z':0,'width':.06,'depth':.06,'above':.03,'below':.03})
    await asyncio.wait_for(page.evaluate('m=>hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode(),'identities':json.loads((FIX/'identities.json').read_text())}),timeout=60)
    print('HOST MESSAGES',await page.evaluate('window.messages'),flush=True);await page.wait_for_timeout(1000);print('STATE',await page.evaluate("()=>({loaded:module.testing.renderer.loaded,active:module.testing.renderer.activeNodes?.triangles,hint:document.querySelector('#hint').textContent,worker:module.testing.renderer.sections?.request})"),flush=True)
    await page.wait_for_function('module.testing.renderer.loaded&&module.testing.renderer.activeNodes',timeout=120000);await page.evaluate('()=>{window.r=module.testing.renderer;}');await page.wait_for_function("r.sections?.workStats||r.sectionWork||document.querySelector('#hint').textContent.includes('unavailable')",timeout=30000)
    state=await page.evaluate("()=>({unique:r.sourceScene.uniqueTriangles,placed:r.sourceScene.expandedTriangles,nodes:r.sourceScene.nodes.length,active:r.activeNodes.triangles,work:r.sections?.workStats||r.sectionWork,caps:r.sections?.caps.length??r.capRoot.children.length,edgeDrawables:r.featureLines?.length??r.model.children.filter(m=>m.isLine&&m.visible).length,geometry:r.models?new Set(r.models.map(m=>m.geometry||m.sourceMesh.geometry)).size:new Set(r.model.children.filter(m=>m.isMesh).map(m=>m.geometry)).size,groupsExpanded:r.sections?[...r.sections.groups.values()].some(g=>g.vertices):false})")
    print(name,json.dumps(state),flush=True)
    assert state['placed']>1500000 and state['nodes']==2000 and state['unique']==1024
    assert state['geometry']==1 and state['active']==1024 and state['edgeDrawables']<=1
    assert state['work']['trianglesVisited']<20000 and state['caps']==6 and not state['groupsExpanded']
    assert not any('comparison-worker' in x for x in requests)
    # Moving the section uses GPU planes and the same loaded mesh objects.
    before=await page.evaluate('r.models?r.models[0].uniqueId:r.model.children.find(m=>m.isMesh).uuid')
    await page.evaluate("()=>r.box({x:.9144,y:0,z:0,width:.06,depth:.06,above:.03,below:.03},false,true)");await page.wait_for_timeout(600)
    after=await page.evaluate('r.models?r.models[0].uniqueId:r.model.children.find(m=>m.isMesh).uuid');assert before==after
    assert await page.evaluate("r.activeNodes.names.has('socket-1/0')&&!r.activeNodes.names.has('socket-0/0')")
    assert not errors,errors
    results.append({'engine':name,'checks':['over 1.5 million placed triangles load','2000 node identities preserved','one unique GPU geometry','active section limits drawing to 1024 triangles','caps inspect under 20000 crossing triangles','six solid cap faces generated','no expanded per-element triangle arrays','old comparison worker not requested','section movement retains loaded geometry','active instance changes correctly'],'metrics':state})
    await context.close()
   (ROOT/'tests/viewer-large-scene-results.json').write_text(json.dumps({'results':results,'platform':'Linux Chromium/SwiftShader; physical GPU and Revit execution untested'},indent=2)+'\n')
  finally:await browser.close()
asyncio.run(main())

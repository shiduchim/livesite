import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {sectionLoops,triangulateSection} from '../src/Viewer/web/sections.mjs';
const earcut=createRequire(import.meta.url)('../src/Viewer/web/vendor/earcut.js');let passed=0;
const test=(name,f)=>{f();passed++;console.log('PASS '+name);};
function box(lo,hi){const p=[[lo,lo,lo],[hi,lo,lo],[hi,hi,lo],[lo,hi,lo],[lo,lo,hi],[hi,lo,hi],[hi,hi,hi],[lo,hi,hi]],indices=[0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,1,2,6,1,6,5,2,3,7,2,7,6,3,0,4,3,4,7];return indices.flatMap(i=>p[i]);}
function surfaceArea(flat){let area=0;for(let i=0;i<flat.length;i+=6)area+=Math.abs((flat[i+2]-flat[i])*(flat[i+5]-flat[i+1])-(flat[i+4]-flat[i])*(flat[i+3]-flat[i+1]))/2;return area;}
for(const axis of [0,1,2])test('solid wall cap on axis '+axis,()=>{const r=sectionLoops(box(0,4),axis,2);assert.equal(r.open,0);assert.equal(r.loops.length,1);assert.ok(Math.abs(surfaceArea(triangulateSection(r.loops,earcut))-16)<1e-8);});
test('window or shaft opening remains a hole',()=>{const r=sectionLoops([...box(0,4),...box(1,3)],0,2);assert.equal(r.loops.length,2);assert.ok(Math.abs(surfaceArea(triangulateSection(r.loops,earcut))-12)<1e-8);});
test('nested material island preserves its area',()=>{const r=sectionLoops([...box(0,6),...box(1,5),...box(2,4)],1,3);assert.ok(Math.abs(surfaceArea(triangulateSection(r.loops,earcut))-24)<1e-8);});
test('concave section is triangulated without bridging its recess',()=>{const r=[[0,0],[4,0],[4,1],[1,1],[1,4],[0,4]];assert.ok(Math.abs(surfaceArea(triangulateSection([r],earcut))-7)<1e-8);});
test('open triangles are reported and never filled arbitrarily',()=>{const r=sectionLoops([0,0,0,4,0,0,0,4,4],2,2);assert.equal(r.loops.length,0);assert.ok(r.open>0);});
test('typed transferred geometry yields the same section',()=>{const r=sectionLoops(new Float64Array(box(0,4)),2,2);assert.equal(r.open,0);assert.ok(Math.abs(surfaceArea(triangulateSection(r.loops,earcut))-16)<1e-8);});
test('plane outside the model emits no cap',()=>assert.equal(sectionLoops(box(0,4),1,8).loops.length,0));
console.log(passed+' section geometry checks passed.');

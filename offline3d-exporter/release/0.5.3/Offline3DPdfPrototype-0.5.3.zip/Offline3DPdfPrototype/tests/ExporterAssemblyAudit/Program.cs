using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text.Json;

// Reads PE metadata only: it never loads a Revit DLL into the audit process.
if(args.Length!=1)throw new ArgumentException("Usage: ExporterAssemblyAudit <payload directory>");
string payload=Path.GetFullPath(args[0]);
using var package=JsonDocument.Parse(File.ReadAllBytes(Path.Combine(payload,"package.json")));
var entries=package.RootElement.GetProperty("exporters").EnumerateArray().ToArray();
var expected=new HashSet<string>(StringComparer.Ordinal){
    "2024-net48","2025-net8.0-windows","2025-net10.0-windows",
    "2026-net8.0-windows","2026-net10.0-windows","2027-net10.0-windows"
};
var forbidden=new HashSet<string>(StringComparer.OrdinalIgnoreCase){
    "Core","System.Text.Json","System.Text.Encodings.Web","Microsoft.Bcl.AsyncInterfaces",
    "System.Memory","System.Buffers","System.Runtime.CompilerServices.Unsafe",
    "System.Threading.Tasks.Extensions","System.ValueTuple"
};
int checks=0;
void Check(bool condition,string name){if(!condition)throw new InvalidDataException(name);checks++;Console.WriteLine("PASS "+name);}
Check(entries.Length==6,"manifest contains all six exporter variants");
foreach(var entry in entries){
    int year=entry.GetProperty("year").GetInt32();
    string framework=entry.GetProperty("framework").GetString()!;
    string variant=year+"-"+framework;
    Check(expected.Remove(variant),"unique supported variant "+variant);
    string relative=entry.GetProperty("path").GetString()!;
    string path=Path.GetFullPath(Path.Combine(payload,relative.Replace('/',Path.DirectorySeparatorChar)));
    Check(path.StartsWith(payload+Path.DirectorySeparatorChar,StringComparison.Ordinal),variant+" assembly path is within payload");
    string folder=Path.GetDirectoryName(path)!;
    string[] dlls=Directory.GetFiles(folder,"*.dll",SearchOption.AllDirectories);
    Check(dlls.Length==1&&Path.GetFullPath(dlls[0])==path,variant+" contains exactly its standalone exporter DLL");
    using var stream=File.OpenRead(path);
    using var pe=new PEReader(stream);
    Check(pe.HasMetadata,variant+" contains managed metadata");
    var metadata=pe.GetMetadataReader();
    var assembly=metadata.GetAssemblyDefinition();
    string assemblyName=metadata.GetString(assembly.Name);
    Check(assemblyName=="Offline3DPrototype.Revit"+year,variant+" assembly identity matches its Revit year");
    var refs=metadata.AssemblyReferences.Select(h=>metadata.GetAssemblyReference(h)).ToArray();
    string[] names=refs.Select(r=>metadata.GetString(r.Name)).OrderBy(n=>n,StringComparer.Ordinal).ToArray();
    Console.WriteLine("REFERENCES "+variant+": "+string.Join(", ",names));
    bool ForbiddenReference(AssemblyReference reference){string name=metadata.GetString(reference.Name);if(!forbidden.Contains(name))return false;return !(framework!="net48"&&name=="System.Memory"&&reference.Version.Major>=8);}
    Console.WriteLine("REFERENCE VERSIONS "+variant+": "+string.Join(", ",refs.Select(r=>metadata.GetString(r.Name)+"/"+r.Version)));
    Check(!refs.Any(ForbiddenReference),variant+" has no Core, JSON or NuGet BCL dependencies (modern framework System.Memory is allowed)");
    Check(names.All(n=>n=="RevitAPI"||n=="RevitAPIUI"||n=="mscorlib"||n=="netstandard"||n=="System"||n.StartsWith("System.",StringComparison.Ordinal)),variant+" references only Revit APIs and standard framework assemblies");
    foreach(string revit in new[]{"RevitAPI","RevitAPIUI"}){
        var reference=refs.Single(r=>metadata.GetString(r.Name)==revit);
        Check(reference.Version.Major==year-2000,variant+" "+revit+" reference matches host year");
    }
    var types=metadata.TypeDefinitions.Select(h=>metadata.GetTypeDefinition(h)).Select(t=>metadata.GetString(t.Namespace)+"."+metadata.GetString(t.Name)).ToHashSet(StringComparer.Ordinal);
    Check(types.Contains("Offline3D.Contract")&&types.Contains("Offline3D.GlbBuilder")&&types.Contains("Offline3D.Registration"),variant+" embeds its own writer, scene builder and plain contract types");
    Check(types.Contains("Offline3D.SpoolSceneWriter")&&types.Contains("Offline3D.IndexedMeshAccumulator"),variant+" includes early indexed geometry sharing and the spool writer");
    Check(types.Contains("Offline3D.RevitExporter.ExportCommand")&&types.Contains("Offline3D.RevitExporter.RibbonApplication"),variant+" contains the Revit command and application entry points");
}
Check(expected.Count==0,"all expected Revit/framework pairs inspected");
var autodeskFiles=Directory.EnumerateFiles(payload,"*.dll",SearchOption.AllDirectories).Where(p=>{
    string name=Path.GetFileName(p);
    return name.Equals("RevitAPI.dll",StringComparison.OrdinalIgnoreCase)||name.Equals("RevitAPIUI.dll",StringComparison.OrdinalIgnoreCase)||name.Equals("AdWindows.dll",StringComparison.OrdinalIgnoreCase)||name.Equals("UIFramework.dll",StringComparison.OrdinalIgnoreCase)||name.StartsWith("Autodesk.",StringComparison.OrdinalIgnoreCase);
}).ToArray();
Check(autodeskFiles.Length==0,"no Autodesk API/UI runtime DLL is redistributed anywhere in payload");
Console.WriteLine(checks+" exporter assembly audit checks passed. Read-only PE metadata inspection; not a Windows/Revit execution test.");

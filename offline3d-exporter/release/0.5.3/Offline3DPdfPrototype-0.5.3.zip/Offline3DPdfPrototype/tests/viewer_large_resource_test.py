import asyncio,json,pathlib,threading,shutil
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/large-resource-fixture')
async def main():
 sceneSize=(FIX/'scene.glb').stat().st_size;assert sceneSize>64*1024*1024
 class Handler(SimpleHTTPRequestHandler):
  def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(WEB),**kwargs)
  def log_message(self,*args):pass
  def do_GET(self):
   if self.path=='/scene.glb':
    self.send_response(200);self.send_header('Content-Type','model/gltf-binary');self.send_header('Content-Length',str(sceneSize));self.end_headers()
    with (FIX/'scene.glb').open('rb') as stream:shutil.copyfileobj(stream,self.wfile,65536)
   else:super().do_GET()
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();origin='http://127.0.0.1:'+str(server.server_address[1])
 results=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
  try:
   for name in ['babylon','three']:
    context=await browser.new_context(viewport={'width':900,'height':900});page=await context.new_page();errors=[];requests=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:requests.append(urlparse(r.url).path));await page.add_init_script("window.messages=[];window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>messages.push(m),addEventListener:(t,f)=>window.hostCallback=f};")
    await page.goto(origin+'/three.html');await page.wait_for_function('!!window.hostCallback');await page.evaluate("async()=>{window.module=await import('/three.mjs');}");await page.locator('#settings-toggle').click();await page.locator('#quality').select_option('low');await page.locator('#caps').evaluate('(e)=>e.closest("details").open=true');await page.locator('#caps').uncheck();await page.locator('#edges').uncheck()
    if name=='three':await page.locator('#engine').select_option('three');await page.wait_for_function("!document.querySelector('#engine').disabled")
    await page.locator('#settings-toggle').click()
    # Scene URLs are restricted to the one native in-memory resource.
    await page.evaluate("()=>hostCallback({data:{type:'scene',url:'https://outside.test/model.glb',size:1}})");assert await page.evaluate("messages.some(m=>m.type==='error'&&m.message.includes('Invalid local scene address'))");assert not any('outside' in x for x in requests)
    await page.evaluate("messages=[]")
    await page.evaluate("()=>hostCallback({data:{type:'box',x:1,y:0,z:1,width:3.048,depth:3.048,above:3.048,below:.1524}})")
    transfer={'type':'scene','url':origin+'/scene.glb','size':sceneSize,'identities':[]};assert len(json.dumps(transfer))<300
    await asyncio.wait_for(page.evaluate('m=>hostCallback({data:m})',transfer),timeout=180)
    await page.wait_for_function('module.testing.renderer.loaded&&module.testing.renderer.activeNodes',timeout=120000);await page.evaluate('()=>{window.r=module.testing.renderer;}');await page.wait_for_timeout(700)
    state=await page.evaluate("()=>({nodes:r.sourceScene.nodes.length,meshes:r.sourceScene.meshes.length,unique:r.sourceScene.uniqueTriangles,active:r.activeNodes.triangles,expandedEdges:r.edgeItems.expandedMeshes(),byteLength:r.sourceBytes.length})")
    assert state['byteLength']==sceneSize and state['nodes']==90 and state['meshes']==90 and state['unique']==90*8192
    assert state['active']==8192 and state['expandedEdges']==0
    # Enabling edges expands only the current unique mesh.
    await page.locator('#settings-toggle').click();await page.locator('#edges').check();await page.locator('#settings-toggle').click();await page.wait_for_timeout(400);assert await page.evaluate('r.edgeItems.expandedMeshes()')==1
    await page.evaluate("()=>r.box({x:25.384,y:0,z:1,width:3.048,depth:3.048,above:3.048,below:.1524},false,true)");await page.wait_for_timeout(400);assert await page.evaluate("r.activeNodes.names.has('part-1/0')&&!r.activeNodes.names.has('part-0/0')");assert await page.evaluate('r.edgeItems.expandedMeshes()')==2
    assert requests.count('/scene.glb')==1 and not errors,errors
    assert not await page.evaluate("messages.some(m=>m.type==='error')"),await page.evaluate('messages')
    results.append({'engine':name,'passed':['non-local scene URL rejected','host scene message stays below 300 bytes','actual over-64-MiB scene fetched once as binary','all 90 unique meshes and placements retained','all 737280 unique triangles retained','only 8192 active triangles drawn','zero edges expanded while disabled','one edge mesh expanded when enabled','moving section selects next placement','only visited edge meshes expanded','no browser or native-bridge errors'],'metrics':state})
    print('PASS',name,state,flush=True);await context.close()
   (ROOT/'tests/viewer-large-resource-v051-results.json').write_text(json.dumps({'bytes':sceneSize,'results':results,'platform':'Linux Chromium/SwiftShader with a loopback binary HTTP test server; native Windows WebView2 interception and physical GPU untested'},indent=2)+'\n')
  finally:await browser.close();server.shutdown();server.server_close()
asyncio.run(main())

"""Actual offline Babylon pixel/drag regression for the section-box outline."""
import asyncio,base64,json,pathlib,math
from urllib.parse import urlparse
from PIL import Image,ImageChops
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-fixture')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   context=await browser.new_context(offline=True,viewport={'width':640,'height':760});page=await context.new_page();errors=[];events=[];results=[]
   page.on('pageerror',lambda e:errors.append(str(e.stack)))
   async def route(r):
    u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve()
    if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
    await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
   await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:events.append(m));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
   await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.locator('#quality').select_option('low');await page.evaluate("async()=>{window.r=(await import('/three.mjs')).testing.renderer;r.configure({shadows:false,occlusion:false});}")
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode()})
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.572,'y':0,'z':-3.048,'width':3.048,'depth':3.048,'above':2.5,'below':.1524})
   await page.wait_for_function('r.loaded&&r.outline&&r.sections.caps.length>0')
   for quality in ['low','ultra']:
    print('Checking',quality,flush=True);await page.evaluate("q=>{r.configure({quality:q,shadows:false,occlusion:false});r.outline.isVisible=true;r.wake();}",quality);await page.wait_for_function('!r.active',timeout=60000)
    visible='/tmp/babylon-outline-'+quality+'-visible.png';hidden='/tmp/babylon-outline-'+quality+'-hidden.png';await page.locator('#scene').screenshot(path=visible)
    actual=await page.evaluate("()=>({orthographic:r.camera.mode===BABYLON.Camera.ORTHOGRAPHIC_CAMERA,handles:r.handles.filter(h=>h.mesh.isEnabled()&&h.mesh.isVisible).length,clipPlanes:!!r.scene.clipPlane6,outlineClip:r.outline.material.options.useClipPlane,cssWidth:r.outline.material.width*r.engine.getHardwareScalingLevel(),resolution:[r.engine.getRenderWidth(),r.engine.getRenderHeight()]})")
    assert actual['orthographic'] and actual['handles']==6 and actual['clipPlanes'] and actual['outlineClip'] is False,actual
    await page.evaluate('r.outline.isVisible=false;r.wake()');await page.wait_for_function('!r.active',timeout=60000);await page.locator('#scene').screenshot(path=hidden)
    a=Image.open(visible).convert('RGB');b=Image.open(hidden).convert('RGB');changed=sum(max(abs(x-y) for x,y in zip(pa,pb))>12 and pa[2]>pa[0]+20 for pa,pb in zip(a.getdata(),b.getdata()));assert changed>500,(quality,changed,actual)
    assert min(a.getpixel((10,10)))>=250,a.getpixel((10,10))
    results.append({'quality':quality,'visibleBlueStrokePixels':changed,**actual});print(results[-1],flush=True)
   await page.evaluate('r.outline.isVisible=true;r.configure({quality:"low"});r.wake()');await page.wait_for_function('!r.active',timeout=60000)
   point=await page.evaluate("()=>{const B=BABYLON,h=r.handles.find(h=>h.axis===0&&h.side==='max'),vp=r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight()),p=B.Vector3.Project(h.mesh.position,B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),q=B.Vector3.Project(h.mesh.position.add(new B.Vector3(1,0,0)),B.Matrix.Identity(),r.scene.getTransformMatrix(),vp),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/vp.width*rect.width,y:rect.y+p.y/vp.height*rect.height,dx:q.x-p.x,dy:q.y-p.y};}")
   before=await page.evaluate('r.bounds.max[0]');length=math.hypot(point['dx'],point['dy']);await page.mouse.move(point['x'],point['y']);await page.mouse.down();await page.mouse.move(point['x']+point['dx']/length*35,point['y']+point['dy']/length*35,steps=8);await page.mouse.up();after=await page.evaluate('r.bounds.max[0]');assert abs(after-before)>.01,(before,after,point)
   assert any(e.get('type')=='bounds' and e.get('final') for e in events),events
   await page.wait_for_function('!r.active',timeout=60000);await page.screenshot(path=str(ROOT/'samples/babylon-outline-v032-preview.png'))
   assert not errors and not any(e.get('type')=='error' for e in events),(errors,events)
   report={'passed':['outline visible in actual screenshot at Low','outline visible in actual screenshot at Extra High','screen-space stroke width retained under supersampling','all six handles remain visible','model clipping remains enabled while outline bypasses clipping','orthographic projection retained','white background pixels retained','real pointer drag changes bounds and emits final synchronization'],'results':results,'dragDelta':after-before,'platform':'Linux Chromium/SwiftShader; simulated WebView2 host. Windows/WebView2 and physical GPU untested.'}
   (ROOT/'tests/babylon-outline-v032-results.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',json.dumps(report),flush=True)
  finally:await browser.close()
asyncio.run(main())

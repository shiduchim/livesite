# A real child process for setup-launcher regression tests. Never installed/run by setup.
$encoding=New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding=$encoding
$mode=$args[0]
switch($mode){
    'StderrSuccess' {[Console]::Out.WriteLine('Build succeeded.');[Console]::Error.WriteLine('informational diagnostic on stderr');exit 0}
    'Failure' {[Console]::Out.WriteLine('Determining projects to restore...');[Console]::Error.WriteLine('error TEST42: a useful build failure');exit 42}
    'SilentFailure' {exit 7}
    'LargeOutput' {$chunk=('x'*65536);for($i=0;$i -lt 8;$i++){[Console]::Out.Write($chunk);[Console]::Error.Write($chunk)};exit 0}
    'Arguments' {$values=@($args | Select-Object -Skip 1);[Console]::Out.WriteLine((ConvertTo-Json -InputObject $values -Compress));exit 0}
    default {[Console]::Error.WriteLine('Unknown fixture mode');exit 2}
}

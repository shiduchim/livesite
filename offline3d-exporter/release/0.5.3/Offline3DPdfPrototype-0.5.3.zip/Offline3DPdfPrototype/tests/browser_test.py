"""Linux adapter/bridge harness, not a Windows WebView2 acceptance test.
Requires playwright Python, Chromium, a generated sample and pdfdetach.
"""
import asyncio, base64, json, os, pathlib, subprocess, sys, mimetypes
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
WEB=ROOT/'src/Viewer/web'
FIXTURE=pathlib.Path(os.environ.get('OFFLINE3D_FIXTURE','/workspace/work/browser-fixture'))
DOTNET=os.environ.get('OFFLINE3D_DOTNET','dotnet')
TOOL=ROOT/'src/Tool/bin/Debug/net8.0/Tool.dll'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await browser.new_context(viewport={'width':1280,'height':860},offline=True,device_scale_factor=1)
  page=await context.new_page();errors=[];messages=[];blocked=[];responses=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('console',lambda e:print('BROWSER',e.type,e.text,file=sys.stderr) if e.type=='error' else None)
  async def route(r):
   from urllib.parse import urlparse
   u=urlparse(r.request.url);path=(WEB/u.path.lstrip('/')).resolve()
   if u.netloc!='offline3d.local' or not path.is_relative_to(WEB) or not path.is_file():blocked.append(r.request.url);await r.abort();return
   mime={'mjs':'text/javascript','js':'text/javascript','css':'text/css','html':'text/html'}.get(path.suffix[1:],'application/octet-stream')
   await r.fulfill(body=path.read_bytes(),content_type=mime)
  await context.route('**/*',route)
  async def bridge(source,msg):
   messages.append(msg)
   if msg['type'] in ('click','size'):
    if msg['type']=='click':
     result=subprocess.run([DOTNET,str(TOOL),'probe',str(ROOT/'samples/SYNTHETIC-Offline3D.pdf'),str(msg['x']),str(msg['y'])],capture_output=True,text=True)
     if result.returncode:responses.append({'rejected':True});return
     point=json.loads(result.stdout)['graphics'];responses.append({'model':json.loads(result.stdout)['model']})
     if not any(x.get('type')=='scene' for x in responses):
      await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIXTURE/'scene.glb').read_bytes()).decode()});responses.append({'type':'scene'})
     bridge.last=point
    point=bridge.last
    await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box',**point,**{k:msg[k]/100 for k in ['width','above','below']}})
  await page.expose_binding('bridgeSend',bridge)
  await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>{window.hostCallback=f;}};")
  await page.goto('https://offline3d.local/index.html')
  await page.wait_for_function('!!window.hostCallback')
  await page.evaluate('m=>window.hostCallback({data:m})',{'type':'document','pdf':base64.b64encode((ROOT/'samples/SYNTHETIC-Offline3D.pdf').read_bytes()).decode(),'registered':True,'synthetic':True})
  await page.wait_for_function("document.getElementById('pdf').width>500")
  # True DOM click on PDF canvas corresponding to PDF (285,350) -> model (15,10,0).
  await page.locator('#pdf').click(position={'x':285,'y':792-350})
  try:await page.wait_for_function("document.getElementById('metrics').textContent.includes('meshes')",timeout=15000)
  except Exception:
   print(json.dumps({'messages':messages,'responses':responses,'errors':errors,'blocked':blocked,'hint':await page.locator('#hint').text_content()},indent=2),file=sys.stderr);raise
  assert abs(responses[0]['model']['x']-15)<1/15 and abs(responses[0]['model']['y']-10)<1/15, responses
  state=await page.evaluate("async()=>{const t=(await import('./app.mjs')).testing;window.__test=t;return {planes:[t.renderer.scene.clipPlane,t.renderer.scene.clipPlane2,t.renderer.scene.clipPlane3,t.renderer.scene.clipPlane4,t.renderer.scene.clipPlane5,t.renderer.scene.clipPlane6].length,meshes:t.renderer.scene.meshes.length,vertices:t.renderer.scene.meshes.reduce((sum,m)=>sum+m.getTotalVertices(),0),frames:t.renderer.frames,loadMs:t.renderer.started};}")
  assert state['planes']==6 and state['meshes']>=6 and state['vertices']>=216
  await page.locator('#width').fill('450');await page.locator('#width').dispatch_event('change')
  await page.wait_for_function("window.__test.renderer.pending.width===4.5")
  # Idle loop must settle instead of continually drawing.
  await page.wait_for_function("!window.__test.renderer.active")
  before=await page.evaluate("import('./app.mjs').then(m=>m.testing.renderer.frames)")
  await page.wait_for_timeout(300)
  after=await page.evaluate("import('./app.mjs').then(m=>m.testing.renderer.frames)");assert before==after
  # PDF.js device->page inverse covers rotations, zoom and DPR (canvas event uses CSS units).
  residual=await page.evaluate("async()=>{const {pdf}= (await import('./app.mjs')).testing;let max=0;for(const rotation of [0,90,180,270])for(const scale of [.5,1,2]){const v=pdf.page.getViewport({scale,rotation});const c=v.convertToViewportPoint(285,350);const q=v.convertToPdfPoint(...c);max=Math.max(max,Math.abs(q[0]-285),Math.abs(q[1]-350));}return max;}")
  assert residual<1e-9
  # A second location updates existing scene. Empty-room clicks do not require a host element.
  await page.locator('#pdf').click(position={'x':150,'y':792-275})
  await page.wait_for_timeout(250)
  assert len([r for r in responses if r.get('type')=='scene'])==1
  await page.locator('#pdf').click(position={'x':10,'y':100});await page.wait_for_timeout(200);assert responses[-1].get('rejected')
  await page.locator('#pdf').click(position={'x':150,'y':792-275});await page.wait_for_function('!window.__test.renderer.active');await page.screenshot(path=str(ROOT/'samples/viewer-adapter-preview.png'),full_page=True)
  assert not errors, errors
  assert not blocked,blocked
  assert not [m for m in messages if m['type']=='error'],messages
  print(json.dumps({'passed':['actual PDF canvas click -> C# package reader/ray service -> GLB -> six clipping planes','box width update','empty-room click reuses scene','outside-crop rejection','12 PDF viewport rotation/zoom roundtrips','idle rendering stops','offline routing with no external requests'], 'observed':state,'pdfCoordinateResidual':residual,'platform':'Linux Chromium/SwiftShader; simulated WebView2 bridge, real C# coordinate service','remoteRequests':blocked},indent=2))
  await browser.close()
asyncio.run(main())

using Offline3D;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp.Pdf.Advanced;
int count=0;
void Test(string name,Action f){f();count++;Console.WriteLine("PASS "+name);}
void Equal(double a,double b,double tolerance=1e-8){if(Math.Abs(a-b)>tolerance)throw new Exception($"{a} != {b}");}
void Throws(Action f){try{f();}catch(InvalidDataException){return;}catch(System.Text.Json.JsonException){return;}throw new Exception("Expected rejection");}
Registration Reg()=>new Registration{ViewId="v",LevelId="l",DocumentId="d",MediaBox=new[]{0d,0,612,792},PageCropBox=new[]{0d,0,612,792},CropPdf=new[]{0d,0,100,0,100,100,0,100},PreciseClicks=true,FitPointCount=3,CheckPointCount=3};
var rotate=new Matrix4(0,-2,0,15,2,0,0,-4,0,0,1,20,0,0,0,1);
Test("inverse and composition",()=>{var p=new Point3(3,7,9);var q=(rotate.Inverse()*rotate).Apply(p);Equal((q-p).Length,0);});
Test("singular inversion rejected",()=>Throws(()=>new Matrix4(new double[16]).Inverse()));
Test("large origin axis/unit roundtrip",()=>{var g=Matrix4.Graphics(new Point3(1000000,-2000000,100));var p=new Point3(1000003,-1999995,110);var q=g.Apply(p);Equal(q.X,.9144);Equal(q.Y,3.048);Equal(q.Z,-1.524);Equal((g.Inverse().Apply(q)-p).Length,0,1e-6);});
Test("translated rotated link applied once",()=>{var local=new Point3(2,1,0);var link=new Matrix4(0,-1,0,100,1,0,0,50,0,0,1,0,0,0,0,1);var q=(Matrix4.Graphics(new Point3(100,50))*link).Apply(local);Equal(q.X,-.3048);Equal(q.Z,-.6096);});
Test("plan ray uses declared ProjectElevation",()=>{var r=Reg();r.LevelProjectElevationFeet=123.4;var p=Coordinates.PlanClick(r,40,50);Equal(p.X,40);Equal(p.Y,50);Equal(p.Z,123.4);});
Test("crop rejects outside and accepts boundary",()=>{var r=Reg();Coordinates.PlanClick(r,0,50);Throws(()=>Coordinates.PlanClick(r,101,50));});
Test("uncalibrated clicks disabled",()=>{var r=Reg();r.PreciseClicks=false;Throws(()=>Coordinates.PlanClick(r,50,50));});
Test("horizontal ray unsupported",()=>{var r=Reg();r.ModelToPdf=new Matrix4(1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1);Throws(()=>Coordinates.PlanClick(r,50,50));});
Test("registration validation",()=>Contract.Validate(Reg()));
Test("nonfinite matrix rejected",()=>Throws(()=>new Matrix4(1,0,0,double.NaN,0,1,0,0,0,0,1,0,0,0,0,1)));
Test("self-crossing crop rejected",()=>{var r=Reg();r.CropPdf=new[]{0d,0,100,100,100,0,0,100};Throws(()=>Contract.Validate(r));});
Test("nonfinite registration rejected",()=>{var r=Reg();r.UserUnit=double.NaN;Throws(()=>Contract.Validate(r));});
Test("unknown schema rejected",()=>Throws(()=>Contract.Validate(new Manifest{SchemaVersion=2})));
var dummy=new Dictionary<string,byte[]>{{"registration.json",Contract.Encode(Reg())},{"identities.json",Contract.Encode(Array.Empty<ElementIdentity>())},{"scene.glb",GlbBuilder.Encode(new[]{GlbBuilder.Box("a",new Point3(),new Point3(2,3,4))},Matrix4.Graphics(new Point3()))}};
Manifest Man()=>PdfPackageService.Describe(true,"test", "test",dummy);
Test("valid manifest",()=>Contract.Validate(Man()));
Test("unknown required capability",()=>{var m=Man();m.RequiredCapabilities=new[]{"remote-code"};Throws(()=>Contract.Validate(m));});
Test("external resource URI rejected",()=>{var m=Man();m.Resources[0].Name="https://example.com/a.json";Throws(()=>Contract.Validate(m));});
Test("attachment traversal rejected",()=>{var m=Man();m.Resources[0].Name="../a.json";Throws(()=>Contract.Validate(m));});
Test("oversized resource rejected",()=>{var m=Man();m.Resources[0].Size=Contract.MaxResource+1;Throws(()=>Contract.Validate(m));});
Test("duplicate resource IDs rejected",()=>{var m=Man();m.Resources[1].Id=m.Resources[0].Id;Throws(()=>Contract.Validate(m));});
Test("malformed JSON rejected",()=>Throws(()=>Contract.Decode<Manifest>(new byte[]{123,125,1})));
Test("GLB header and local payload",()=>Contract.ValidateGlb(dummy["scene.glb"]));
Test("GLB nonfinite vertex rejected",()=>{var g=(byte[])dummy["scene.glb"].Clone();int jsonLength=(int)BitConverter.ToUInt32(g,12);int binStart=28+jsonLength;Array.Copy(BitConverter.GetBytes(float.NaN),0,g,binStart,4);Throws(()=>Contract.ValidateGlb(g));});
Test("GLB length mismatch rejected",()=>{var g=(byte[])dummy["scene.glb"].Clone();g[8]=0;Throws(()=>Contract.ValidateGlb(g));});
Test("GLB external URI rejected",()=>{using var ms=new MemoryStream();using var w=new BinaryWriter(ms);var json=System.Text.Encoding.UTF8.GetBytes("{\"asset\":{\"version\":\"2.0\"},\"buffers\":[{\"uri\":\"https://x\",\"byteLength\":0}]} ");int pad=(json.Length+3)&~3;w.Write(0x46546c67u);w.Write(2u);w.Write(28+pad);w.Write(pad);w.Write(0x4e4f534au);w.Write(json);for(int i=json.Length;i<pad;i++)w.Write((byte)32);w.Write(0);w.Write(0x004e4942u);Throws(()=>Contract.ValidateGlb(ms.ToArray()));});
ControlPoint C(double x,double y)=>new ControlPoint{SheetX=x,SheetY=y,PdfX=200-y*90,PdfY=100+x*90};
var controls=new CalibrationInput{Fit=new[]{C(0,0),C(1,0),C(0,1),C(1,1)},Check=new[]{C(.2,.2),C(.8,.3),C(.4,.9)}};
Test("calibration scale/rotation + independent checks",()=>{var fit=Calibration.Fit(controls,Matrix4.Identity,0);Equal(fit.MaxResidualMetres,0);var p=fit.SheetToPdf.Apply(new Point3(.3,.7));Equal(p.X,137);Equal(p.Y,127);});
Test("calibration rejects >1 mm residual",()=>{var bad=Contract.Decode<CalibrationInput>(Contract.Encode(controls));bad.Check[0].PdfX+=2;Throws(()=>Calibration.Fit(bad,Matrix4.Identity,0));});
Test("calibration rejects reused checks",()=>{var bad=Contract.Decode<CalibrationInput>(Contract.Encode(controls));bad.Check[0]=bad.Fit[0];Throws(()=>Calibration.Fit(bad,Matrix4.Identity,0));});
Test("calibration rejects collinear controls",()=>{var bad=new CalibrationInput{Fit=new[]{C(0,0),C(1,0),C(2,0)},Check=controls.Check};Throws(()=>Calibration.Fit(bad,Matrix4.Identity,0));});
string temp=Path.Combine(Path.GetTempPath(),"offline3d-tests-"+Guid.NewGuid());Directory.CreateDirectory(temp);
try{
    string plain=Path.Combine(temp,"original.pdf"),output=Path.Combine(temp,"packaged.pdf");
    using(var pdf=new PdfDocument()){var page=pdf.AddPage();page.Width=PdfSharp.Drawing.XUnit.FromPoint(612);page.Height=PdfSharp.Drawing.XUnit.FromPoint(792);pdf.AddEmbeddedFile("unrelated.txt",new MemoryStream(new byte[]{1,2,3}));pdf.Save(plain);}
    var service=new PdfPackageService();
    Test("attachment write/read/reopen round trip",()=>{service.Write(plain,output,Man(),dummy);var p=service.Read(output);if(p.Glb.Length!=dummy["scene.glb"].Length)throw new Exception("GLB changed");});
    Test("unrelated attachment preserved",()=>{using var pdf=PdfReader.Open(output,PdfDocumentOpenMode.Import);var names=pdf.Internals.Catalog.Elements.GetDictionary("/Names")!.Elements.GetDictionary("/EmbeddedFiles")!.Elements.GetArray("/Names")!;if(!names.Elements.OfType<PdfString>().Any(s=>s.Value=="unrelated.txt"))throw new Exception("Lost unrelated file");});
    Test("safe replacement of existing destination",()=>{service.Write(plain,output,Man(),dummy);service.Read(output);});
    Test("bad descriptor leaves destination intact",()=>{var before=File.ReadAllBytes(output);var m=Man();m.Resources[0].Sha256=new string('a',64);Throws(()=>service.Write(plain,output,m,dummy));if(!before.SequenceEqual(File.ReadAllBytes(output)))throw new Exception("Destination changed");});
    Test("rotated cropped UserUnit page roundtrip",()=>{string rotated=Path.Combine(temp,"rotated.pdf");using(var pdf=PdfReader.Open(plain,PdfDocumentOpenMode.Modify)){var page=pdf.Pages[0];page.Rotate=90;page.CropBox=new PdfRectangle(new PdfSharp.Drawing.XPoint(10,20),new PdfSharp.Drawing.XPoint(590,760));page.Elements.SetReal("/UserUnit",2);pdf.Save(rotated);}var r=Reg();PdfPackageService.SetPageGeometry(rotated,r);var files=new Dictionary<string,byte[]>(dummy){["registration.json"]=Contract.Encode(r)};service.Write(rotated,output,PdfPackageService.Describe(true,"rotation","test",files),files);var p=service.Read(output);Equal(p.Registration.UserUnit,2);Equal(p.Registration.Rotation,90);Equal(p.Registration.PageCropBox[0],10);});
    Test("actual page geometry mismatch rejected",()=>{var files=new Dictionary<string,byte[]>(dummy);var r=Reg();r.MediaBox[2]=600;files["registration.json"]=Contract.Encode(r);Throws(()=>service.Write(plain,output,PdfPackageService.Describe(true,"mismatch","test",files),files));});
    Test("copy PDF alone independent of intermediates/cache",()=>{var copy=Path.Combine(temp,"copy.pdf");File.Copy(output,copy);File.Delete(plain);service.Read(copy);});
}finally{Directory.Delete(temp,true);}
AutomaticTests.Run(Test,Throws,Equal);
VisualTests.Run(Test,Throws,Equal);
Console.WriteLine($"{count} automated checks passed.");

import asyncio,base64,json,pathlib,math
from urllib.parse import urlparse
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1];WEB=ROOT/'src/Viewer/web';FIX=pathlib.Path('/workspace/work/browser-v04')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
  try:
   context=await browser.new_context(offline=True,viewport={'width':760,'height':900});page=await context.new_page();errors=[];events=[];results=[]
   page.on('pageerror',lambda e:errors.append(str(e.stack)[:2000]));page.on('console',lambda m:print('BROWSER',m.type,m.text[:500],flush=True) if m.type=='error' else None)
   async def route(r):
    u=urlparse(r.request.url);f=(WEB/u.path.lstrip('/')).resolve()
    if u.netloc!='offline3d.local' or not f.is_relative_to(WEB) or not f.is_file():await r.abort();return
    await r.fulfill(body=f.read_bytes(),content_type={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm'}.get(f.suffix,'application/octet-stream'))
   await context.route('**/*',route);await page.expose_binding('bridgeSend',lambda _,m:events.append(m));await page.add_init_script("window.chrome=window.chrome||{};window.chrome.webview={postMessage:m=>window.bridgeSend(m),addEventListener:(t,f)=>window.hostCallback=f};")
   async def setting(control,value):
    if not await page.locator('#settings-panel').is_visible():await page.locator('#settings-toggle').click()
    await page.locator('#'+control).select_option(value)
    if await page.locator('#settings-panel').is_visible():await page.locator('#settings-toggle').click()
   async def tool(control):
    if not await page.locator('#tools-panel').is_visible():await page.locator('#tools-toggle').click()
    await page.locator('#'+control).click()
    if await page.locator('#tools-panel').is_visible():await page.locator('#tools-toggle').click()
   await page.goto('https://offline3d.local/three.html');await page.wait_for_function('!!window.hostCallback');await page.evaluate("async()=>{window.module=await import('/three.mjs');}");await setting('quality','low')
   await page.locator('#settings-toggle').click()
   assert await page.locator('#unit-feet').get_attribute('aria-pressed')=='true'
   assert [await page.locator('#default-'+k).input_value() for k in ['square','above','below']]==['10.00','10.00','0.50']
   await page.locator('#unit-meters').click()
   assert [await page.locator('#default-'+k).input_value() for k in ['square','above','below']]==['3.0480','3.0480','0.1524']
   for _ in range(5):
    await page.locator('#unit-feet').click();await page.locator('#unit-meters').click()
   await page.locator('#save-box-defaults').click();pref=[m for m in events if m.get('type')=='setBoxDefaults'][-1];assert pref['square']==3.048 and pref['below']==.1524 and pref['unit']=='meters'
   await page.evaluate('m=>hostCallback({data:m})',{'type':'boxDefaults','square':6.096,'above':4.572,'below':.3048,'unit':'feet'})
   assert [await page.locator('#default-'+k).input_value() for k in ['square','above','below']]==['20.00','15.00','1.00']
   await page.locator('#default-square').fill('12');await page.locator('#save-box-defaults').click();pref=[m for m in events if m.get('type')=='setBoxDefaults'][-1];assert abs(pref['square']-3.6576)<1e-9 and pref['above']==4.572 and pref['unit']=='feet'
   n=len([m for m in events if m.get('type')=='setBoxDefaults']);await page.locator('#default-square').fill('0');await page.locator('#save-box-defaults').click();assert len([m for m in events if m.get('type')=='setBoxDefaults'])==n;assert await page.locator('#defaults-status').get_attribute('class')=='error'
   await page.evaluate('m=>hostCallback({data:m})',{'type':'boxDefaults','square':3.048,'above':3.048,'below':.1524,'unit':'feet'});await page.locator('#settings-toggle').click()
   assert await page.locator('#engine option').count()==2;assert await page.locator('.dimensions').count()==0;assert await page.locator('#view-preset').count()==0
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'scene','glb':base64.b64encode((FIX/'scene.glb').read_bytes()).decode(),'identities':json.loads((FIX/'identities.json').read_text())})
   await page.evaluate('m=>window.hostCallback({data:m})',{'type':'box','x':4.57,'y':0,'z':-.15,'width':10,'depth':3,'above':4,'below':.5})
   for name in ['babylon','three']:
    print('ENGINE',name,flush=True)
    if await page.locator('#engine').input_value()!=name:await setting('engine',name)
    await page.wait_for_function("()=>module.testing.renderer.loaded&&!document.querySelector('#engine').disabled",timeout=90000);await page.evaluate('()=>{window.r=module.testing.renderer;}');await page.wait_for_timeout(700)
    if name=='three':await page.wait_for_function('r.ready',timeout=30000)
    print('MODELS',await page.evaluate("()=>r.models?r.models.map(m=>({name:m.name,type:m.getClassName(),material:m.material?.getClassName()})):r.model.children.map(m=>m.name)"),flush=True)
    rect=await page.locator('#scene').bounding_box();cube=await page.locator('.view-cube').bounding_box();assert cube['width']<=48
    # First drag after a new engine/view opens must already track the pointer.
    await page.evaluate('()=>{window.initialPan=[...r.getCameraState().target];}');original=await page.evaluate('r.project(initialPan)');x=rect['x']+40;y=rect['y']+45
    await page.mouse.move(x,y);await page.mouse.down(button='middle');await page.mouse.move(x+65,y+25,steps=6);await page.mouse.up(button='middle');await page.wait_for_timeout(150);shifted=await page.evaluate('r.project(initialPan)');assert abs(shifted['x']-original['x']-65)<2 and abs(shifted['y']-original['y']-25)<2,(name,original,shifted)
    # Faster zoom and no old close-distance clamp.
    old=await page.evaluate('r.getCameraState()');await page.mouse.move(rect['x']+rect['width']*.28,rect['y']+rect['height']*.5);await page.mouse.wheel(0,-120);await page.wait_for_timeout(150);new=await page.evaluate('r.getCameraState()');assert new['radius']/old['radius']<.8,(name,old,new);assert math.dist(old['target'],new['target'])>.01
    await page.evaluate('()=>{const s=r.getCameraState();s.radius=.01;r.setCameraState(s);}');await page.mouse.wheel(0,-120);await page.wait_for_timeout(100);assert await page.evaluate('r.getCameraState().radius')<.009
    await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Geometry properties from real model picking.
    point=await page.evaluate("()=>{if(r.camera.mode!==undefined){const B=BABYLON,m=r.models.find(m=>m.name==='wall/0'),v=m.getBoundingInfo().boundingBox.centerWorld,p=B.Vector3.Project(v,B.Matrix.Identity(),r.scene.getTransformMatrix(),r.camera.viewport.toGlobal(r.engine.getRenderWidth(),r.engine.getRenderHeight())),rect=document.querySelector('#scene').getBoundingClientRect();return{x:rect.x+p.x/r.engine.getRenderWidth()*rect.width,y:rect.y+p.y/r.engine.getRenderHeight()*rect.height};}return r.project([1.524,1.524,-.1524]);}")
    print('PICK POINT',point,flush=True);await page.mouse.click(point['x'],point['y']);await page.wait_for_timeout(300);assert await page.locator('#properties').is_visible(),(name,point,await page.locator('#hint').inner_text());assert '123' in await page.locator('#property-values').inner_text()
    await page.evaluate("()=>{window.visibleNames=()=>r.models?r.models.filter(m=>m.isEnabled()).map(m=>m.name):r.model.children.filter(m=>(m.isMesh||m.isLine)&&m.visible&&!m.name.startsWith('__o3d')).map(m=>m.name);}")
    await tool('isolate-selection');await page.wait_for_timeout(100);assert all(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await tool('show-all');await tool('xray-selection');await page.wait_for_timeout(100)
    assert await page.evaluate("()=>r.models?r.models.find(m=>m.name==='wall2/0').visibility<.2:r.model.children.find(m=>m.name==='wall2/0').material.opacity<.2")
    await tool('show-all');await tool('hide-selection');await page.wait_for_timeout(100)
    assert not any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await tool('show-all');assert any(n.startswith('wall/') for n in await page.evaluate('visibleNames()'))
    await tool('focus-selection');await page.wait_for_timeout(600);await page.locator('#reset').click();await page.wait_for_timeout(600)
    # Compact grip sizes stay fixed as the model/box size changes.
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:500,depth:500,above:100,below:100},true)');await page.wait_for_timeout(300);assert await page.evaluate('r.bounds.max[0]-r.bounds.min[0]')>400
    await tool('box-reset');assert any(m.get('type')=='resetBounds' for m in events)
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:10,depth:3,above:4,below:.5},true)');await page.wait_for_timeout(500)
    assert await page.locator('.section-grip').count()==6
    assert await page.evaluate("()=>document.querySelector('.section-outline path').getAttribute('d').match(/M/g).length===12&&getComputedStyle(document.querySelector('.section-outline path')).strokeWidth==='1px'")
    assert await page.evaluate("Array.from(document.querySelectorAll('.section-grip svg')).every(s=>getComputedStyle(s).width==='24px')")
    assert await page.evaluate("()=>r.models?!r.scene.meshes.some(m=>m.name.startsWith('Stretch ')):!r.model.children.some(m=>m.name.startsWith('__o3dHandle'))")
    # Click well outside the small glyph, inside its transparent grab target.
    grip=page.locator('.section-grip[data-axis="0"][data-side="max"]');await grip.wait_for(state='visible');box=await grip.bounding_box()
    axis=await page.evaluate("()=>{const r=module.testing.renderer,b=r.bounds,p=b.min.map((v,k)=>(v+b.max[k])/2);p[0]=b.max[0];const q=[...p];q[0]+=1;const a=r.project(p),z=r.project(q);return{x:z.x-a.x,y:z.y-a.y};}")
    length=math.hypot(axis['x'],axis['y']);dx=axis['x']/length;dy=axis['y']/length
    before=await page.evaluate('structuredClone(r.bounds)');camera_before=await page.evaluate('r.getCameraState()')
    x=box['x']+box['width']/2-dy*16;y=box['y']+box['height']/2+dx*16
    await page.mouse.move(x,y);assert await page.evaluate("p=>document.elementFromPoint(p.x,p.y)?.closest('.section-grip')?.dataset.axis",{'x':x,'y':y})=='0'
    await page.mouse.down();await page.wait_for_timeout(80);assert await page.evaluate('r.bounds.max[0]')==before['max'][0]
    await page.mouse.move(x+dx*40,y+dy*40,steps=8);await page.mouse.up();await page.wait_for_timeout(250)
    after=await page.evaluate('structuredClone(r.bounds)');assert after['max'][0]>before['max'][0]+.01
    assert abs(after['max'][0]-before['max'][0]-40/length)<.025
    assert after['min']==before['min'] and after['max'][1:]==before['max'][1:]
    assert math.dist(camera_before['target'],(await page.evaluate('r.getCameraState()'))['target'])<1e-6
    # Native host echoes committed bounds: do not recenter the camera at release.
    echo=await page.evaluate("()=>({...r.toMessage(),type:'box'})");await page.evaluate('m=>window.hostCallback({data:m})',echo);await page.wait_for_timeout(150)
    assert math.dist(camera_before['target'],(await page.evaluate('r.getCameraState()'))['target'])<1e-6
    # A selected object's centre is the orbit pivot even when dragging empty space.
    await page.evaluate("()=>{r.select('wall/0');window.selectedCentre=r.modelBounds('wall/0');selectedCentre=selectedCentre.min.map((v,k)=>(v+selectedCentre.max[k])/2);}")
    p0=await page.evaluate('r.project(selectedCentre)');a0=await page.evaluate('r.getCameraState().alpha')
    rect=await page.locator('#scene').bounding_box();x=rect['x']+25;y=rect['y']+25
    await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+50,y+20,steps=8);await page.mouse.up();await page.wait_for_timeout(300)
    p1=await page.evaluate('r.project(selectedCentre)');assert math.hypot(p1['x']-p0['x'],p1['y']-p0['y'])<2,(name,p0,p1)
    assert abs(await page.evaluate('r.getCameraState().alpha')-a0)>.1
    await tool('clear-selection');assert await page.evaluate('r.orbitSelection') is None
    # Menus overlay the canvas; opening them never changes camera viewport size.
    assert not await page.locator('#settings-panel').is_visible() and not await page.locator('#tools-panel').is_visible()
    viewport=await page.locator('#scene').bounding_box();assert viewport['height']>800
    await page.locator('#settings-toggle').click();assert await page.locator('#scene').bounding_box()==viewport;await page.locator('#settings-toggle').click()
    await page.locator('#tools-toggle').click();assert await page.locator('#scene').bounding_box()==viewport;await page.locator('#tools-toggle').click()
    # Pan tracks the same 80/35 CSS pixels when zoomed out and very close.
    for radius in [20,.05]:
     await page.evaluate('radius=>{const s=r.getCameraState();s.radius=radius;r.setCameraState(s);window.panPoint=[...s.target];}',radius);await page.wait_for_timeout(200)
     original=await page.evaluate('r.project(panPoint)');angles=await page.evaluate('r.getCameraState()');rect=await page.locator('#scene').bounding_box();x=rect['x']+45;y=rect['y']+45
     await page.mouse.move(x,y);await page.mouse.down(button='middle');await page.mouse.move(x+80,y+35,steps=8);await page.mouse.up(button='middle');await page.wait_for_timeout(200)
     shifted=await page.evaluate('r.project(panPoint)');assert abs(shifted['x']-original['x']-80)<2 and abs(shifted['y']-original['y']-35)<2,(name,radius,original,shifted)
     assert abs((await page.evaluate('r.getCameraState()'))['alpha']-angles['alpha'])<1e-6
    # A single wheel notch almost doubles zoom; stock-box fit keeps orientation.
    await page.mouse.move(rect['x']+rect['width']*.5,rect['y']+rect['height']*.5);before_zoom=await page.evaluate('r.getCameraState().radius');await page.mouse.wheel(0,-120);await page.wait_for_timeout(150);assert .48<await page.evaluate('r.getCameraState().radius')/before_zoom<.56
    previous=await page.evaluate('r.getCameraState()');await page.evaluate('m=>hostCallback({data:m})',{'type':'box','x':4.57,'y':0,'z':-.15,'width':3.048,'depth':3.048,'above':3.048,'below':.1524,'fitBox':True});await page.wait_for_timeout(200)
    assert abs(await page.evaluate('r.bounds.max[0]-r.bounds.min[0]')-3.048)<1e-8
    assert abs(await page.evaluate('r.getCameraState().alpha')-previous['alpha'])<1e-6
    assert await page.evaluate('r.getCameraState().radius')>1
    await page.evaluate('()=>r.box({x:4.57,y:0,z:-.15,width:10,depth:3,above:4,below:.5},true)');await page.wait_for_timeout(250)
    # Middle drag pans without changing orientation; top view hides head-on grips.
    before_pan=await page.evaluate('r.getCameraState()');await page.mouse.move(rect['x']+30,rect['y']+50);await page.mouse.down(button='middle');await page.mouse.move(rect['x']+70,rect['y']+70,steps=6);await page.mouse.up(button='middle');await page.wait_for_timeout(400);after_pan=await page.evaluate('r.getCameraState()')
    assert math.dist(before_pan['target'],after_pan['target'])>.01 and abs(before_pan['alpha']-after_pan['alpha'])<1e-6
    await page.locator('.view-cube').focus();await page.locator('.view-cube').press('PageUp');await page.wait_for_timeout(300);assert await page.locator('.section-grip:visible').count()==4
    await page.locator('.view-cube').press('Home');await page.wait_for_timeout(300)
    for style in ['realistic','colors','wireframe','shaded']:
     await setting('style',style);await page.wait_for_timeout(250)
    await page.screenshot(path=str(ROOT/f'samples/v05-{name}.png'));assert not errors,errors
    results.append({'engine':name,'passed':['only Babylon and Three retained','size controls moved into defaults settings; view dropdown removed','half-size cube','faster cursor-centred wheel zoom','close zoom has no 8 cm clamp','shared indexed geometry loads','actual picking exposes element ID 123','hide/isolate/X-ray/show-all controls run','300 ms focus and Home controls run','500 m section box accepted','reset saved-size message sent','all display styles load','six compact paired-triangle grips with no cones','grip size stays fixed on screen','off-glyph grab area starts drag without jumping','drag moves only its face by projected distance','camera stays fixed on commit and host echo','selected-object centre stays fixed during orbit','clear selection restores pointer orbit','middle drag pans without orbiting','top view hides head-on grips','twelve box edges drawn at a fixed one-pixel width','collapsed menus leave over 800 px for the model','menus do not resize the canvas','pan follows pixels consistently at wide and close zoom','one wheel notch almost doubles zoom','stock-box fit preserves orientation and restores usable zoom','first drag after opening already tracks pixels']})
   assert not any(m.get('type')=='error' for m in events),events
   (ROOT/'tests/viewer-v051-regression-results.json').write_text(json.dumps({'boxDefaultsPassed':['factory feet values visible','metres conversion','unit toggles preserve physical sizes','saved host defaults restore fields','edits sent in metres','zero square rejected'],'results':results,'platform':'Linux Chromium/SwiftShader with simulated native host; Windows input and physical GPU performance untested'},indent=2)+'\n');print('PASS',json.dumps(results),flush=True)
  finally:await browser.close()
asyncio.run(main())

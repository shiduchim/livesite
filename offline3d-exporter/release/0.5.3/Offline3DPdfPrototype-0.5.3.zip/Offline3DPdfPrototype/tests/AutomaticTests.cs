using Offline3D;
using Offline3D.Automatic;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
internal static class AutomaticTests
{
    public static void Run(Action<string,Action> test,Action<Action> throws,Action<double,double,double> equal){
        string folder=Path.Combine(Path.GetTempPath(),"Offline3DExport-test-"+Guid.NewGuid());Directory.CreateDirectory(folder);
        var reg=new Registration{ModelToSheet=new Matrix4(.02,0,0,0,0,.02,0,0,0,0,1,0,0,0,0,1),LevelProjectElevationFeet=10,CropSheet=new[]{0d,0,.6,0,.6,.4,0,.4}};
        var markers=AutomaticExport.Markers(reg.CropSheet);var transform=new Matrix4(750,0,0,60,0,750,0,200,0,0,1,0,0,0,0,1);
        string Clean(int rotation=0,bool collide=false){string path=Path.Combine(folder,"clean-"+rotation+"-"+collide+".pdf");Write(path,false,rotation,collision:collide);return path;}
        string Marked(int rotation=0,int omit=-1,bool wrong=false,bool shifted=false,bool nested=false){string path=Path.Combine(folder,$"marked-{rotation}-{omit}-{wrong}-{shifted}-{nested}.pdf");Write(path,true,rotation,omit,wrong,shifted,nested);return path;}
        void Write(string path,bool marks,int rotation,int omit=-1,bool wrong=false,bool shifted=false,bool nested=false,bool collision=false){
            using var pdf=new PdfDocument();var page=pdf.AddPage();page.Width=XUnit.FromPoint(612);page.Height=XUnit.FromPoint(792);page.Rotate=rotation;
            page.CropBox=new PdfRectangle(new XPoint(10,20),new XPoint(600,780));page.Elements.SetReal("/UserUnit",2);
            using(var g=XGraphics.FromPdfPage(page)){
                g.DrawRectangle(new XPen(XColors.Black,1),70+(wrong?2:0),300,400,280);
                if(collision)g.DrawLine(new XPen(XColor.FromArgb(241,7,229)),20,20,40,20);
                void DrawMarkers(XGraphics graphics){foreach(var m in markers){if(m.Id==omit)continue;var p=transform.Apply(new Point3(m.SheetX,m.SheetY));double shift=shifted&&m.Id==12?3:0;var pen=new XPen(XColor.FromArgb(m.Red,m.Green,m.Blue),.5);graphics.DrawLine(pen,p.X+shift,792-p.Y,p.X+shift+6,792-p.Y);graphics.DrawLine(pen,p.X+shift,792-p.Y,p.X+shift,792-p.Y-4);}}
                if(marks){if(nested){using var form=new XForm(pdf,XUnit.FromPoint(612),XUnit.FromPoint(792));using(var fg=XGraphics.FromForm(form))DrawMarkers(fg);g.DrawImage(form,0,0);}else DrawMarkers(g);}
            }pdf.Save(path);
        }
        try{
            test("automatic 25-marker registration, 12 fit + 13 independent checks",()=>{var r=AutomaticRegistrationService.Register(Clean(),Marked(),reg,markers);if(r.Controls.Fit.Length!=12||r.Controls.Check.Length!=13||r.MarkerCount!=25)throw new Exception("Wrong control partition");equal(r.Calibration.MaxResidualMetres,0,1e-5);var p=r.Calibration.SheetToPdf.Apply(new Point3(.2,.3));equal(p.X,210,.001);equal(p.Y,425,.001);});
            test("automatic mapping handles nested PDF form transforms",()=>{var r=AutomaticRegistrationService.Register(Clean(),Marked(nested:true),reg,markers);equal(r.Calibration.MaxResidualMetres,0,1e-5);});
            foreach(int rotation in new[]{90,180,270})test("automatic registration respects actual rotated/cropped UserUnit page "+rotation,()=>{var r=AutomaticRegistrationService.Register(Clean(rotation),Marked(rotation),reg,markers);equal(r.Calibration.MaxResidualMetres,0,1e-5);});
            test("automatic mapping rejects missing registration marker",()=>throws(()=>AutomaticRegistrationService.Register(Clean(),Marked(omit:4),reg,markers)));
            test("automatic mapping rejects independent numeric outlier",()=>throws(()=>AutomaticRegistrationService.Register(Clean(),Marked(shifted:true),reg,markers)));
            test("automatic mapping rejects changed clean drawing",()=>throws(()=>AutomaticRegistrationService.Register(Clean(),Marked(wrong:true),reg,markers)));
            test("automatic mapping rejects drawing/marker color collision",()=>throws(()=>AutomaticRegistrationService.Register(Clean(collide:true),Marked(),reg,markers)));
            test("automatic mapping rejects inconsistent actual page geometry",()=>throws(()=>AutomaticRegistrationService.Register(Clean(),Marked(90),reg,markers)));
            void Request(string dir,string marked){
                Directory.CreateDirectory(dir);File.Copy(Clean(),Path.Combine(dir,"drawing-clean.pdf"));File.Copy(marked,Path.Combine(dir,"drawing-marked.pdf"));
                reg.ViewId="synthetic-auto-view";reg.LevelId="synthetic-level";reg.DocumentId="synthetic-document";
                File.WriteAllBytes(Path.Combine(dir,"registration.draft.json"),Contract.Encode(reg));File.WriteAllBytes(Path.Combine(dir,"markers.json"),Contract.Encode(markers));
                File.WriteAllBytes(Path.Combine(dir,"identities.json"),Contract.Encode(new[]{new ElementIdentity{UniqueId="synthetic-floor",DocumentId=reg.DocumentId,MeshName="floor"}}));
                File.WriteAllBytes(Path.Combine(dir,"scene.glb"),GlbBuilder.Encode(new[]{GlbBuilder.Box("floor",new Point3(0,0,9),new Point3(30,20,10))},reg.ModelToGraphics));
                File.WriteAllText(Path.Combine(dir,"exporter-version.txt"),"synthetic native PDF registration test");File.WriteAllLines(Path.Combine(dir,"exclusions.txt"),new[]{"Synthetic only"});File.WriteAllText(Path.Combine(dir,"synthetic.flag"),"");
            }
            test("automatic finalizer delivers one enhanced PDF without manual controls",()=>{
                string dir=Path.Combine(folder,"Offline3DExport-finalizer");Request(dir,Marked());string output=Path.Combine(folder,"synthetic-enhanced.pdf");ExportFinalizer.Export(dir,output);
                var package=new PdfPackageService().Read(output);if(!package.Manifest.Synthetic||package.Registration.CheckPointCount!=13||Directory.Exists(dir))throw new Exception("Invalid finalized package/cleanup");
                var point=Coordinates.PlanClick(package.Registration,285,350);equal(point.X,15,.001);equal(point.Y,10,.001);equal(point.Z,10,.001);
            });
            test("failed automatic finalization preserves existing destination and diagnostics",()=>{
                string dir=Path.Combine(folder,"Offline3DExport-failed");Request(dir,Marked(omit:4));string output=Path.Combine(folder,"synthetic-enhanced.pdf");var before=File.ReadAllBytes(output);throws(()=>ExportFinalizer.Export(dir,output));if(!before.SequenceEqual(File.ReadAllBytes(output))||!Directory.Exists(dir))throw new Exception("Failed export corrupted destination/diagnostics");
            });
        }finally{Directory.Delete(folder,true);}
    }
}

using Offline3D;
using System.Text.Json;

internal static class VisualTests
{
 public static void Run(Action<string,Action> test,Action<Action> throws,Action<double,double,double> equal){
  test("per-face materials preserve linear color opacity and surface properties",()=>{
   var red=GlbBuilder.Box("same-element/face-red",new Point3(),new Point3(1,1,1));red.Material=new PlainMaterial{Name="Red paint",Red=1,Green=.1,Blue=.05,Opacity=.6,Roughness=.2,Metallic=.8};
   var blue=GlbBuilder.Box("same-element/face-blue",new Point3(2,0,0),new Point3(3,1,1));blue.Material=new PlainMaterial{Name="Blue paint",Red=.1,Green=.2,Blue=.9};
   var bytes=GlbBuilder.Encode(new[]{red,blue},Matrix4.Graphics(new Point3()));Contract.ValidateGlb(bytes);using var json=JsonDocument.Parse(new ReadOnlyMemory<byte>(bytes,20,(int)BitConverter.ToUInt32(bytes,12)));var materials=json.RootElement.GetProperty("materials");if(materials.GetArrayLength()!=2)throw new Exception("Merged painted faces");var pbr=materials[0].GetProperty("pbrMetallicRoughness");equal(pbr.GetProperty("baseColorFactor")[1].GetDouble(),PlainMaterial.Linear(.1),1e-12);equal(pbr.GetProperty("baseColorFactor")[3].GetDouble(),.6,1e-12);equal(pbr.GetProperty("metallicFactor").GetDouble(),.8,1e-12);if(materials[0].GetProperty("alphaMode").GetString()!="BLEND")throw new Exception("Lost transparency");
  });
  test("sRGB transfer anchors",()=>{equal(PlainMaterial.Linear(0),0,1e-12);equal(PlainMaterial.Linear(1),1,1e-12);equal(PlainMaterial.Linear(.5),.21404114048223255,1e-12);});
  test("invalid material values rejected",()=>{var m=GlbBuilder.Box("bad",new Point3(),new Point3(1,1,1));m.Material.Red=double.NaN;throws(()=>GlbBuilder.Encode(new[]{m},Matrix4.Identity));m.Material.Red=2;throws(()=>GlbBuilder.Encode(new[]{m},Matrix4.Identity));});
  test("source smooth normals use inverse transpose and graphics axes",()=>{var m=new PlainMesh{Name="smooth",Triangles=new(){new(0,0,0),new(1,0,0),new(0,1,0)},Normals=new(){new(0,0,1),new(0,0,1),new(0,0,1)}};var bytes=GlbBuilder.Encode(new[]{m},Matrix4.Graphics(new Point3()));Contract.ValidateGlb(bytes);int start=28+(int)BitConverter.ToUInt32(bytes,12)+36;equal(BitConverter.ToSingle(bytes,start),0,1e-6);equal(BitConverter.ToSingle(bytes,start+4),1,1e-6);equal(BitConverter.ToSingle(bytes,start+8),0,1e-6);});
  test("mismatched normals rejected",()=>{var m=GlbBuilder.Box("bad",new Point3(),new Point3(1,1,1));m.Normals.Add(new Point3(0,0,1));throws(()=>GlbBuilder.Encode(new[]{m},Matrix4.Identity));});
  var reg=new Registration{ModelToGraphics=Matrix4.Graphics(new Point3(1000,2000,50)),ModelToPdf=new Matrix4(0,-2,0,4000,2,0,0,-2000,0,0,1,0,0,0,0,1)};
  test("asymmetric section footprint agrees with rotated model mapping",()=>{var b=BoxVolume.Centered(new Point3(1,0,-2),3,5,4,0);b.MinX-=1;b.Validate();var points=b.PdfFootprint(reg);var model=reg.ModelToGraphics.Inverse().Apply(new Point3(b.MinX,b.Level,b.MinZ));var expected=reg.ModelToPdf.Apply(model);equal(points[0].X,expected.X,1e-9);equal(points[0].Y,expected.Y,1e-9);equal(b.Width,4,1e-12);equal(b.Depth,5,1e-12);});
  test("section dimensions reject inversion nonfinite and overbudget sizes",()=>{throws(()=>BoxVolume.Centered(new Point3(),0,3,3,0));throws(()=>BoxVolume.Centered(new Point3(),3,20000001,3,0));throws(()=>BoxVolume.Centered(new Point3(),3,3,3,-1));throws(()=>BoxVolume.Centered(new Point3(double.NaN,0,0),3,3,3,0));});
  test("viewport ambiguity guard permits disjoint bodies and rejects containment",()=>{var a=new Offline3D.RevitExporter.SheetBounds(0,0,2,2);if(a.Overlaps(new(2,0,4,2)))throw new Exception("Touching edges rejected");if(!a.Overlaps(new(1,1,3,3))||!a.Overlaps(new(.2,.2,1,1)))throw new Exception("Overlap missed");});
 }
}

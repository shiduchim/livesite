using System.IO;
using System.Text.Json;
using System.Windows;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Core;

namespace Offline3D.Viewer;
public partial class MainWindow:Window
{
    private const string Origin="https://offline3d.local";
    private readonly IPdfPackageService packages=new PdfPackageService();
    private CancellationTokenSource? opening;
    private OpenPackage? package;
    private byte[]? pdf;
    private bool ready,sceneSent;
    private Point3? selected;
    private readonly Dictionary<string,string> allowed=new(StringComparer.Ordinal){["/index.html"]="text/html",["/app.mjs"]="text/javascript",["/renderer.mjs"]="text/javascript",["/sections.mjs"]="text/javascript",["/section-worker.mjs"]="text/javascript",["/vendor/earcut.js"]="text/javascript",["/vendor/studio.env"]="application/octet-stream",["/vendor/glslang.js"]="text/javascript",["/vendor/glslang.wasm"]="application/wasm",["/vendor/twgsl.js"]="text/javascript",["/vendor/twgsl.wasm"]="application/wasm",["/style.css"]="text/css",["/vendor/babylon.js"]="text/javascript",["/vendor/loaders.js"]="text/javascript",["/vendor/pdf.mjs"]="text/javascript",["/vendor/pdf.worker.mjs"]="text/javascript"};
    public MainWindow(){InitializeComponent();Loaded+=async(_,_)=>await Initialize();Closed+=(_,_)=>{opening?.Cancel();opening?.Dispose();Browser.Dispose();};}
    private async Task Initialize(){try{
        string? runtime=Path.Combine(AppContext.BaseDirectory,"WebView2Runtime");
        if(!File.Exists(Path.Combine(runtime,"msedgewebview2.exe")))runtime=null;
        try{CoreWebView2Environment.GetAvailableBrowserVersionString(runtime);}catch{throw new FileNotFoundException("WebView2 Runtime is missing. Rerun INSTALL.cmd to set up the viewer dependency.");}
        var env=await CoreWebView2Environment.CreateAsync(runtime,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Offline3DPrototype","WebCache"));
        await Browser.EnsureCoreWebView2Async(env);
        var web=Browser.CoreWebView2;web.Settings.AreDefaultContextMenusEnabled=false;web.Settings.AreDevToolsEnabled=false;web.Settings.AreHostObjectsAllowed=false;web.Settings.IsPasswordAutosaveEnabled=false;web.Settings.IsGeneralAutofillEnabled=false;
        web.SetVirtualHostNameToFolderMapping("offline3d.local",Path.Combine(AppContext.BaseDirectory,"web"),CoreWebView2HostResourceAccessKind.DenyCors);
        web.AddWebResourceRequestedFilter("*",CoreWebView2WebResourceContext.All);
        web.WebResourceRequested+=(_,e)=>{if(!Uri.TryCreate(e.Request.Uri,UriKind.Absolute,out var u)||u.GetLeftPart(UriPartial.Authority)!=Origin||!allowed.ContainsKey(u.AbsolutePath)||u.Query.Length!=0)e.Response=env.CreateWebResourceResponse(new MemoryStream(),403,"Blocked","");};
        web.NavigationStarting+=(_,e)=>{if(e.Uri!=Origin+"/index.html")e.Cancel=true;};
        web.NewWindowRequested+=(_,e)=>e.Handled=true;web.DownloadStarting+=(_,e)=>e.Cancel=true;web.PermissionRequested+=(_,e)=>e.State=CoreWebView2PermissionState.Deny;
        web.WebMessageReceived+=Message;web.Navigate(Origin+"/index.html");
    }catch(Exception ex){Status.Text=ex.Message;}}
    private void Send(object data)=>Browser.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(data,Contract.Json));
    private void SendDocument(){if(!ready||pdf==null)return;Send(new{type="document",pdf=Convert.ToBase64String(pdf),synthetic=package?.Manifest.Synthetic??false,registered=package!=null});}
    private async void Open_Click(object sender,RoutedEventArgs e){
        if(Browser.CoreWebView2==null)return;var dialog=new OpenFileDialog{Filter="PDF (*.pdf)|*.pdf",CheckFileExists=true};if(dialog.ShowDialog()!=true)return;
        opening?.Cancel();opening?.Dispose();opening=new CancellationTokenSource();var token=opening.Token;package=null;pdf=null;selected=null;sceneSent=false;
        Status.Text="Validating PDF and attachments…";
        try{
            var result=await Task.Run(()=>{token.ThrowIfCancellationRequested();if(new FileInfo(dialog.FileName).Length>Contract.MaxPdf)throw new InvalidDataException("PDF too large");var bytes=File.ReadAllBytes(dialog.FileName);OpenPackage? p=null;string? error=null;try{p=packages.Read(dialog.FileName);}catch(Exception ex){error=ex.Message;}token.ThrowIfCancellationRequested();return(bytes,p,error);},token);
            if(token.IsCancellationRequested)return;pdf=result.bytes;package=result.p;SendDocument();Status.Text=package==null?"2D/calibration only: "+result.error:package.Manifest.Synthetic?"SYNTHETIC DEMO · Click inside the plan for a 3D box":"Verified package · Click inside the calibrated plan";
        }catch(OperationCanceledException){}catch(Exception ex){if(!token.IsCancellationRequested)Status.Text=ex.Message;}
    }
    private void Message(object? sender,CoreWebView2WebMessageReceivedEventArgs e){
        if(e.Source!=Origin+"/index.html"||e.WebMessageAsJson.Length>4096)return;
        try{
            using var doc=JsonDocument.Parse(e.WebMessageAsJson);var root=doc.RootElement;string? type=root.GetProperty("type").GetString();
            if(type=="ready"){ready=true;SendDocument();return;}
            if(type=="click"){
                double x=root.GetProperty("x").GetDouble(),y=root.GetProperty("y").GetDouble();if(!double.IsFinite(x)||!double.IsFinite(y)||root.GetProperty("page").GetInt32()!=1)return;
                Status.Text=$"PDF page 1: ({x:F4}, {y:F4}) default user units";
                if(package==null)return;
                // PDF.js reports raw default user-space coordinates via viewport inversion.
                selected=Coordinates.PlanClick(package.Registration,x,y);
                if(!sceneSent){sceneSent=true;Send(new{type="scene",glb=Convert.ToBase64String(package.Glb)});}
                SendBox(root);return;
            }
            if(type=="size"&&selected.HasValue)SendBox(root);
            if(type=="error")Status.Text=root.GetProperty("message").GetString();
        }catch(Exception ex){Status.Text=ex.Message;}
    }
    private void SendBox(JsonElement root){
        if(package==null||!selected.HasValue)return;
        double Read(string name,double max,double min=1){double v=root.GetProperty(name).GetDouble();if(!double.IsFinite(v)||v<min||v>max)throw new InvalidDataException("Invalid box dimension");return v/100;}
        double width=Read("width",3000),above=Read("above",3000),below=Read("below",3000,0);
        var p=package.Registration.ModelToGraphics.Apply(selected.Value);
        Send(new{type="box",x=p.X,y=p.Y,z=p.Z,width,above,below});
    }
}

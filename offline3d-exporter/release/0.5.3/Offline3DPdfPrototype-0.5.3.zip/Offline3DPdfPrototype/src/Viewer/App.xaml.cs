using System.Windows;
namespace Offline3D.Viewer;
public partial class App:Application { }

using Offline3D;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using PdfSharp.Fonts;

try {
    if(args.Length==0)throw new ArgumentException("Commands: synthetic <folder> | inspect <pdf> | calibrate <draft-folder> <controls.json> <output.pdf>");
    var service=new PdfPackageService();
    switch(args[0]) {
        case "synthetic": {
            string dir=Path.GetFullPath(args[1]);Directory.CreateDirectory(dir);
            // Vector-only PDF, plus a locally supplied open font for the explicit synthetic label.
            GlobalFontSettings.FontResolver=new LocalFontResolver();
            string plain=Path.Combine(dir,"synthetic-plan.pdf");using(var pdf=new PdfDocument()){
                var page=pdf.AddPage();page.Width=XUnit.FromPoint(612);page.Height=XUnit.FromPoint(792);
                using(var g=XGraphics.FromPdfPage(page)){
                    g.DrawString("SYNTHETIC DEMO - NOT A REVIT EXPORT",new XFont("Prototype",14),XBrushes.Black,new XPoint(42,35));
                    g.DrawString("Offline 3D box | Level 0 | 30 x 20 feet",new XFont("Prototype",10),XBrushes.Black,new XPoint(42,55));
                    g.DrawRectangle(new XPen(XColors.SlateGray,2),60,792-500,450,300);
                    g.DrawRectangle(XBrushes.LightGray,60,792-500,450,8);
                    g.DrawRectangle(XBrushes.LightGray,60,792-200-8,450,8);
                    g.DrawRectangle(XBrushes.LightGray,60,792-500,8,300);
                    g.DrawRectangle(XBrushes.LightGray,502,792-500,8,300);
                    g.DrawLine(new XPen(XColors.Gray,4),285,792-500,285,792-340);
                    g.DrawString("Click inside the plan in Offline3D Viewer.",new XFont("Prototype",10),XBrushes.Black,new XPoint(60,635));
                }pdf.Save(plain);
            }
            var m2s=new Matrix4(1d/50,0,0,0,0,1d/50,0,0,0,0,1,0,0,0,0,1);
            var s2p=new Matrix4(750,0,0,60,0,750,0,200,0,0,1,0,0,0,0,1);
            var controls=new CalibrationInput{Fit=new[]{C(0,0),C(.6,0),C(0,.4),C(.6,.4)},Check=new[]{C(.1,.1),C(.5,.1),C(.3,.3),C(.15,.35)}};
            ControlPoint C(double x,double y){var p=s2p.Apply(new Point3(x,y));return new ControlPoint{SheetX=x,SheetY=y,PdfX=p.X,PdfY=p.Y};}
            var fit=Calibration.Fit(controls,m2s,0);
            var reg=new Registration{ViewId="synthetic-plan",LevelId="synthetic-level-0",DocumentId="synthetic-document",ModelToSheet=m2s,ModelToPdf=fit.SheetToPdf*m2s,CropSheet=new[]{0d,0,.6,0,.6,.4,0,.4},CropPdf=new[]{60d,200,510,200,510,500,60,500},PreciseClicks=true,FitPointCount=4,CheckPointCount=4,CalibrationEvidence=controls,MaxResidualMetres=fit.MaxResidualMetres};
            PdfPackageService.SetPageGeometry(plain,reg);
            var meshes=new[]{GlbBuilder.Box("floor",new Point3(0,0,-.4),new Point3(30,20,0)),GlbBuilder.Box("wall-south",new Point3(0,0,0),new Point3(30,.5,10)),GlbBuilder.Box("wall-north",new Point3(0,19.5,0),new Point3(30,20,10)),GlbBuilder.Box("wall-west",new Point3(0,0,0),new Point3(.5,20,10)),GlbBuilder.Box("wall-east",new Point3(29.5,0,0),new Point3(30,20,10)),GlbBuilder.Box("partition",new Point3(14.8,10.7,0),new Point3(15.2,20,10))};
            meshes[0].Material=new PlainMaterial{Name="Warm floor",Red=.63,Green=.43,Blue=.25,Roughness=.38};
            for(int i=1;i<5;i++)meshes[i].Material=new PlainMaterial{Name="Paint "+i,Red=i==1?.78:.88,Green=i==1?.3:.85,Blue=i==1?.2:.78,Roughness=.75};
            meshes[5].Material=new PlainMaterial{Name="Blue partition",Red=.08,Green=.35,Blue=.72,Roughness=.25};
            var files=new Dictionary<string,byte[]>{{"registration.json",Contract.Encode(reg)},{"identities.json",Contract.Encode(meshes.Select(m=>new ElementIdentity{UniqueId="synthetic:"+m.Name,MeshName=m.Name,DocumentId=reg.DocumentId}).ToArray())},{"scene.glb",GlbBuilder.Encode(meshes,reg.ModelToGraphics)}};
            service.Write(plain,Path.Combine(dir,"SYNTHETIC-Offline3D.pdf"),PdfPackageService.Describe(true,"Synthetic room; no source RVT", ".NET synthetic generator",files),files);
            File.WriteAllBytes(Path.Combine(dir,"controls.synthetic.json"),Contract.Encode(controls));
            Console.WriteLine("Created SYNTHETIC-Offline3D.pdf");break;
        }
        case "probe": {var p=service.Read(args[1]);var model=Coordinates.PlanClick(p.Registration,double.Parse(args[2],System.Globalization.CultureInfo.InvariantCulture),double.Parse(args[3],System.Globalization.CultureInfo.InvariantCulture));var g=p.Registration.ModelToGraphics.Apply(model);Console.WriteLine(System.Text.Encoding.UTF8.GetString(Contract.Encode(new {model,graphics=g})));break;}
        case "inspect": {var p=service.Read(args[1]);Console.WriteLine(System.Text.Encoding.UTF8.GetString(Contract.Encode(p.Manifest)));Console.WriteLine($"Verified {p.Elements.Length} identities; {p.Glb.Length} GLB bytes; residual {p.Registration.MaxResidualMetres:G6} m");break;}
        case "auto-export": {Offline3D.Automatic.ExportFinalizer.Export(args[1],args[2]);if(args.Contains("--notify"))Notification.Show("Export 3D PDF","Export complete: "+args[2]);break;}
        case "calibrate": {
            string dir=args[1];var reg=Contract.Decode<Registration>(File.ReadAllBytes(Path.Combine(dir,"registration.draft.json")));var controls=Contract.Decode<CalibrationInput>(File.ReadAllBytes(args[2]));
            var fit=Calibration.Fit(controls,reg.ModelToSheet,reg.LevelProjectElevationFeet);reg.ModelToPdf=fit.SheetToPdf*reg.ModelToSheet;
            if(reg.CropSheet.Length!=8)throw new InvalidDataException("Expected rectangular sheet crop");reg.CropPdf=Enumerable.Range(0,4).SelectMany(i=>{var p=fit.SheetToPdf.Apply(new Point3(reg.CropSheet[i*2],reg.CropSheet[i*2+1]));return new[]{p.X,p.Y};}).ToArray();
            reg.PreciseClicks=true;reg.CalibrationEvidence=controls;reg.FitPointCount=controls.Fit.Length;reg.CheckPointCount=controls.Check.Length;reg.MaxResidualMetres=fit.MaxResidualMetres;
            string pdf=Path.Combine(dir,"drawing.pdf");PdfPackageService.SetPageGeometry(pdf,reg);
            var files=new Dictionary<string,byte[]>{{"registration.json",Contract.Encode(reg)},{"identities.json",File.ReadAllBytes(Path.Combine(dir,"identities.json"))},{"scene.glb",File.ReadAllBytes(Path.Combine(dir,"scene.glb"))}};
            var exclusions=File.ReadAllLines(Path.Combine(dir,"exclusions.txt"));
            service.Write(pdf,args[3],PdfPackageService.Describe(false,"Selected rectangular floor-plan crop; temporary 3D section box; host model only",File.ReadAllText(Path.Combine(dir,"exporter-version.txt")),files,exclusions),files);
            Console.WriteLine($"Packaged; numeric residual {fit.MaxResidualMetres*1000:G6} mm");break;
        }
        default:throw new ArgumentException("Unknown command");
    }
    return 0;
}catch(Exception ex){Console.Error.WriteLine(ex.Message);if(args.Contains("--notify"))Notification.Show("Export 3D PDF — error",ex.Message+"\n\nNo validated enhanced PDF was produced. Temporary diagnostics were retained.");return 1;}

sealed class LocalFontResolver : IFontResolver {
    public FontResolverInfo ResolveTypeface(string familyName,bool bold,bool italic)=>new FontResolverInfo("regular");
    public byte[] GetFont(string faceName){string p=Path.Combine(AppContext.BaseDirectory,"DejaVuSans.ttf");if(!File.Exists(p))throw new FileNotFoundException("Place DejaVuSans.ttf beside Tool.dll for synthetic generation only",p);return File.ReadAllBytes(p);}
}

static class Notification {
 [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)]private static extern int MessageBoxW(IntPtr owner,string message,string title,uint type);
 public static void Show(string title,string message){if(OperatingSystem.IsWindows())MessageBoxW(IntPtr.Zero,message,title,0x40);else Console.WriteLine(title+": "+message);}
}

"""Create the installer/source archive, including the sealed prebuilt payload."""
from pathlib import Path
import zipfile,hashlib
root=Path(__file__).resolve().parents[1]
out=root.parent/'Offline3DPdfPrototype.zip'
excluded={'bin','obj','node_modules','.git','artifacts','__pycache__'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and not excluded.intersection(p.relative_to(root).parts):
   z.write(p,Path('Offline3DPdfPrototype')/p.relative_to(root))
print(out)
print('SHA256 '+hashlib.sha256(out.read_bytes()).hexdigest())

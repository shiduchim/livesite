from pathlib import Path
import hashlib,json,uuid
root=Path(__file__).resolve().parents[1];payload=root/'payload'
exporters=[]
for year,framework in [(2024,'net48'),(2025,'net8.0-windows'),(2025,'net10.0-windows'),(2026,'net8.0-windows'),(2026,'net10.0-windows'),(2027,'net10.0-windows')]:
 path=f'Exporters/{year}-{framework}/Offline3DPrototype.Revit{year}.dll'
 assert (payload/path).is_file(),path
 exporters.append({'year':year,'framework':framework,'path':path,'apiVersion':f'{year-2000}.0.0.0','referencePackageVersion':{2024:'2024.0.0',2025:'2025.0.2',2026:'2026.0.4',2027:'2027.0.0'}[year]})
assert not list(payload.rglob('RevitAPI.dll')) and not list(payload.rglob('RevitAPIUI.dll'))
assert (payload/'Viewer/Offline3D.FastPDF.Dev.exe').is_file()
files=[{'path':p.relative_to(payload).as_posix(),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(payload.rglob('*')) if p.is_file() and p!=payload/'package.json']
manifest={'schema':1,'product':'Offline3DPdfPrototype','version':'0.5.3-experimental','releaseId':uuid.uuid4().hex,'exporters':exporters,'files':files,'windowsRuntimeTested':False,'revitRuntimeTested':False,'webview2Bundled':False}
(payload/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'Sealed {len(files)} payload files, six exporter variants. Autodesk DLLs excluded.')

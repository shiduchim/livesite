"""Developer cross-build gate. Windows users run INSTALL.cmd, not this script."""
from pathlib import Path
import os,subprocess,shutil
root=Path(__file__).resolve().parents[1]
env=dict(os.environ,DOTNET_CLI_HOME='/workspace/work/dotnet-home',NUGET_PACKAGES='/workspace/work/nuget',DOTNET_CLI_TELEMETRY_OPTOUT='1',MSBUILDDISABLENODEREUSE='1',DOTNET_CLI_USE_MSBUILD_SERVER='0')
sdk='/workspace/work/dotnet10/dotnet'
variants=[(2024,'net48'),(2025,'net8.0-windows'),(2025,'net10.0-windows'),(2026,'net8.0-windows'),(2026,'net10.0-windows'),(2027,'net10.0-windows')]
for year,framework in variants:
 output=root/f'payload/Exporters/{year}-{framework}'
 if output.exists():shutil.rmtree(output)
 args=[sdk,'build','src/RevitExporter/RevitExporter.csproj','-c','Release',f'-p:RevitYear={year}',f'-p:RevitHostFramework={framework}','-p:UseSharedCompilation=false','-m:1','-nr:false','-o',str(output)]
 with (root/f'tests/revit-{year}-{framework}-build.txt').open('w') as log:subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert not list(output.glob('RevitAPI*.dll'))
 assert len(list(output.glob('*.dll')))==1, 'Exporter must be a single self-contained DLL: '+str(output)
 print('Built exporter',year,framework,flush=True)
viewer=root/'payload/Viewer'
if viewer.exists():shutil.rmtree(viewer)
with (root/'tests/viewer-publish.txt').open('w') as log:
 subprocess.run([sdk,'publish','fastpdf/src/EKFastPDF/EKFastPDF.csproj','-c','Release','-r','win-x64','--self-contained','true','-p:UseSharedCompilation=false','-m:1','-nr:false','-o',str(viewer)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Published self-contained Windows viewer',flush=True)
licenses=root/'payload/licenses'
if licenses.exists():shutil.rmtree(licenses)
shutil.copytree(root/'licenses',licenses)
shutil.copy2(root/'samples/SYNTHETIC-Offline3D.pdf',root/'payload/SYNTHETIC-Offline3D.pdf')
subprocess.run(['python',str(root/'scripts/Seal-Payload.py')],cwd=root,check=True)

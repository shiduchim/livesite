EKPDF 0.5.4

A fast PDF reader. PDFs exported from Revit with clickable 3D open in 3D:
press ClickTo3D and click the plan.

INSTALL
1. Extract this ZIP.
2. Close EKPDF if it is open.
3. Double-click INSTALL.cmd.

Installs for your Windows user only; no administrator rights are needed.
Open it from Start > EKPDF. Remove it from Windows Settings > Apps, or with
UNINSTALL.cmd. Your PDFs and settings are kept.

EKPDF needs Microsoft WebView2 Runtime for its 3D view. Windows 10 and 11
normally include it; if not, setup asks before installing Microsoft's
official runtime.

Revit users: install the EKPDF Revit add-in package after this one.

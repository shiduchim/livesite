# Third-party notices and pinned versions

| Component | Version | License / inclusion |
| --- | --- | --- |
| PDFsharp (Core package) | 6.2.0 | MIT, checked in the actual NuGet nuspec and upstream tagged LICENSE; `licenses/PDFsharp-LICENSE.txt` |
| System.Text.Json / Encodings.Web and other .NET dependencies | 8.0.5 direct JSON; exact transitives in lock files | MIT; .NET license/notices in `licenses/` |
| Babylon.js and Babylon loaders | 7.54.3 | Apache-2.0; exact licenses next to bundled vendor JS |
| PDF.js (pdfjs-dist) | 4.10.38 | Apache-2.0; vendor license included; used only in separate test host, never replaces FastPDF PDFium |
| Microsoft.Web.WebView2 SDK | 1.0.2903.40 | Microsoft BSD-style SDK redistribution conditions; exact LICENSE/NOTICE in `licenses/` |
| PDFium native package as supplied by FastPDF | 157.0.8100 | BSD-3-Clause/Apache-2.0 and bundled component notices; see inherited `fastpdf/THIRD-PARTY-NOTICES.txt` and `licenses/PDFium/` |
| DejaVu Sans | supplied system font, unchanged | Bitstream/DejaVu license; binary `assets/DejaVuSans.ttf`, terms `licenses/DejaVu-copyright.txt`; embedded in synthetic PDF |
| Test tooling | .NET Test SDK 17.11.1, xUnit 2.9.2, runner 2.8.2 | .NET/MIT and Apache-2.0 xUnit; exact NuGet records locked in FastPDF test project |

PDFsharp's license is stated for **this exact package/version**, not for all products bearing that name. Babylon and PDF.js assets are physically bundled. The static uncompressed GLB subset uses no external decoder, texture, shader download, CDN or server. Shaders are included in Babylon's local bundle. All NuGet and npm transitives are pinned with content hashes.

The Microsoft Edge/WebView2 **Fixed Runtime is separate** from its SDK and is not bundled in this source delivery. Its distribution is governed by Microsoft's runtime terms. Setup reuses an installed runtime or asks consent to obtain it from Microsoft before first offline use. No runtime license server is called by this prototype. Autodesk Revit references/runtime are also not redistributed.

FastPDF and ClickTo3D supplied source remain the user's reference materials. Only the isolated current FastPDF copy is changed for this development task. No ownership/license claim is made for those supplied products.

## Revit build references, v0.2

Nice3point.Revit.Api.RevitAPI and RevitAPIUI: 2024.0.0, 2025.0.2, 2026.0.4 and 2027.0.0. Embedded package licenses were inspected (MIT declarations) and copied to `licenses/Revit-build-references`. These reference-only assemblies are compile-time dependencies, excluded from the delivered runtime payload. This does not assert a permissive license for Autodesk Revit itself. Local Windows builds use the installed licensed product's DLLs automatically. See `docs/BUILD-DEPENDENCIES.md`.

## Additional rendering runtimes, v0.3.0

| Component | Pinned version | Terms |
| --- | --- | --- |
| Three.js | 0.186.1 | MIT, licenses/Three-LICENSE.txt |
| PlayCanvas Engine | 2.23.3 | MIT, licenses/PlayCanvas-LICENSE.txt |
| Filament JavaScript/WASM | 1.53.4 | Apache-2.0, licenses/Filament-LICENSE.txt; upstream Google Filament SDK |
| three-gpu-pathtracer | 0.0.27 | MIT, licenses/three-gpu-pathtracer-LICENSE.txt |
| three-mesh-bvh | 0.9.15 | MIT, licenses/three-mesh-bvh-LICENSE.txt |
| xatlas-web | 0.1.0 | MIT, licenses/xatlas-web-LICENSE.txt |
| Earcut | 2.2.4 | ISC, licenses/earcut-LICENSE.txt |
| glslang / Tint-Dawn WebGPU shader tools | Babylon core 7.54.3 distribution | Included upstream license notices: licenses/glslang-LICENSE.txt and Tint-Dawn-LICENSE.txt |
| esbuild (developer bundling only) | 0.25.12 | MIT; not required on the recipient computer |

The trusted installed runtime bundles these engines; PDFs supply validated model data only. No engine is loaded from a document or a remote CDN. Filament is WASM/WebGL2 here. The Photo adapter uses the package's WebGLPathTracer export. Bundled generated adapters retain upstream license banners and dependency notices. npm package-lock.json records exact dependency hashes.

Babylon's studio environment is copied from its official playground texture repository under Apache-2.0 (licenses/Babylon-studio-LICENSE.md): https://raw.githubusercontent.com/BabylonJS/Babylon.js/master/packages/tools/playground/public/textures/environment.env . SHA-256: 65f5a57bdf9d9e27776df663cd6bb2cb3890c40994f0efe2b4b0cf6e0647f3cb. The separate studio.ktx is an original procedurally generated lighting cubemap; it contains no third-party photography. Three's RoomEnvironment and the Photo gradient are generated locally.

Navisworks was researched, not bundled; no Autodesk graphics runtime is redistributed. See docs/RENDER-ENGINE-COMPARISON.md.

## v0.4.0 runtime scope

The installed viewer now contains Babylon.js and Three.js only. PlayCanvas, Filament and three-gpu-pathtracer licenses above are retained for historical source adapters in the source archive; those engines are not installed in the v0.4.0 viewer runtime. No meshoptimizer or SharpGLTF binary is included: the custom writer uses indexed float32 geometry and shared translated meshes.

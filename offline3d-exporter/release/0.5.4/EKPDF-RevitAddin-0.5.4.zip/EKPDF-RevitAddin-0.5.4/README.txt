EKPDF Revit add-in 0.5.4

Adds Add-Ins > Export 3D PDF to Revit 2024, 2025, 2026 and 2027. It exports
a plan or sheet as a PDF with clickable offline 3D.

INSTALL
1. Install EKPDF first (the EKPDF-0.5.4 package). The add-in uses it to
   finish each 3D PDF.
2. Extract this ZIP and close Revit.
3. Double-click INSTALL.cmd.

Installs for your Windows user only, for every Revit 2024-2027 found. It
replaces an earlier "Offline 3D PDF" 0.5.x installation automatically.
Remove it from Windows Settings > Apps, or with UNINSTALL.cmd.
